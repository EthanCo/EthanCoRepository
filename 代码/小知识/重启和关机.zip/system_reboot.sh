#!/system/bin/sh  
reboot