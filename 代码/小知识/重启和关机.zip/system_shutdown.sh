#!/system/bin/sh  
reboot -p