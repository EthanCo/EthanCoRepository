package com.zhk.myfragment;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ListFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView.ScaleType;
import android.widget.ListView;

public class LeftFragment extends ListFragment {
	private int[] data = new int[]{R.drawable.a,
			R.drawable.b,
			R.drawable.c,
			R.drawable.d,
			R.drawable.e,
			R.drawable.f,
			R.drawable.g,
			};
	
	private int currentPosition = 0;//��ʼ����ѡ��λ��
	
	
	
	//fragment�����Լ�����ͼ���˴���Ϊ��ListFragment���ʲ�������
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return super.onCreateView(inflater, container, savedInstanceState);
	}
	
	//��activity��������
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		//��򵥷�ʽ
		//		setListAdapter(new ArrayAdapter<String>(getActivity(),  android.R.layout.simple_list_item_activated_1, android.R.id.text1, data));
		//		showDetail(currentPosition);	
		//baseAdapter��ʽ
		setListAdapter(new BaseAdapter() {
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {

				ImageButton imgbt = new ImageButton(getActivity());
				imgbt.setImageResource(data[position]);
				imgbt.setScaleType(ScaleType.FIT_XY);
				final int p =position;
				imgbt.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						showDetail(p);
					}
				});
				return imgbt;
			}
			
			@Override
			public long getItemId(int position) {
				// TODO Auto-generated method stub
				return currentPosition;
			}
			
			@Override
			public Object getItem(int position) {
				// TODO Auto-generated method stub
				return data[currentPosition];
			}
			
			@Override
			public int getCount() {
				// TODO Auto-generated method stub
				return data.length;
			}
		});
		showDetail(currentPosition);
	}
	
	//��ʾ������Ϣ
	private void showDetail(int index){
		//fragment�Ĺ�����
		FragmentManager fm = getFragmentManager();
		DetailFragment detail = (DetailFragment) fm.findFragmentById(R.id.detail);
		if(detail == null || index != detail.getShowIndex()){
			//����Ϊ��ѡģʽ
			getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
			//ָ����Ŀ��ѡ��
			getListView().setItemChecked(index, true);
			//�½�DetailFragment��ʵ��
			detail = DetailFragment.getInstance(index);
			//�滻FrameLayoutΪDetailFragment  ������ ����
			FragmentTransaction ft = fm.beginTransaction();
			ft.replace(R.id.detail, detail); //��������(�滻)FrameLayout
			ft.commit();
		}
	}
	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		showDetail(position);
	}
}
