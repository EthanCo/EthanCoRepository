package com.zhk.ActivityReturn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Activity1 extends Activity {

	private EditText et1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity1);
		
		et1 = (EditText)findViewById(R.id.et1);
		Button bt1 = (Button)findViewById(R.id.bt1);
		bt1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(Activity1.this,Activity2.class);
//				startActivity(intent);
				startActivityForResult(intent, 0); //����ָ��Activity���ȴ�������أ�0��������
			}
		});
	}
	
	@Override
	public void onActivityResult(int requestCode,int resultCode,Intent intent){
		if(requestCode==0&&resultCode==0){
			Bundle bundle = intent.getExtras();
			String result = bundle.getString("info");
			et1.setText(result);
		}
	}
}
