/** Automatically generated file. DO NOT MODIFY */
package com.readystatesoftware.viewbadger;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}