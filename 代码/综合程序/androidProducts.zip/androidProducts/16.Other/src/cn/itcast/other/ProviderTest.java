package cn.itcast.other;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.test.AndroidTestCase;

public class ProviderTest extends AndroidTestCase {
	
	// .class -> .dex -> .apk -> ��װ -> ��������(�������߳�) -> ����ProviderTest���� -> setContext() -> ���Է��� -> getContext()
	
	public void test1() {
		// ��ȡ����������
		ContentResolver resolver = getContext().getContentResolver();
		
        // ���������ṩ��
        Uri uri = Uri.parse("content://cn.itcast.sqlite.provider");
		ContentValues values = new ContentValues();
		
		resolver.insert(uri, values);
		resolver.delete(uri, null, null);
		resolver.update(uri, values, null, null);
		resolver.query(uri, null, null, null, null);
	}
	
	public void testQuery1() {
		ContentResolver resolver = getContext().getContentResolver();
		Uri uri = Uri.parse("content://cn.itcast.sqlite.provider/person");
		Cursor c = resolver.query(uri, new String[]{ "id", "name", "balance" }, "balance>?", new String[]{ "9000" }, "balance DESC");
		while (c.moveToNext()) {
			Person p = new Person(c.getInt(0), c.getString(1), c.getInt(2));
			System.out.println(p);
		}
	}
	
	public void testQuery2() {
		ContentResolver resolver = getContext().getContentResolver();
		Uri uri = Uri.parse("content://cn.itcast.sqlite.provider/person/100");
		Cursor c = resolver.query(uri, null, "balance>?", new String[]{ "9100" }, null);
		while (c.moveToNext()) {
			Person p = new Person(c.getInt(0), c.getString(1), c.getInt(2));
			System.out.println(p);
		}
	}
	
	public void testInsert() {
		ContentResolver resolver = getContext().getContentResolver();
		Uri uri = Uri.parse("content://cn.itcast.sqlite.provider/person");
		
		ContentValues values = new ContentValues();
		values.put("name", "provider");
		values.put("balance", 12345);
		uri = resolver.insert(uri, values);		// ��������, ���ҵõ��������ݵ�uri
		System.out.println(uri);
	}
	
	public void testUpdate() {
		ContentResolver resolver = getContext().getContentResolver();
		Uri uri = Uri.parse("content://cn.itcast.sqlite.provider/person");
		
		ContentValues values = new ContentValues();
		values.put("name", "update");
		values.put("balance", 54321);
		int count = resolver.update(uri, values, null, null);		// ��������, �õ�Ӱ���¼��
		System.out.println(count);
	}
	
	public void testDelete() {
		ContentResolver resolver = getContext().getContentResolver();
		Uri uri = Uri.parse("content://cn.itcast.sqlite.provider/person");
		int count = resolver.delete(uri, null, null);
		System.out.println(count);
	}
	
	public void testGetType() {
		ContentResolver resolver = getContext().getContentResolver();
		String type1 = resolver.getType(Uri.parse("content://cn.itcast.sqlite.provider/person"));		// ��ȡuri������
		String type2 = resolver.getType(Uri.parse("content://cn.itcast.sqlite.provider/person/100"));
		System.out.println(type1);
		System.out.println(type2);
	}
	
	
	
	
}
