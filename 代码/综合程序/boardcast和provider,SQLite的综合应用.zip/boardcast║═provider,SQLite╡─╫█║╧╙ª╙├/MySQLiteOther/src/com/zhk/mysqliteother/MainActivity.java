package com.zhk.mysqliteother;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends Activity {

	private EditText etInsertTV;
	private TextView tvInfo;
	ContentResolver contentResoler;
	Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming");

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		etInsertTV = (EditText)findViewById(R.id.InsertTV);
		tvInfo = (TextView)findViewById(R.id.tv_info);
		contentResoler = getContentResolver();
		
		 Button btInsert =(Button) findViewById(R.id.InsertBT);
		 btInsert.setOnClickListener(new OnClickListener() {
		 @Override
			 public void onClick(View v) {
			 ContentValues values = new ContentValues();
			  contentResoler.insert(uri, values);
				 Toast.makeText(getApplicationContext(), "�������ݳɹ�",
				 Toast.LENGTH_SHORT).show();
			 }
		 });
		 
			Button btSearch =(Button) findViewById(R.id.SearchBT);
			btSearch.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					//uriһ��Ҫ��
					Cursor cursor = contentResoler.query(uri, null, null, null, null);
					Toast.makeText(getApplicationContext(), "��ʼ��ѯ����", Toast.LENGTH_SHORT).show();
					tvInfo.setText(infateList(cursor));
				}
			});
	}
	
	private String infateList(Cursor cursor) {
		String str ="";
		while(cursor.moveToNext()){
			str+=cursor.getString(cursor.getColumnIndex("_id"));
			str+=cursor.getString(cursor.getColumnIndex("name"));
			str+=cursor.getInt(cursor.getColumnIndex("age"));
			str+="\n";
		}
		return str;
	}
}
	

	
//	@Override
//	protected void onDestroy() {
//		super.onDestroy();
//	}
//}
