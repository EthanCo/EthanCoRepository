package com.zhk.mysqlite;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	MySQLiteOpenHelper sHelper;
	SQLiteDatabase db; //���һ����̬����
	private EditText etInsertTV;
	private TextView tvInfo;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		etInsertTV = (EditText)findViewById(R.id.InsertTV);
		tvInfo = (TextView)findViewById(R.id.tv_info);
		//����������ݿ�
//		db= SQLiteDatabase.openOrCreateDatabase(getFilesDir().toString()+"/ismyDB.db3", null);	
//		sHelper = new MySQLiteOpenHelper(this, "ismyDBa.db3",null,1);
		Toast.makeText(getApplicationContext(), "�����ݿ�ɹ�", Toast.LENGTH_SHORT).show();
		
		Button btCreateTable = (Button)findViewById(R.id.CreateTableBT);
		btCreateTable.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//�����SQLiteOpenHelper���������Ҫ����MySQLiteOpenHelper.onCreate��������
//				db.execSQL("create table tb_student(_id varchar(16) primary key,name varchar(16),age integer)");
				SQLiteDatabase thisdb = sHelper.getReadableDatabase();
				Toast.makeText(getApplicationContext(), "���ӱ��ɹ�", Toast.LENGTH_SHORT).show();
			}
		});
		
		Button btInsert =(Button) findViewById(R.id.InsertBT);
		btInsert.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String id= etInsertTV.getText().toString();
//				db.execSQL("insert into tb_student values(?,?,?)", new Object[]{id,"ssss",18});
				SQLiteDatabase thisdb = sHelper.getReadableDatabase();
				thisdb.execSQL("insert into tb_student values(?,?,?)", new Object[]{id,"ssss",18});
				Toast.makeText(getApplicationContext(), "�������ݳɹ�", Toast.LENGTH_SHORT).show();
			}
		});
		
		Button btSearch =(Button) findViewById(R.id.SearchBT);
		btSearch.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "��ʼ��ѯ����", Toast.LENGTH_SHORT).show();
//				Cursor cursor = db.rawQuery("select * from tb_student", null);
				Cursor cursor =sHelper.getReadableDatabase().rawQuery("select * from tb_student",null);
				tvInfo.setText(infateList(cursor));
			}
		});
	}
	
	private String infateList(Cursor cursor) {
		String str ="";
		while(cursor.moveToNext()){
			str+=cursor.getString(cursor.getColumnIndex("_id"));
			str+=cursor.getString(cursor.getColumnIndex("name"));
			str+=cursor.getInt(cursor.getColumnIndex("age"));
			str+="\n";
		}
		return str;
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		//�˳�����ʱ�ر�MySQLiteOpenHelper���SQLiteDatabase
		if (sHelper!=null) {
			sHelper.close();
		}
	}
}
