package com.zhk.domain;

import java.util.Date;

public class ChatMessage {
	
	public ChatMessage() {
		super();
	}
	public ChatMessage(String info, Type type, Date date) {
		super();
		this.info = info;
		this.type = type;
		this.date = date;
	}
	private String name;
	private String info;
	private Type type;
	private Date date;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public Type getType() {
		return type;
	}
	public void setType(Type type) {
		this.type = type;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public enum Type{
		INCOMING,OUTCOMING
	}
}
