package com.zhk.girlfriendrobot;

import java.text.SimpleDateFormat;
import java.util.List;

import com.zhk.domain.ChatMessage;
import com.zhk.domain.ChatMessage.Type;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ChatMessageADapter extends BaseAdapter{

	private LayoutInflater mInflater;
	List<ChatMessage> mDatas;
	
	public ChatMessageADapter(Context context,List<ChatMessage> mDatas){
		mInflater=LayoutInflater.from(context);
		this.mDatas=mDatas;
	}
	
	@Override
	public int getCount() {
		return mDatas.size();
	}

	@Override
	public Object getItem(int position) {
		return mDatas.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	//���������ڲ��ֲ�ͬʱҪ��д
	@Override
	public int getItemViewType(int position) {
		ChatMessage chatMessage = mDatas.get(position);
		if(chatMessage.getType()==Type.INCOMING){
			return 0; //������Ϣ
		}else{
			return 1; //������Ϣ
		}
	}

	@Override
	public int getViewTypeCount() {
		return 2;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ChatMessage chatMessage = mDatas.get(position);
		ViewHolder viewHolder = null;
		if(convertView==null){
			//ͨ��itemType���ò�ͬ�Ĳ���
			if(getItemViewType(position)==0){
			convertView = mInflater.inflate(R.layout.from_msg, parent,false);
			viewHolder = new ViewHolder();
			viewHolder.mMsg= (TextView) convertView.findViewById(R.id.from_msg_msg);
			viewHolder.mDate = (TextView) convertView.findViewById(R.id.from_msg_date);
			}else{
				convertView = mInflater.inflate(R.layout.send_msg, parent,false);
				viewHolder = new ViewHolder();
				viewHolder.mMsg= (TextView) convertView.findViewById(R.id.send_msg_msg);
				viewHolder.mDate = (TextView) convertView.findViewById(R.id.send_msg_date);
			}
			convertView.setTag(viewHolder);
		}else{
			viewHolder=(ViewHolder) convertView.getTag();
		}
		//��������
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		viewHolder.mDate.setText(df.format(chatMessage.getDate()));
		viewHolder.mMsg.setText(chatMessage.getInfo());
		return convertView;
	}
	
	private final class ViewHolder{
		TextView mDate;
		TextView mMsg;
	}

}
