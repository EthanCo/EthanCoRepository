package com.zhk.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.zhk.domain.ChatMessage;
import com.zhk.domain.Result;
import com.zhk.domain.ChatMessage.Type;

//����Http����Ĺ�����
public class HttpUtils {
	private static final String serverURL = "http://www.tuling123.com/openapi/api"; // �����﷢������
	private static final String APIKEY = "e33caa9899c57efdd6cc19e272153455"; // ������ע���ʺ�

	/**
	 * @return �̶��ľ���ʹ�õ�URL
	 */
	private static StringBuffer getOftenURL() {
		StringBuffer sb = new StringBuffer(serverURL);
		sb.append("?key=").append(APIKEY);
		return sb;
	}

	/**
	 * 
	 * @param info �û��������Ϣ
	 * @return ������URL
	 */
	private static String getURL(String info) {
		StringBuffer sb = getOftenURL();
		sb.append("&info=").append(info);
		return sb.toString();
	}

	public static String getJson(String info) {
		String result = "";
		ByteArrayOutputStream baos = null;
		InputStream is = null;
		
		try {
			info = URLEncoder.encode(info, "utf-8");
			URL url = new URL(getURL(info));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setReadTimeout(5000);
			conn.setRequestMethod("GET");
			if (conn.getResponseCode() == 200) {
				is = conn.getInputStream();
				int len = -1;
				byte[] buf = new byte[128];
				baos = new ByteArrayOutputStream();
				while ((len = is.read(buf)) != -1) {
					baos.write(buf, 0, len);
				}
				baos.flush();
				result = new String(baos.toByteArray());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (baos != null) {
				try {
					baos.flush();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	/**
	 * ����һ����Ϣ,���صõ�����Ϣ
	 * @param info 
	 * @return
	 */
	public static ChatMessage sendMessage(String info){
		ChatMessage chatMessage = new ChatMessage();
		
		Gson gson = new Gson();
		String jsonRes = getJson(info);
		Result result =null;
		try {
			result = gson.fromJson(jsonRes, Result.class);
			chatMessage.setInfo(result.getText());
		} catch (JsonSyntaxException e) {
			chatMessage.setInfo("��������æ");
		}
		chatMessage.setDate(new Date());
		chatMessage.setType(Type.INCOMING);
		return chatMessage;
	}
}
