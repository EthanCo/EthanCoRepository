package com.zhk.mysqlite;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.preference.PreferenceActivity.Header;

public class MyContentProvider extends ContentProvider {
	MySQLiteOpenHelper dbHelper;
	UriMatcher matcher;
	private SQLiteDatabase db;
	private static final int tbPower = 1;
	private static final int tbPower_ID = 2;

	@Override
	public boolean onCreate() {
		dbHelper = new MySQLiteOpenHelper(getContext(), "db_data.db3");
		db = dbHelper.getReadableDatabase();
		matcher = new UriMatcher(UriMatcher.NO_MATCH);
		matcher.addURI("com.zhk.mysqlite.MyContentProvider", "tb_power", tbPower); //ƥ�䵽tb_power����ֵ����1
		matcher.addURI("com.zhk.mysqlite.MyContentProvider", "tb_power/#", tbPower_ID);//ƥ�䵽tb_power��ֵ����2
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
		switch (matcher.match(uri)) {
		case tbPower_ID:
			long id = ContentUris.parseId(uri);//ContentUris �����ڻ�ȡUri·�������ID����
			selection = selection == null ? "_id=" + id : selection + "AND _id" + id;
			//			break; //��Ҫbreak
		case tbPower:
			return db.query("tb_power", new String[] { "_id", "name" }, selection, selectionArgs, null, null, sortOrder);
		default:
			throw new RuntimeException("uri����ʶ��:" + uri);
		}
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		switch (matcher.match(uri)) {
		case tbPower:
			long id = db.insert("tb_power", "suiyi", values);
			return ContentUris.withAppendedId(uri, id);// ��id����uri���淵��
		default:
			throw new RuntimeException("Uri����ʶ��" + uri);
		}
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		switch (matcher.match(uri)) {
		case tbPower_ID:
			long id = ContentUris.parseId(uri);
			selection = selection == null ? "_id=" + id : selection + " AND _id=" + id; //������ѯ����
		case tbPower:
			return db.delete("tb_power", selection, selectionArgs);
		default:
			throw new RuntimeException("Uri����ʶ��:" + uri);
		}
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
		switch (matcher.match(uri)) {
		case tbPower:
			return db.update("tb_power", values, selection, selectionArgs);
		default:
			throw new RuntimeException("Uri����ʶ��:" + uri);
		}
	}

}
