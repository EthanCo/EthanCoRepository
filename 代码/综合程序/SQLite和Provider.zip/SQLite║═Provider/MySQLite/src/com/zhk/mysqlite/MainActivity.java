package com.zhk.mysqlite;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	private MySQLiteUtil util;
	private EditText etID;
	private Toast mToast;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initView();

		util = new MySQLiteUtil(getApplicationContext());
	}

	private void initView() {
		etID = (EditText) findViewById(R.id.etID);
		mToast = Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT);
	}

	public void insert(View v) {
		String id = etID.getText().toString();
		if (getEtIdText(id)) {
			Student stu = new Student(id, "xxx" + id);
			util.insert(stu);
			showTip("���ӳɹ�");
		}
	}

	public void search(View v) {
		String id = etID.getText().toString();
		if (getEtIdText(id)) {
			Student stu = util.Search(id);
			if (stu == null) {
				showTip("���޴���");
			} else {
				showTip("ID:" + stu.getId() + " Name:" + stu.getName());
			}
		}
	}
	
	public void delete(View v){
		String id = etID.getText().toString();
		if(getEtIdText(id)){
			util.delete(id);
			showTip("ɾ���ɹ�");
		}
	}
	
	public void update(View v){
		String id = etID.getText().toString();
		if(getEtIdText(id)){
			Student stu = new Student(id, "yyy"+id);
			util.update(stu);
			showTip("�޸ĳɹ�");
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		util.close();
	}

	private boolean getEtIdText(String id) {
		if (id.equals("")) {
			showTip("��������id");
			return false;
		} else {
			return true;
		}
	}
	
	private void showTip(String tip) {
		mToast.setText(tip);
		mToast.show();
	}
}
