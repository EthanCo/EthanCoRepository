package com.zhk.mysqliteother;

import android.R.integer;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	private EditText etInfo;
	private static final Uri uri = Uri.parse("content://com.zhk.mysqlite.MyContentProvider/tb_power");

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		etInfo = (EditText) findViewById(R.id.etInfo);
	}

	public void search(View v) {
		String id = etInfo.getText().toString();
		if (id.equals("")) {
			Toast.makeText(getApplicationContext(), "������id", Toast.LENGTH_SHORT).show();
		} else {
			ContentResolver resolver = getContentResolver();
			Cursor c = resolver.query(uri, null, "_id=?", new String[] { id }, null);
			if (c.moveToNext()) {
				etInfo.setText("ID:" + c.getString(0) + " NAME:" + c.getString(1));
			}
		}
	}

	public void insert(View v) {
		String id = etInfo.getText().toString();
		String name = "name" + id;
		if (id.equals("")) {
			Toast.makeText(getApplicationContext(), "������id", Toast.LENGTH_SHORT).show();
		} else {
			ContentResolver resolver = getContentResolver();
			ContentValues values = new ContentValues();
			values.put("_id", id);
			values.put("name", name);
			Uri newUri = resolver.insert(uri, values);
			long rowNum = ContentUris.parseId(newUri); //�����к�
			if (rowNum>0) {
				Toast.makeText(getApplicationContext(), "�������ݳɹ�", Toast.LENGTH_SHORT).show();
			}
		}
	}

	public void delete(View v) {
		String id = etInfo.getText().toString();
		if (id.equals("")) {
			Toast.makeText(getApplicationContext(), "������id", Toast.LENGTH_SHORT).show();
		} else {
			//Uri newUri = ContentUris.withAppendedId(uri, Integer.parseInt(id));//���ֻ����id��һλ��Ϊ0ʱʹ��,������ת��ʱ���0ȥ��
			ContentResolver resolver = getContentResolver();
			int res = resolver.delete(uri, "_id=?", new String[]{id});
			System.out.println("delete"+res);
			if (res == 1) {
				Toast.makeText(getApplicationContext(), "id:" + id + "ɾ���ɹ�", Toast.LENGTH_SHORT).show();
			}
		}
	}

	public void update(View v) {
		String id = etInfo.getText().toString();
		if (id.equals("")) {
			Toast.makeText(getApplicationContext(), "������id", Toast.LENGTH_SHORT).show();
		} else {
			ContentResolver resolver = getContentResolver();
			ContentValues values = new ContentValues();
			values.put("name", "NewName"+id);
			resolver.update(uri, values, "_id=?", new String[] { id });
			Toast.makeText(getApplicationContext(), "id:" + id + "���³ɹ�", Toast.LENGTH_SHORT).show();
		}
	}
}
