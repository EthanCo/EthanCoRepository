package com.ethanco.mytest1030;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageView imgView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //隐藏状态栏
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        imgView = (ImageView) findViewById(R.id.imgView);

        imgView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Drawable drawable = getResources().getDrawable(R.drawable.bg);
                //Drawable drawable = getResources().getDrawable(R.drawable.bg2);
                //Drawable drawable = getResources().getDrawable(R.drawable.bg3);
                BitmapDrawable bd = (BitmapDrawable) drawable;
                Bitmap bitmap = bd.getBitmap();

                BlurBitmapUtil.blurRenderScript(bitmap, imgView, MainActivity.this, 3, 15);
                //BlurBitmapUtil.blurFastBlur(bitmap, imgView, MainActivity.this, 3, 15);
                //BlurBitmapUtil.blurFastBlurByPercent(bitmap, imgView, MainActivity.this, 3, 15);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
