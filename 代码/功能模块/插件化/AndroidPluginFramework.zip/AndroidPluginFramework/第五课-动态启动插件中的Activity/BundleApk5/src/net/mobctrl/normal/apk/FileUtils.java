package net.mobctrl.normal.apk;

import android.content.Context;
import android.widget.Toast;

/**
 * @Author Zheng Haibo
 * @Mail mochuan.zhb@alibaba-inc.com
 * @Company Alibaba Group
 * @PersonalWebsite http://www.mobctrl.net
 * @version $Id: FileUtils.java, v 0.1 2015年12月10日 下午2:30:40 mochuan.zhb Exp $
 * @Description
 */
public class FileUtils {
	
	public void write(){
		
	}

	public void print(Context context, String name) {
		Toast.makeText(context, name, Toast.LENGTH_SHORT).show();
	}
}
