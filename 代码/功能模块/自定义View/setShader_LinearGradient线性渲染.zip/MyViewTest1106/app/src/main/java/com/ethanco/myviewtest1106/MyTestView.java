package com.ethanco.myviewtest1106;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by YOLANDA on 2015-11-06.
 */
public class MyTestView extends View {

    private Paint mBackgroundPaint;
    private int mBackgroundColor;
    private int mBackgroundSecondColor;
    private RectF mBackgroundBounds;
    private int mButtonRadius = 0;

    public MyTestView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public MyTestView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MyTestView(Context context) {
        super(context);
        init();
    }

    private void init() {
        mBackgroundColor = getResources().getColor(R.color.colorPrimary);
        mBackgroundSecondColor = getResources().getColor(R.color.colorAccent);

        //设置背景画笔
        mBackgroundPaint = new Paint();
        mBackgroundPaint.setAntiAlias(true);
        mBackgroundPaint.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        mBackgroundBounds = new RectF();
        if (mButtonRadius == 0) {
            mButtonRadius = getMeasuredHeight() / 2;
        }
        mBackgroundBounds.left = 2;
        mBackgroundBounds.top = 2;
        mBackgroundBounds.right = getMeasuredWidth() - 2;
        mBackgroundBounds.bottom = getMeasuredHeight() - 2;

        LinearGradient mProgressBgGradient = new LinearGradient(0, 0, getMeasuredWidth(), 0,
                new int[]{mBackgroundColor, mBackgroundSecondColor},
                new float[]{0.6F, 0.6F + 0.001f},
                Shader.TileMode.CLAMP
        );

        mBackgroundPaint.setColor(mBackgroundColor);
        mBackgroundPaint.setShader(mProgressBgGradient);
        canvas.drawRoundRect(mBackgroundBounds, mButtonRadius, mButtonRadius, mBackgroundPaint);
    }
}
