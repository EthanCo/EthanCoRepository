package com.zhk.ningbo.customedrawerlayout;

import android.content.Context;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.ViewDragHelper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Created by Zhk on 2015/10/18.
 */
public class MyDrawerLayout extends FrameLayout {
    private ViewDragHelper mDragHelper;
    private View mLeftContent;
    private View mMainContent;
    private int mHeight;
    private int mWidth;
    private int mMoveRange;

    public MyDrawerLayout(Context context) {
        super(context);
        init();
    }

    public MyDrawerLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MyDrawerLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        mDragHelper = ViewDragHelper.create(this, 1, new ViewDragHelper.Callback() { //sensitivity:滑动的速度，多快的情况下才会触发
            @Override
            public boolean tryCaptureView(View child, int pointerId) {
/*              为了触摸leftContent时，让MainContent滑动，需要 return true，然后在clampViewPositionHorizontal中判断处理
                if (child == mLeftContent) {
                    return false;
                } else if (child == mMainContent) {
                    return true;
                }
                return false;*/
                return true;
            }

            @Override
            public void onViewCaptured(View capturedChild, int activePointerId) {
                // 当capturedChild被捕获时,调用.
                super.onViewCaptured(capturedChild, activePointerId);
            }

            @Override
            public int getViewHorizontalDragRange(View child) {
                //return super.getViewHorizontalDragRange(child);
                return mMoveRange; // 返回拖拽的范围, 不对拖拽进行真正的限制. 仅仅决定了动画执行速度
            }

            /**
             * 根据建议值 修正将要移动到的(横向)位置   (重要)
             * 此时没有发生真正的移动
             * @param child
             * @param left
             * @param dx
             * @return
             */
            @Override
            public int clampViewPositionHorizontal(View child, int left, int dx) {
                /**
                 * child.getLeft()  原来的left
                 * dx               水平方向变化量
                 * left             =child.getLeft()+dx
                 */
                if (child == mMainContent) {
                    left = fixLeft(left); //对MainContent的范围滑动进行限制
                }

                return left;
            }

            /**
             * 当View位置改变的时候, 处理要做的事情 (更新状态, 伴随动画, 重绘界面)
             * 此时,View已经发生了位置的改变
             * @param changedView 改变位置的View
             * @param left        新的左边值
             * @param top
             * @param dx          水平方向变化量
             * @param dy
             */
            @Override
            public void onViewPositionChanged(View changedView, int left, int top, int dx, int dy) {
                super.onViewPositionChanged(changedView, left, top, dx, dy);

                int newLeft = left;
                if (changedView == mLeftContent) {
                    // 把当前变化量传递给mMainContent
                    newLeft = mMainContent.getLeft() + dx;
                }

                // 进行修正
                newLeft = fixLeft(newLeft);

                if (changedView == mLeftContent) {
                    mLeftContent.layout(0, 0, mWidth, mHeight);
                    mMainContent.layout(newLeft, 0, newLeft + mWidth, 0 + mHeight);
                }

                // 为了兼容低版本, 每次修改值之后, 进行重绘
                invalidate();
            }

            /**
             * 当View被释放的时候, 处理的事情(执行动画)
             * @param releasedChild 被释放的子View
             * @param xvel          水平方向的速度, 向右为+
             * @param yvel          竖直方向的速度, 向下为+
             */
            @Override
            public void onViewReleased(View releasedChild, float xvel, float yvel) {
                super.onViewReleased(releasedChild, xvel, yvel);

                // 判断执行 关闭/开启
                // 先考虑所有开启的情况,剩下的就都是关闭的情况
                if (xvel == 0 && mMainContent.getLeft() > mMoveRange / 2.0F) {
                    open();
                } else if (xvel > 0) {
                    open();
                } else {
                    close();
                }
            }
        });
    }

    @Override
    public void computeScroll() {
        super.computeScroll();

        if (mDragHelper.continueSettling(true)) {
            ViewCompat.postInvalidateOnAnimation(this);
        }
    }

    public void close() {
        close(true);
    }

    /**
     * 关闭
     *
     * @param isSmooth 是否开启顺滑
     */
    public void close(boolean isSmooth) {
        int finalLeft = 0;
        if (isSmooth) {
            // 1. 触发一个平滑动画
            if (mDragHelper.smoothSlideViewTo(mMainContent, finalLeft, 0)) {
                // 返回true代表还没有移动到指定位置, 需要刷新界面.
                // 参数传this(child所在的ViewGroup)
                ViewCompat.postInvalidateOnAnimation(this);
            }
        } else {
            mMainContent.layout(finalLeft, 0, finalLeft + mWidth, 0 + mHeight);
        }
    }

    public void open() {
        open(true);
    }

    /**
     * 开启
     *
     * @param isSmooth 是否开启顺滑
     */
    public void open(boolean isSmooth) {
        int finalLeft = mMoveRange;
        if (isSmooth) {
            // 触发一个平滑动画
            if (mDragHelper.smoothSlideViewTo(mMainContent, finalLeft, 0)) {
                // 返回true代表还没有移动到指定位置, 需要刷新界面.
                // 参数传this(child所在的ViewGroup)
                ViewCompat.postInvalidateOnAnimation(this);
            }
        } else {
            mMainContent.layout(finalLeft, 0, finalLeft + mWidth, 0 + mHeight);
        }
    }


    private int fixLeft(int left) {
        if (left < 0) {
            return 0;
        } else if (left > mMoveRange) {
            return mMoveRange;
        }
        return left;
    }

    @Override
    public boolean onInterceptHoverEvent(MotionEvent event) {
        return mDragHelper.shouldInterceptTouchEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mDragHelper.processTouchEvent(event);
        //要返回true，否则在Down之后就接收不到touch事件了
        return true;
    }

    @Override
    protected void onFinishInflate() { //当子View都填充完毕的时候调用
        super.onFinishInflate();

        int childCount = getChildCount();
        if (childCount < 2) {
            throw new IllegalStateException("布局至少有两个childView");
        }
//        if (!(getChildAt(0) instanceof ViewGroup && getChildAt(1) instanceof ViewGroup)) {
//            throw new IllegalArgumentException("子View必须是ViewGroup的子类. Your children must be an instance of ViewGroup");
//        }

        mLeftContent = getChildAt(0);
        mMainContent = getChildAt(1);
    }

    /**
     * 当尺寸有变化的时候调用
     *
     * @param w
     * @param h
     * @param oldw
     * @param oldh
     */
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        mHeight = getMeasuredHeight();
        mWidth = getMeasuredWidth();

        //移动的范围
        mMoveRange = (int) (mWidth * 0.6);
    }
}
