#### View的getMeasuredWidth和getWidth这两个方法有什么区别 ####
先来看看getwidth  
	public final int getWidth() {
        return mRight - mLeft;
    }

getMeasuredWidth
	public final int getMeasuredWidth() {
        return mMeasuredWidth & MEASURED_SIZE_MASK;
    }

在默认的实现中，View的测量宽/高和最终的宽/高是相等的，只不过  

- 测量宽高形成与View的measure过程 (稍早)
- 最终宽高形成与View的layout过程

在日常的开发中，我们可以认为View的测量宽高就等于最终宽高，但是的确在某些特殊的情况下会导致两者不一致。



- 如果重写了View的layout方法，修改了其super.layout传入的参数，那么测量宽高就会与最终宽高不相等了
- 如果View需要多次measure才能确定自己测量的宽高，在前几次的测量过程中，其得出的测量宽高可能和最终宽高不一致，但最终来讲，测量宽高还是和最终宽高相同。