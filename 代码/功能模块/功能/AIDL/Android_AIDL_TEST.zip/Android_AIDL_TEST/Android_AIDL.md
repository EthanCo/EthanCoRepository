### 调用其他APP的Service ###
**Android5.0之前可以使用隐式的意图来调用Service,而Android5.0之后,就必须要用显示意图才能调用Service了。**  
### 被启动程序的Service ###
在清单文件注册service时要添加  

	android:exported="true"  

让其他程序可以调用该Service

### 调用其他应用的APP ###
Android5.0之后,在调用其他应用的App时,需使用显示意图  
显示意图调用其他应用程序的Service,需给Intent设置  

	Intent intent = new Intent();	
	intent.setComponent(new ComponentName("包名", "包名.要调用的Service名称")); 
	startService(intent);
	//stopService(intent); 

## AIDL ##
用作与其他应用的通信
### 被启动程序的Service ###
需要新建一个AIDL  
在Service的onBind中返回这个AIDL接口的实现类  

    public IBinder onBind(Intent intent) {
        return new IAppServiceRemoteBinder.Stub() {
            @Override
            public void basicTypes(int anInt, long aLong, boolean aBoolean, float aFloat, double aDouble, String aString) throws RemoteException {

            }
        };
    }

### 调用其他应用的APP ###
实现ServiceConnection接口  

	@Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        Log.i(TAG, "zhk onServiceConnected");
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        Log.i(TAG, "zhk onServiceDisconnected");
    }

绑定外部Service  

	bindService(intent, this, Context.BIND_AUTO_CREATE);

解除绑定外部Service  

	unbindService(this);

### 两个通信 ###
为方便,约定被启动Service的程序为A,调用其他应用的APP的程序为B  

- 首先,需要在A中的AIDL中新建相应的方法  
- 在Service的onBind中返回其AIDL实现类  
- 在B中ServiceConnection接口的onServiceConnected方法中

	//binder = (IAppServiceRemoteBinder) service;   
	//因為兩個app的此類不是同一個類，所以不能這樣轉換  
	binder = IAppServiceRemoteBinder.Stub.asInterface(service);

- 然后即可使用  

如下所示,讲传递给A的Service中的onBind中的AIDL实现类的setData方法

	 if (binder!=null){
         try {
             binder.setData("改變后的數據");
         } catch (RemoteException e) {
              e.printStackTrace();
         }
     }

