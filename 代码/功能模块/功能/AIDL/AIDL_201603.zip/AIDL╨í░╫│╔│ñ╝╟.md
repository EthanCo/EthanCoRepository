# AIDL小白成长记 #
### AIDL ###
IPC(进程间通信) 多个应用程序，多线程
### Binder ###
只有IPC，没有多线程，多个应用程序
### Messenger ###
只有IPC，没有多线程

## AIDL默认支持的数据类型 ##
- 基本数据类型 (short除外)
- String,CharSequence
- List,Map
- Parcelable

## AIDL使用步骤 ##
1. 创建AIDL文件 (AS需要编译后才会生成)
2. 在Service端创建Service
3. 在Client端bindService，返回AIDL
4. 调用AIDL的方法