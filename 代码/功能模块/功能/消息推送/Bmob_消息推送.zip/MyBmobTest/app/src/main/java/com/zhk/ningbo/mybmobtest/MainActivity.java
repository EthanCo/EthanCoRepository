package com.zhk.ningbo.mybmobtest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import cn.bmob.push.BmobPush;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobInstallation;

/**
 * 具体看官方文档
 * http://docs.bmob.cn/android/developdoc/index.html?menukey=develop_doc&key=develop_android#index_消息推送
 *
 * 注意 :
 * 1.Manifest要注册自己的Receiver - 比如这里的 MyPushMessageReceiver
 * 2. Bmob.initialize(this, APK_KEY); 无论什么都是要先初始化的
   3. 操作网页进行推送之前，要先在网页那边设置一下包名
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String APK_KEY = "708e342f63504781188827595c30e711";
        // 初始化BmobSDK
        Bmob.initialize(this, APK_KEY); //这句话无论什么都要有

        // 使用推送服务时的初始化操作
        BmobInstallation.getCurrentInstallation(this).save();
        // 启动推送服务
        BmobPush.startWork(this, APK_KEY);
    }
}
