package com.example.mybarcodetest_jike;

import com.google.zxing.WriterException;
import com.zxing.activity.CaptureActivity;
import com.zxing.encoding.EncodingHandler;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/*
 * android.permission.CAMERA ����ͷ
 * android.permission.VIBRATE ��
 * */
public class MainActivity extends Activity {

	private Button btScan;
	private TextView tvInfo;
	private Button btCreateCode;
	private EditText etInputData;
	private ImageView ivBarCode;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		initView();
		initEvent();
	}
	
	private void initEvent() {
		//��������ά��ɨ��
		btScan.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this,CaptureActivity.class);
				startActivityForResult(intent, 100);
			}
		});
		btCreateCode.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = etInputData.getText().toString();
				if(str.equals("")){
					Toast.makeText(getApplicationContext(), "����������", Toast.LENGTH_SHORT).show();
				}else{
					try {
						Bitmap bitmap = EncodingHandler.createQRCode(str, 400);
						ivBarCode.setImageBitmap(bitmap);
					} catch (WriterException e) {
						e.printStackTrace();
					}
				}
			}
		});
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode==100&&resultCode==Activity.RESULT_OK){
			String res = data.getExtras().getString("result");
			tvInfo.setText(res);
		}
	}

	private void initView() {
		btScan = (Button)findViewById(R.id.bt_scan);
		tvInfo = (TextView)findViewById(R.id.tv_info);
		btCreateCode = (Button)findViewById(R.id.btCreateCode);
		etInputData = (EditText)findViewById(R.id.etInputData);
		ivBarCode = (ImageView)findViewById(R.id.ivBarCode);
	}
}
