package comzhk.mytwocode;

import comzhk.utils.BarCodeUtil;
import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/*
 * android.permission.CAMERA ����ͷȨ��
 * */
public class MainActivity extends Activity {
	private Button btShow;
	private ImageView ivCode;
	private EditText etInfo;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	
		initView();
		initEvent();
	}
	
	private void initEvent() {
		btShow.setOnClickListener(new OnClickListener() {			
			@Override
			public void onClick(View v) {
				String info =etInfo.getText().toString();
				if(info.equals("")){
					Toast.makeText(getApplicationContext(), "����������", Toast.LENGTH_SHORT).show();
				}else{
					BarCodeUtil util = new BarCodeUtil();
					Bitmap bitmap = util.createBarCode(info);
					if(bitmap!=null){
						ivCode.setImageBitmap(bitmap);
					}
				}
			}
		});
		}
	private void initView() {
		btShow = (Button)findViewById(R.id.bt_show);
		ivCode = (ImageView) findViewById(R.id.iv_code);
		etInfo = (EditText)findViewById(R.id.et_info);
	}
}
