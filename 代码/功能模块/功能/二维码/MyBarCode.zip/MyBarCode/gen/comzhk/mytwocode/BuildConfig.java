/** Automatically generated file. DO NOT MODIFY */
package comzhk.mytwocode;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}