package m4_OutputStream;

import java.io.FileOutputStream;
import java.io.IOException;

public class z1_FileOutputStream {
	public static void main(String[] args) throws IOException{
		FileOutputStream fos = new FileOutputStream("fos.txt");
		fos.write("fos content".getBytes());
		fos.close();
	}
}
