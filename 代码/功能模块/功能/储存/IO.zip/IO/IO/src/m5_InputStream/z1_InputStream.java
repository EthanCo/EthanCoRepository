package m5_InputStream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class z1_InputStream {
	public static void main(String[] args) throws IOException {
		// methed1();
		methed2();
		//methed3();
	}

	// ����ֽ��� ������ѭ�� //���� ���ݲ��Ǻܴ������ ���ݺܴ���ܻᷢ���ڴ�й¶
	private static void methed3() throws IOException {
		FileInputStream fis = new FileInputStream("fos.txt");
		byte[] buf = new byte[fis.available()];
		if (fis.read(buf) != -1) {
			System.out.println(new String(buf));
		}
	}

	private static void methed2() throws IOException {
		FileInputStream fis = new FileInputStream("fos.txt");
		byte[] buf = new byte[1024];
		int len = 0;
		while ((len = fis.read(buf)) != -1) {
			System.out.println(new String(buf, 0, len));
		}
		fis.close();
	}

	public static void methed1() throws IOException {
		FileInputStream fis = new FileInputStream("fos.txt");
		int ch = 0;
		while ((ch = fis.read()) != -1) {
			System.out.println((char) ch);
		}
		fis.close();
	}
}
