package m3_IOException;

import java.io.FileWriter;
import java.io.IOException;

//IO�쳣������ʽ
public class z1_Test {
	public static void main(String[] args) {
		FileWriter fw = null;
		try {
			fw = new FileWriter("demo.txt");
			fw.write("QWERTY");
			fw.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		}
	}
}
