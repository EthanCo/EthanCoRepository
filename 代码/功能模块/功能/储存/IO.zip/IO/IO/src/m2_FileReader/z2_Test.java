package m2_FileReader;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
 * �����ļ�
 *
 * */
public class z2_Test {
	public static void main(String[] args) throws IOException {
		cope1();
		cope2();
	}

	public static void cope1() throws IOException {
		// ����Ŀ�ĵ�
		FileWriter fw = new FileWriter("demo_cope.txt");

		// �������ļ�����
		FileReader fr = new FileReader("demo.txt");

		int ch = 0;
		while ((ch = fr.read()) != -1) {
			fw.write(ch);
		}

		fw.close();
		fr.close();
	}

	public static void cope2() {
		FileWriter fw = null;
		FileReader fr = null;

		try {
			// ����Ŀ�ĵ�
			fw = new FileWriter("demo_cope2.txt");

			// �������ļ�����
			fr = new FileReader("demo.txt");

			char[] buf = new char[1024];
			int num = 0;
			while ((num = fr.read(buf)) != -1) {
				fw.write(buf, 0, num);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
