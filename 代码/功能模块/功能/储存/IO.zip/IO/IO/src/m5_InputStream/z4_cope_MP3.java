package m5_InputStream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * ��ʾmp3�ĸ���.ͨ��������
 * BufferedOutputStream
 * BufferedInputStream
 * */
public class z4_cope_MP3 {
	public static void main(String[] args) throws IOException{
		long start = System.currentTimeMillis();
		cope1();
		long end = System.currentTimeMillis();
		System.out.println((end-start)+"����");
	}
	//ͨ���ֽ����Ļ�������ɸ���
	public static void cope1() throws IOException{
		BufferedInputStream bufis = new BufferedInputStream(new FileInputStream("Let Me Hear.mp3"));
		BufferedOutputStream bufos = new BufferedOutputStream(new FileOutputStream("Cope Of Let Me Hear.mp3"));
		 
		int by =0;
		
		while ((by=bufis.read())!=-1) {
			bufos.write(by);
		}
		bufis.close();
		bufos.close();
	}
}
