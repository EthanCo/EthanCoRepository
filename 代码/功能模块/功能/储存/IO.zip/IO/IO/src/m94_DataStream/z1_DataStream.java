package m94_DataStream;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/*
 * ����������������
 * */
public class z1_DataStream {
	public static void main(String[] args) throws IOException{
//		writeData();
//		readData();
		writeUTFDemo();
	}
	public static void writeData() throws IOException{
		DataOutputStream dos = new DataOutputStream(new FileOutputStream("data.txt"));
		dos.writeInt(234);
		dos.writeBoolean(true);
		dos.writeDouble(9.66);
		
		dos.close();
	}
	public static void readData() throws IOException{
		DataInputStream dis = new DataInputStream(new FileInputStream("data.txt"));
		int num = dis.readInt();
		boolean b = dis.readBoolean();
		double d = dis.readDouble();
		System.out.println(""+num+b+d);
	}
	
	public static void writeUTFDemo() throws IOException{
		/*
		 * ��ͨ��ָ������д��
		OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream("utf.txt"), "utf-8");
		osw.write("���");
		osw.close();
		*/
		//��������ķ���дutf,��ֻ���ö�Ӧ�ķ���������
		DataOutputStream dos = new DataOutputStream(new FileOutputStream("utfdata.txt"));
		dos.writeUTF("���");
		dos.close();
	}
	public static void readUTFDemo() throws IOException{
		DataInputStream dis = new DataInputStream(new FileInputStream("utfdata.txt"));
		String s = dis.readUTF();
		System.out.println(s);
	}
}
