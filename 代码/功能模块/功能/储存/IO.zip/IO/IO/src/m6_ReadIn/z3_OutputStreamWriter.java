package m6_ReadIn;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/*
 *ת���� ����ָ������
 * �ֽ������ת��Ϊ�ַ������
 * */
public class z3_OutputStreamWriter {
	public static void main(String[] args) throws IOException{
//		OutputStream os = System.out;
//		OutputStreamWriter osw = new OutputStreamWriter(os);
//		osw.write("abc"); //û����
////		osw.flush();
//		BufferedWriter bufw = new BufferedWriter(osw);
//		bufw.write("PPPP");
//		bufw.newLine();
//		bufw.write("LLLL");
//		bufw.close();
////		osw.close();

		
		BufferedWriter bufw2 = 
				new BufferedWriter(new OutputStreamWriter(System.out));
		bufw2.write("UUUU");
		bufw2.newLine();
		bufw2.write("YYYY");
		bufw2.flush();
		bufw2.close();
	}
}
