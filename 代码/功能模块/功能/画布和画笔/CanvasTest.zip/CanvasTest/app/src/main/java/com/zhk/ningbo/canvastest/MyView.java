package com.zhk.ningbo.canvastest;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by Administrator on 2015/8/4.
 */
public class MyView extends View {

    private Bitmap bitmap;

    public MyView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public MyView(Context context) {
        this(context, null);
    }

    public MyView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Paint paint = new Paint();
        paint.setColor(0xFF0099CC);
        paint.setTextSize(20);
        //paint.setStyle(Paint.Style.STROKE); // 风格: 实心、空心等

        //写字
        canvas.drawText("你好test123", 0, 20, paint);
        //画线
        canvas.drawLine(0, 40, 150, 40, paint);
        //画矩形
        canvas.drawRect(0, 60, 150, 140, paint);
        //画矩形 通过Rect
        Rect r = new Rect(0, 150, 150, 200);
        canvas.drawRect(r, paint);
        //画矩形 通过rectF
        RectF rectF = new RectF(0, 210, 150, 260);
        //canvas.drawRect(rectF, paint);
        //画圆角矩形
        canvas.drawRoundRect(rectF, 10, 10, paint);
        //画圆形
        canvas.drawCircle(50, 350, 50, paint); //cx：圆心的x坐标。cy：圆心的y坐标。radius：圆的半径。
        //绘制图片
        bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
        canvas.drawBitmap(bitmap, 200, 50, paint);

        RectF rectF3 = new RectF(200, 300, 300, 400);
        canvas.drawArc(rectF3, 0, 60, false, paint);//oval :指定圆弧的外轮廓矩形区域。 startAngle: 圆弧起始角度，单位为度。
        // sweepAngle: 圆弧扫过的角度，顺时针方向，单位为度。useCenter: 如果为True时，在绘制圆弧时将圆心包括在内，通常用来绘制扇形。
    }
}
