package com.EthanCool.myserialporttest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import android_serialport_api.SerialPort;

public class MainActivity extends Activity {

	private SerialPort sPort;
	private FileInputStream input;
	private FileOutputStream output;

	File device = new File("/dev/ttyS1");
	int baudrate = 9600; // 波特率
	int falgs = 0;
	private boolean continueRead = true;
	private EditText reciveEt;
	private EditText sendEt;
	private Button btnSend;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initSerialPort();
		initView();
		initEvent();
		initSpRead();
	}

	private void initEvent() {
		btnSend.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				sendData(sendEt.getText().toString());
				sendEt.setText("");
			}
		});
	}

	private void sendData(String data) {
		if (sPort != null) {
			try {
				output.write(new String(data).getBytes());
				// output.write('\n');
				output.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
			Toast.makeText(MainActivity.this, "发送数据成功", Toast.LENGTH_SHORT).show();
		}
	}

	private void initView() {
		reciveEt = (EditText) findViewById(R.id.et_recive);
		sendEt = (EditText) findViewById(R.id.et_send);
		btnSend = (Button) findViewById(R.id.btn_send);
	}

	private void initSpRead() {
		if (sPort != null && input != null) {
			new Thread() {
				public void run() {
					int len;
					while (continueRead) {
						try {
							byte[] buffer = new byte[64];
							if (input == null)
								return;
							len = input.read(buffer);
							if (len > 0) {
								onDataReceived(buffer, len);
							}
						} catch (IOException e) {
							e.printStackTrace();
							return;
						}
					}
				};
			}.start();
		}
	}

	private void initSerialPort() {
		try {
			sPort = new SerialPort(device, baudrate, falgs);
			input = (FileInputStream) sPort.getInputStream();
			output = (FileOutputStream) sPort.getOutputStream();
		} catch (SecurityException | IOException e) {
			e.printStackTrace();
		}
		Toast.makeText(MainActivity.this, "打开串口成功", Toast.LENGTH_SHORT).show();
	}

	void onDataReceived(final byte[] buffer, final int size) {
		runOnUiThread(new Runnable() {
			public void run() {
				if (reciveEt != null) {
					reciveEt.append(new String(buffer, 0, size));
				}
			}
		});
	}

	@Override
	protected void onDestroy() {
		continueRead = false;
		sPort.close();
		sPort = null;
		super.onDestroy();
	}
}
