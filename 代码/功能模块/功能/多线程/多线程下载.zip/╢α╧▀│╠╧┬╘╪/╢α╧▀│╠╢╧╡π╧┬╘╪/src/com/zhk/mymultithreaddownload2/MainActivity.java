package com.zhk.mymultithreaddownload2;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.zhk.dao.DownloadDao;
import com.zhk.mymultithreaddownload2.DownLoadManager;

public class MainActivity extends Activity {

	private static final int ERROR_DOWNLOAD=0;
	private static final int SET_PROGRESS_MAX=1;
	private static final int UPDATE_PROGRESS=2;
	
	private DownLoadManager manager;
	
	private ProgressBar pb;
	private TextView tvInfo;
	private EditText etPath;
	private DownloadDao dao;
	
	Handler mHandler = new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case ERROR_DOWNLOAD:
				Toast.makeText(getApplicationContext(), "����ʧ��", Toast.LENGTH_LONG).show();
				break;
			case SET_PROGRESS_MAX:
				int max = (Integer)msg.obj;
				pb.setMax(max);
				break;
			case UPDATE_PROGRESS:
				int length = (Integer)msg.obj; //�����صĳ���
				int existProgress = pb.getProgress(); //�õ���ǰ�����ؿ̶�
				int progress = existProgress+length;
				pb.setProgress(progress);
				
				int maxProgress = pb.getMax();
				float value = (float)progress/(float)maxProgress;
				int precent = (int)(value*100);
				tvInfo.setText("���أ�"+precent+"%");
				
				if(maxProgress == progress){
					//ɾ�����ؼ�¼
					dao.delete(etPath.getText().toString());
				}
				break;
			default:
				break;
			}
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		etPath = (EditText)findViewById(R.id.et_path);
		tvInfo = (TextView)findViewById(R.id.tv_info);
		pb = (ProgressBar)findViewById(R.id.pb);
		
		manager = new DownLoadManager(this);
		dao = new DownloadDao(this);
	}
	
	public void download(View v){
		final String path = etPath.getText().toString();
		//���� ��һ����ʱ�Ĳ���,Ӧ�÷��������߳�
		new Thread(){

			public void run() {
				try {
					manager.download(path, new ProgressBarListener() {

						@Override
						public void getMax(int length) {
							Message msg = new Message();
							msg.what = SET_PROGRESS_MAX;
							msg.obj = length;
							mHandler.sendMessage(msg);
						}

						@Override
						public void getDownload(int length) {
							Message msg = new Message();
							msg.what = UPDATE_PROGRESS;
							msg.obj = length;
							mHandler.sendMessage(msg);
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
					Message msg = new Message();
					msg.what = ERROR_DOWNLOAD;
					mHandler.sendMessage(msg);
				}
			}
		}.start();
	}
	}
