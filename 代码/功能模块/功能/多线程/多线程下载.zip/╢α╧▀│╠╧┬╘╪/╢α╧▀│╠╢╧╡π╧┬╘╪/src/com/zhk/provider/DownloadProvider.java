package com.zhk.provider;

import com.zhk.db.DownloadDBHelper;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.util.Log;

public class DownloadProvider extends ContentProvider {

	private static UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);
	private final static String authrity="zhe.xiangdangyu.yige.yuming";
	private final static int DOWNLOAD=10;
	static{
		matcher.addURI(authrity, "download", DOWNLOAD);
	}
//	private SQLiteOpenHelper mOpenHelper;
private SQLiteOpenHelper mOpenHelper;
	
	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		mOpenHelper = new DownloadDBHelper(getContext());
		return false;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		Cursor ret = null;
		SQLiteDatabase db = mOpenHelper.getReadableDatabase();
		int code = matcher.match(uri);
		switch (code) {
		case DOWNLOAD:
			Log.i("log.i", "query");
			ret = db.query("download", projection, selection, selectionArgs, null, null, sortOrder);
			break;

		default:
			break;
		}
		return ret;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		int code = matcher.match(uri);
		switch (code) {
		case DOWNLOAD:
			Log.i("log.i", "insert");
			db.insert("download", "_id", values);
			break;

		default:
			break;
		}
		return null;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		int code = matcher.match(uri);
		switch (code) {
		case DOWNLOAD:
			db.delete("download", selection, selectionArgs);
			break;

		default:
			break;
		}
		return 0;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		int code = matcher.match(uri);
		switch (code) {
		case DOWNLOAD:
			System.out.println("update");
			db.update("download", values, selection, selectionArgs);
			break;

		default:
			break;
		}
		return 0;
	}
//	@Override
//	public boolean onCreate() {
//		mOpenHelper = new DownloadDBHelper(getContext());
//		return false;
//	}
//
//	@Override
//	public Cursor query(Uri uri, String[] projection, String selection,
//			String[] selectionArgs, String sortOrder) {
//		Cursor ret = null;
//		SQLiteDatabase db = mOpenHelper.getReadableDatabase();
//		int code = matcher.match(uri);
//		switch (code) {
//		case DOWNLOAD:
//			ret = db.query("download", projection, selection, selectionArgs, null, null, sortOrder);
//			break;
//
//		default:
//			break;
//		}
//		return ret;
//	}
//
//	@Override
//	public String getType(Uri uri) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Uri insert(Uri uri, ContentValues values) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public int delete(Uri uri, String selection, String[] selectionArgs) {
//		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
//		int code = matcher.match(uri);
//		switch (code) {
//		case DOWNLOAD:
//			db.delete("download", selection, selectionArgs);
//			break;
//
//		default:
//			break;
//		}
//		return 0;
//	}
//
//	@Override
//	public int update(Uri uri, ContentValues values, String selection,
//			String[] selectionArgs) {
//		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
//		int code = matcher.match(uri);
//		switch (code) {
//		case DOWNLOAD:
//			db.update("download", values, selection, selectionArgs);
//			break;
//
//		default:
//			break;
//		}
//		return 0;
//	}

}
