package com.zhk.dao;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import com.zhk.domain.DownloadInfo;

//public class DownloadDao {
//	
//	private ContentResolver cr;
//	
//	public DownloadDao(Context context){
//		cr = context.getContentResolver();
//	}
//	
//	//�������ؼ�¼
//	public void save(DownloadInfo info){
//		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
//		ContentValues values = new ContentValues();
//		values.put("path", info.getPath());
//		values.put("threadid", info.getThreadid());
//		cr.insert(uri, values);
//	}
//	
//	//�������ؼ�¼
//	public void update(DownloadInfo info){
//		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
//		ContentValues values = new ContentValues();
//		values.put("downloadlength", info.getDownloadsize());
//		cr.update(uri, values, "path =? threadid =?",new String[]{info.getPath(),info.getThreadid()+""} );
//	}
//	
//	//ɾ�����ؼ�¼
//	public void delete(String path){
//		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
//		ContentValues values = new ContentValues();
//		cr.delete(uri, "path =?", new String[]{path});
//	}
//	
//	//�ж����ؼ�¼�Ƿ����
//	public boolean isExist(String path){
//		boolean isExist = false;
//		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
//		Cursor cursor = cr.query(uri, null, "path = ?", new String []{path}, null); //null:����
//		if(cursor.moveToFirst()){
//			isExist = true;
//		}
//		cursor.close();
//		return isExist;
//	}
//	
//	//�������е����س���
//	public int queryCount(String path){
//		int count =0;
//		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
//		Cursor cursor = cr.query(uri, new String[]{"downloadlength"},
//				"path = ?",new String []{path}, null); //null:����
//		if(cursor.moveToNext()){
//			int length =cursor.getInt(0);
//			count=count+length;
//		}
//		cursor.close();
//		return count;
//	}
//	
//	//�õ�ÿ���߳�������
//	public int query(DownloadInfo info){
////		int count =0;
////		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
////		Cursor cursor = cr.query(uri, new String[]{"downloadlength"},
////				"path = ? and threadid =?",new String []{info.getPath(),info.getThreadid()+""}, null); //null:����
////		if(cursor.moveToNext()){
////			count =cursor.getInt(0);
////		}
////		cursor.close();
////		return count;
//		int count = 0;
//		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
//		Cursor c = cr.query(uri, new String[]{"downloadlength"}, " path = ? and threadid = ?", new String[]{info.getPath(),info.getThreadid()+""}, null);
//		if(c.moveToNext()){
//			count = c.getInt(0);
//		}
//		c.close();
//		return count;
//	}
//}

public class DownloadDao {

	private ContentResolver cr;
	
	public DownloadDao(Context context) {
		// TODO Auto-generated constructor stub
		cr = context.getContentResolver();
	}
	
	//�������ؼ�¼
	public void save(DownloadInfo info){
		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
		ContentValues values = new ContentValues();
		values.put("path", info.getPath());
		values.put("threadid", info.getThreadid());
		Log.i("log.i", "save"+info.getPath()+info.getThreadid()+"");
		cr.insert(uri, values);
	}
	
	//�������ؼ�¼
	public void update(DownloadInfo info){
		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
		ContentValues values = new ContentValues();
		values.put("downloadlength", info.getDownloadsize());
		Log.i("update", info.getPath()+info.getThreadid()+"");
		cr.update(uri, values, " path = ? and threadid = ? ", new String[]{info.getPath(),info.getThreadid()+""});
	}
//	//�������ؼ�¼
//	public void update(DownloadInfo info){
//		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
//		ContentValues values = new ContentValues();
//		values.put("downloadlength", info.getDownloadsize());
//		cr.update(uri, values, "path =? threadid =?",new String[]{info.getPath(),info.getThreadid()+""} );
//	}
	
	//ɾ�����ؼ�¼
	public void delete(String path){
		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
		cr.delete(uri, " path = ?", new String[]{path});
	}
	
	//�ж����ؼ�¼�Ƿ����
	public boolean isExist(String path){
		boolean isExist = false;
		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
		Cursor c = cr.query(uri, null, " path = ? ", new String[]{path}, null);
		if(c.moveToFirst()){
			isExist = true;
		}
		c.close();
		return isExist;
	}
	
	//�������е����س���
	public int queryCount(String path){
		int count = 0;
		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
		Cursor c = cr.query(uri, new String[]{"downloadlength"}, " path = ? ", new String[]{path}, null);
        while(c.moveToNext()){
        	int length = c.getInt(0);
        	count = count + length;
        }
		c.close();
		return count;
	}
	
	//�õ�ÿ���߳����ص�������
	public int query(DownloadInfo info){
		int count = 0;
		Uri uri = Uri.parse("content://zhe.xiangdangyu.yige.yuming/download");
		Cursor c = cr.query(uri, new String[]{"downloadlength"}, " path = ? and threadid = ?", new String[]{info.getPath(),info.getThreadid()+""}, null);
		if(c.moveToNext()){
			count = c.getInt(0);
		}
		c.close();
		return count;
	}	
}
