package com.example.MyMulti;

import com.example.MyMultiThreadDownload.R;
import com.example.download.MyDownloadManager;
import com.example.inter.ProgressBarListener;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {
	/*
	 *  ע�������Ȩ�� ���� дSD��
	 */
	private static final int ERROR_DOWNLOAD=0;
	private static final int SET_PROGRESS_MAX=1;
	private static final int UPDATE_PROGRESS=2;
	
	private ProgressBar pb;
	private EditText et_path;
	private TextView tv_info;
	private MyDownloadManager manager;
	
	private Handler mHandler = new Handler(){
		public void handleMessage(Message msg) {
			switch(msg.what){
			case ERROR_DOWNLOAD:
				Toast.makeText(getApplicationContext(), "����ʧ��", Toast.LENGTH_LONG).show();
				break;
			case SET_PROGRESS_MAX:
				int max =(Integer)msg.obj;
				pb.setMax(max);
				break;
			case UPDATE_PROGRESS:
				int length = (Integer)msg.obj; //�����صĳ���
				int existProgress = pb.getProgress(); //�õ���ǰ�����ؿ̶�
				int progress = existProgress+length;
				pb.setProgress(progress);
				
				int maxProgress = pb.getMax();
				float value = (float)progress/(float)maxProgress;
				int precent = (int)(value*100);
				tv_info.setText("���أ�"+precent+"%");
				break;
				default:
					break;
			}
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		pb =(ProgressBar) findViewById(R.id.pb);
		et_path =(EditText) findViewById(R.id.et_path);
		tv_info =(TextView) findViewById(R.id.tv_info);
		
		manager = new MyDownloadManager();
	}
	
	public void download(View v){
		final String path = et_path.getText().toString();
		//���� ��һ����ʱ�Ĳ���,Ӧ�÷��������߳�
		new Thread(){

			public void run() {
				try {
					manager.download(path, new ProgressBarListener() {

						@Override
						public void getMax(int length) {
							Message msg = new Message();
							msg.what = SET_PROGRESS_MAX;
							msg.obj = length;
							mHandler.sendMessage(msg);
						}

						@Override
						public void getDownload(int length) {
							Message msg = new Message();
							msg.what = UPDATE_PROGRESS;
							msg.obj = length;
							mHandler.sendMessage(msg);
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
					Message msg = new Message();
					msg.what = ERROR_DOWNLOAD;
					mHandler.sendMessage(msg);
				}
			}
		}.start();
	}
}
