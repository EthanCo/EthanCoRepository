public class MainActivity extends ActionBarActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        //�ҵ���ť
        Button btn = (Button) findViewById(R.id.btn);
        //���Ӽ�����
        btn.setOnClickListener(new MyOnClickListener());
    }
    
    private class MyOnClickListener implements OnClickListener
    {
			public void onClick(View v) {
			
			}
 }