public class MainActivity extends ActionBarActivity implements OnClickListener{
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        //�ҵ���ť
        Button btn = (Button) findViewById(R.id.btn);
        //���Ӽ�����
        btn.setOnClickListener(this);
    }
    
		public void onClick(View v) {
			//
		}
}