package com.zhk.alarmtest;

import java.util.Calendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {

	private Button setTime;
	private AlarmManager alarm;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//获取按钮
		setTime = (Button)findViewById(R.id.setTime);
		//获取AlarmManager对象
		alarm = (AlarmManager)getSystemService(Service.ALARM_SERVICE);
		
		//设置点击事件
		setTime.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Calendar currentTime = Calendar.getInstance();

				new TimePickerDialog(MainActivity.this, 0 , new OnTimeSetListener() {
					public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
								// 指定启动AlarmActivity组件
								// 创建PendingIntent对象
								// 方法一 直接唤醒AlarmActivity, 这个不需要AlarmReceiver
								// Intent intent = new Intent(MainActivity.this,
								// AlarmActivity.class);
								// PendingIntent pi = PendingIntent.getActivity(
								// MainActivity.this, 0, intent, 0);

								// 方法二 用broadcast接收 从而启动AlarmActivity
								Intent intent = new Intent(MainActivity.this,
										AlarmReceiver.class);
								PendingIntent pi = PendingIntent.getBroadcast(
										MainActivity.this, 0, intent, 0);

								Calendar c = Calendar.getInstance();
								c.setTimeInMillis(System.currentTimeMillis());
								// 根据用户选择事件来设置Calendar对象
								c.set(Calendar.HOUR_OF_DAY, hourOfDay);
								c.set(Calendar.MINUTE, minute);
								// 设置AlarmManager将在Calendar对应的事件启动指定组件
								alarm.set(AlarmManager.RTC_WAKEUP,
										c.getTimeInMillis(), pi);
								// 1.模式
								// 2.时间
								// 3.事件(做什么)
								Toast.makeText(MainActivity.this, "闹铃设置成功",
										Toast.LENGTH_LONG).show();
					}
				}, currentTime.get(Calendar.HOUR_OF_DAY), currentTime.get(Calendar.MINUTE), false).show();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
