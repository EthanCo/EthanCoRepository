package cn.itcast.junit.test;

import junit.framework.Assert;
import cn.itcast.junit.Service;
import android.test.AndroidTestCase;

public class MyTest extends AndroidTestCase {

	public void test1() {
		Service service = new Service();
		Assert.assertEquals(5, service.divide(10, 2));
	}
	
	public void test2() {
		Service service = new Service();
		System.out.println(service.divide(10, 0));
	}
	
	public void test3() {
		Service service = new Service();
		Assert.assertEquals(3.3333, service.divide(10, 3));
	}
	
	public void test4() {
		Service service = new Service();
		Assert.assertEquals(2.5, service.divide(10, 4));
	}
	
}
