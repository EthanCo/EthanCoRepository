﻿using UnityEngine;
using System.Collections;

public class Test : MonoBehaviour {
	

	// Update is called once per frame
	void Update () {
	
	}

	void OnGUI()
	{
		if (GUILayout.Button ("init", GUILayout.Height (100))) {
		
			AndroidJavaClass jc =new AndroidJavaClass("com.unity3d.player.UnityPlayer");
			AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity");   
			jo.Call("initfunc");  
		}

		if (GUILayout.Button ("recognizer", GUILayout.Height (100))) {
			
			AndroidJavaClass jc =new AndroidJavaClass("com.unity3d.player.UnityPlayer");
			AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity");   
			jo.Call("startRecognizerfuc");  
		}
		}
}
