package com.xyz;

import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.RecognizerListener;
import com.iflytek.cloud.RecognizerResult;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechRecognizer;
import com.iflytek.cloud.SpeechUtility;
import com.unity3d.player.UnityPlayerActivity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

public class UnityTestActivity extends UnityPlayerActivity {
	
	public SpeechRecognizer mspeech;
	public InitListener mInitListener = new InitListener(){

		@Override
		public void onInit(int arg0) {
			// TODO Auto-generated method stub
			Log.d("test", "init code:"+arg0);
		}
		
	};
	
	public RecognizerListener mRecognizerListener = new RecognizerListener(){

		@Override
		public void onBeginOfSpeech() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onEndOfSpeech() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onError(SpeechError arg0) {
			// TODO Auto-generated method stub
			Log.d("test", "error:"+arg0.getErrorCode());
		}

		@Override
		public void onEvent(int arg0, int arg1, int arg2, Bundle arg3) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onResult(RecognizerResult results, boolean arg1) {
			// TODO Auto-generated method stub
			Log.d("test", results.getResultString());
		}

		@Override
		public void onVolumeChanged(int v) {
			// TODO Auto-generated method stub
			Log.d("test", "v:"+v);
		}
		
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		SpeechUtility.createUtility(getApplicationContext(), "appid=51e8ae25");
	}
	
	public void initfunc()
	{
		mspeech = SpeechRecognizer.createRecognizer(getApplicationContext(), mInitListener);
		Log.d("test", "init s!");
	}
	
	public void startRecognizerfuc(){
		mspeech.setParameter(SpeechConstant.DOMAIN, "iat");
		mspeech.setParameter(SpeechConstant.LANGUAGE, "zh_cn");
		mspeech.setParameter(SpeechConstant.ACCENT, "mandarin");
		mspeech.startListening(mRecognizerListener);
	}
}
