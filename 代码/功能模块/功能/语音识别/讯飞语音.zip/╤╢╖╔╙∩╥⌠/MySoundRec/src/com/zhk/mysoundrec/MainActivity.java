package com.zhk.mysoundrec;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

/*
 * android.permission.ACCESS_FINE_LOCATION ���λ��
 * android.permission.WRITE_EXTERNAL_STORAGE ��дSD��
 * android.permission.MOUNT_UNMOUNT_FILESYSTEMS SD���Ƿ���ڼ�������ѯ
 * */
public class MainActivity extends Activity {

	private Button btnSound;
	public static final int REQUEST_CODE_DOUND_REQ = 100;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		btnSound = (Button) findViewById(R.id.btnSound);
		btnSound.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				try {
					Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
					startActivityForResult(i, REQUEST_CODE_DOUND_REQ);
				} catch (Exception e) {
					new AlertDialog.Builder(MainActivity.this)
						.setTitle("NotFound")
						.setMessage("û���ҵ��ȸ�����ʶ��ģ��,�Ƿ�װ��")
						.setPositiveButton("��",new dialogclick()).setNegativeButton("��", null)
						.create()
						.show();
				}
			}
		});
	}
	
	public class dialogclick implements DialogInterface.OnClickListener{

		@Override
		public void onClick(DialogInterface dialog, int which) {
			
			//��assets�ļ����µ�xunfeiyuyin.apk���Ƶ�sd��Ŀ¼��,�ٰ�װ
			FileOutputStream out = null;
			InputStream in = null;
			try {
				// ��ȡ������
				in = getAssets()
						.open("xunfeiyuyin.apk"); //assetsĿ¼
				// ��ȡ�����ļ���Ŀ¼
				File dir = Environment
						.getExternalStorageDirectory();
				File file = new File(dir,
						"/xunfeiyuyin.apk");
				out = new FileOutputStream(file);
				int len;
				byte[] buf = new byte[1024];
				while ((len = in.read(buf)) != -1) {
					out.write(buf, 0, len);
				}
				Intent i = new Intent();
				// ��������ģʽ
				i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				//
				i.setAction(android.content.Intent.ACTION_VIEW);
				i.setDataAndType(Uri.fromFile(file),
						"application/vnd.android.package-archive");
				startActivity(i);
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (out != null) {
						out.close();
					}
					if (in != null) {
						in.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK) {
			switch (requestCode) {
			case REQUEST_CODE_DOUND_REQ:
				ArrayList<String> speeks = null;
				speeks = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
				TextView mTv = (TextView) findViewById(R.id.tvSpeek);
				mTv.setText(speeks.get(0));
				break;
			default:
				break;
			}
		}
	}
}
