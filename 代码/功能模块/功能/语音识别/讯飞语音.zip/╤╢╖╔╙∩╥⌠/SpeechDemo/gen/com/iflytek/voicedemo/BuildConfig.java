/** Automatically generated file. DO NOT MODIFY */
package com.iflytek.voicedemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}