package com.zhk.testspeak;

import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechRecognizer;
import com.iflytek.cloud.SpeechUtility;
import com.iflytek.cloud.ui.RecognizerDialog;
import com.iflytek.cloud.ui.RecognizerDialogListener;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class VoiceToTextUtils {
	private Context mContext;
	private RecognizerDialog iatDialog;
	private SpeechRecognizer mIat;
	private RecognizerDialogListener recognizerDialogListener;//��дUI������

	public VoiceToTextUtils(Context context, RecognizerDialogListener listener) {
		this.mContext = context;
		this.recognizerDialogListener = listener;

		init();
	}

	private void init() {
		SpeechUtility.createUtility(mContext, SpeechConstant.APPID + "=54fd9f36");
		iatDialog = new RecognizerDialog(mContext, mInitListener);

		mIat = SpeechRecognizer.createRecognizer(mContext, mInitListener);
		mIat.setParameter(SpeechConstant.DOMAIN, "iat"); // ���� һ��ֻʹ��iat�Ϳ�����
		mIat.setParameter(SpeechConstant.LANGUAGE, "zh_cn");// ���� en_us Ӣ��
		mIat.setParameter(SpeechConstant.ACCENT, "mandarin");// ����
		mIat.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_CLOUD);
	}

	/**
	 * ��ʼ����������
	 */
	private InitListener mInitListener = new InitListener() {

		@Override
		public void onInit(int code) {
			Log.d("log.i", "SpeechRecognizer init() code = " + code);
			if (code != ErrorCode.SUCCESS) {
//				tip.show("��ʼ��ʧ��,�����룺" + code);
				Toast.makeText(mContext,"��ʼ��ʧ��,�����룺" + code ,Toast.LENGTH_SHORT).show();
			}
		}
	};

	public void Rec() {
		// ��ʾ��д�Ի���
		iatDialog.setListener(recognizerDialogListener);
		iatDialog.show();
	}
}
