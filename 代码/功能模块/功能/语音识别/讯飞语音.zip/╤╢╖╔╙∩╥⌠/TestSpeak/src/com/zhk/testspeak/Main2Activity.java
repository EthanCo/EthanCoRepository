package com.zhk.testspeak;

import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.RecognizerResult;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechRecognizer;
import com.iflytek.cloud.SpeechUtility;
import com.iflytek.cloud.ui.RecognizerDialog;
import com.iflytek.cloud.ui.RecognizerDialogListener;
import com.iflytek.speech.UtilityConfig;

import android.app.Activity;
import android.graphics.Shader.TileMode;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class Main2Activity extends Activity {

	private TextView tv;
	private RecognizerDialog iatDialog;
	private SpeechRecognizer mIat;
	private VoiceToTextUtils utils;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initView();
		initEvent();

	}

	private void initEvent() {
		// TODO Auto-generated method stub
	}

	private void initView() {

		tv = (TextView) findViewById(R.id.tv);
		tv.setText("xxx");
		
		utils = new VoiceToTextUtils(this, recognizerDialogListener);
//		iatDialog = new RecognizerDialog(this, mInitListener);
	}

	public void mclick(View v) {
		// ��ʾ��д�Ի���
//		iatDialog.setListener(recognizerDialogListener);
//		iatDialog.show();
		utils.Rec();
	}
	
	/**
	 * ��дUI������
	 */
	private RecognizerDialogListener recognizerDialogListener = new RecognizerDialogListener() {

		@Override
		public void onResult(RecognizerResult results, boolean arg1) {
//			String text = JsonParser.parseIatResult(results.getResultString());
//			tv.append(text);
		}

		@Override
		public void onError(SpeechError error) {
//			showTip(error.getPlainDescription(true));
		}
	};

	/**
	 * ��ʼ����������
	 */
	private InitListener mInitListener = new InitListener() {

		@Override
		public void onInit(int code) {
			Log.d("log.i", "SpeechRecognizer init() code = " + code);
			if (code != ErrorCode.SUCCESS) {
//				showTip("��ʼ��ʧ��,�����룺" + code);
			}
		}
	};
}
