package com.zhk.com.asrlibrary;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.baidu.speech.VoiceRecognitionService;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * 语音识别工具类
 * Created by YOLANDA on 2015/9/11
 */
public class AsrUtils implements RecognitionListener, View.OnTouchListener {
    private Activity mContext;
    private static final String TAG = "zhkBaiduAsr";
    private static final int EVENT_ERROR = 11;
    private static SpeechRecognizer speechRecognizer;
    private long speechEndTime = -1;
    View speechTips;
    View speechWave;
    private TextView mView;

    public AsrUtils(Activity context) {
        this.mContext = context;
        speechTips = View.inflate(context, R.layout.bd_asr_popup_speech, null);
        speechWave = speechTips.findViewById(R.id.wave);
        speechTips.setVisibility(View.GONE);
        mContext.addContentView(speechTips, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        if (speechRecognizer == null) {
            initSpeechRecognizer(context);
        }
        speechRecognizer.setRecognitionListener(this);
    }

    /**
     * 初始化全局的speechRecognizer
     *
     * @param context
     */
    public static void initSpeechRecognizer(Context context) {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.getApplicationContext(),
                new ComponentName(context.getApplicationContext(), VoiceRecognitionService.class));
    }

    /**
     * 销毁speechRecognizer
     */
    public static void destorySpeeckRecognizer() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
    }

    @Override //准备就绪 只有当此方法回调之后才能开始说话，否则会影响识别效果

    public void onReadyForSpeech(Bundle params) {

    }

    @Override //开始说话 当用户开始说话后，将会回调此方法
    public void onBeginningOfSpeech() {

    }

    @Override //音量变化 引擎将对每一帧语音进行回调一次改方法
    public void onRmsChanged(float rmsdB) {
        final int VTAG = 0xFF00AA01;
        Integer rawHeight = (Integer) speechWave.getTag(VTAG);
        if (rawHeight == null) {
            rawHeight = speechWave.getLayoutParams().height;
            speechWave.setTag(VTAG, rawHeight);
        }

        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) speechWave
                .getLayoutParams();
        params.height = (int) (rawHeight * rmsdB * 0.01);
        params.height = Math.max(params.height, speechWave.getMeasuredWidth());
        speechWave.setLayoutParams(params);
    }

    @Override //原始语音 此方法会被回调多次，buffer 是当前帧对应的 PCM 语音数据，拼接后可得到完整的录音数据
    public void onBufferReceived(byte[] buffer) {

    }

    @Override //说话结束 当用户停止说话后，将会回调此方法
    public void onEndOfSpeech() {

    }

    @Override // 识别出错 错误码详见错误码一节（注意：识别出错将不再回调 onResults 方法）
    public void onError(int error) {
        asrListener.onError(error);
        StringBuilder sb = new StringBuilder();
        sb.append(ErrorFactory.createError(error));
        sb.append(":" + error);
        print("识别失败：" + sb.toString());
    }

    @Override //识别结果 识别结果中包含：识别结果、原始结果等，具体见文档
    public void onResults(Bundle results) {
        long end2finish = System.currentTimeMillis() - speechEndTime;
        ArrayList<String> nbest = results
                .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        print("识别成功："
                + Arrays.toString(nbest.toArray(new String[nbest.size()])));
        String json_res = results.getString("origin_result");
        try {
            print("origin_result=\n" + new JSONObject(json_res).toString(4));
        } catch (Exception e) {
            print("origin_result=[warning: bad json]\n" + json_res);
        }
//        btn.setText("开始");
        //mView.setText(R.string.start);
        String strEnd2Finish = "";
        if (end2finish < 60 * 1000) {
            strEnd2Finish = "(waited " + end2finish + "ms)";
        }
//        txtResult.setText(nbest.get(0) + strEnd2Finish);
        returnistener.onResult(nbest.get(0) + strEnd2Finish);
    }

    @Override //临时结果 在最终识别结果返回前，可能会收到多个临时识别结果
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> nbest = partialResults
                .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (nbest.size() > 0) {
            print("~临时识别结果：" + Arrays.toString(nbest.toArray(new String[0])));
//            txtResult.setText(nbest.get(0));
            returnistener.onResult(nbest.get(0));
        }
    }

    @Override //识别事件
    public void onEvent(int eventType, Bundle params) {
        switch (eventType) {
            case EVENT_ERROR:
                String reason = params.get("reason") + "";
                print("EVENT_ERROR, " + reason);
                break;
        }
    }

    private void print(String msg) {
//        txtLog.append(msg + "\n");
//        ScrollView sv = (ScrollView) txtLog.getParent();
        returnistener.onLog(msg + "\n");
        //sv.smoothScrollTo(0, 1000000);
        Log.d(TAG, "----" + msg);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                speechTips.setVisibility(View.VISIBLE);
                speechRecognizer.cancel();
                Intent intent = new Intent();
                //bindParams(intent);
                intent.putExtra("vad", "touch");
//                txtResult.setText("");
//                txtLog.setText("");
                returnistener.onResult("");
                returnistener.onLog("");
                speechRecognizer.startListening(intent);
                asrListener.onAsrStart();
                return true;
            case MotionEvent.ACTION_UP:
                speechRecognizer.stopListening();
                speechTips.setVisibility(View.GONE);
                asrListener.onAsrfinish();
                break;
        }
        return false;
    }

    /**
     * 停止语音识别
     */
    public void stop() {
        speechRecognizer.stopListening();
    }

    public interface onReturnListener {
        void onResult(String result); //当返回结果

        void onLog(String log); //log信息
    }

    /**
     * 设置语音识别的onTouth触发事件
     *
     * @param view
     */
    public void setAsrOnTouchListener(TextView view) {
        this.mView = view;
        view.setOnTouchListener(this);
    }

    /**
     * 结果监听
     *
     * @param returnistener
     */
    public void setOnReturnistener(onReturnListener returnistener) {
        this.returnistener = returnistener;
    }

    public onReturnListener returnistener = new NullOnReturnListener();

    public interface onAsrListener {
        void onAsrStart();

        void onError(int error);

        void onAsrfinish();
    }

    public void setOnAsrListener(onAsrListener asrListener) {
        this.asrListener = asrListener;
    }

    public onAsrListener asrListener = new NullOnAsrListener();


}

class NullOnReturnListener implements AsrUtils.onReturnListener {

    @Override
    public void onResult(String result) {
        //do nothing
    }

    @Override
    public void onLog(String log) {
        //do nothing
    }
}

class NullOnAsrListener implements AsrUtils.onAsrListener {

    @Override
    public void onAsrStart() {
        //do nothing
    }

    @Override
    public void onError(int error) {
        //do nothing
    }

    @Override
    public void onAsrfinish() {
        //do nothing
    }
}
