package com.zhk.com.asrlibrary;

import android.speech.SpeechRecognizer;

/**
 * 错误工厂类
 * Created by YOLANDA on 2015-09-14
 */
public class ErrorFactory {

    /**
     * 根据错误码返回错误信息
     *
     * @param error
     * @return
     */
    public static String createError(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO:
                return "音频问题";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                return "没有语音输入";
            case SpeechRecognizer.ERROR_CLIENT:
                return "其它客户端错误";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                return "权限不足";
            case SpeechRecognizer.ERROR_NETWORK:
                return "网络问题";
            case SpeechRecognizer.ERROR_NO_MATCH:
                return "没有匹配";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                return "引擎忙";
            case SpeechRecognizer.ERROR_SERVER:
                return "服务端错误";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                return "连接超时";
            default:
                return "未知错误";
        }
    }
}
