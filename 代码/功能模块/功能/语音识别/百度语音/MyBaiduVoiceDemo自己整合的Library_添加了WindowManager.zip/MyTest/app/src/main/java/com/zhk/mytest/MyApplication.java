package com.zhk.mytest;

import android.app.Application;

import com.zhk.com.asrlibrary.AsrUtils;

/**
 * Created by YOLANDA on 2015-10-12.
 */
public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        AsrUtils.initSpeechRecognizer(this); //初始化语音识别，必须在主线程初始化
    }
}
