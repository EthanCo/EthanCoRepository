package com.zhk.mytest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.TextView;

import com.zhk.com.asrlibrary.AsrUtils;

public class MainActivity extends AppCompatActivity {

    private TextView txtResult;
    private TextView txtLog;
    private Button btn;
    private AsrUtils myAsrUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtResult = (TextView) findViewById(R.id.txtResult);
        txtLog = (TextView) findViewById(R.id.txtLog);
        btn = (Button) findViewById(R.id.btn);


        myAsrUtils = new AsrUtils(this, true);
        myAsrUtils.setAsrOnTouchListener(btn); //设置语音识别触发监听
        myAsrUtils.setOnReturnistener(new AsrUtils.onReturnListener() { //语音识别结果监听
            @Override
            public void onResult(String result) {
                if (result != null) {
                    txtResult.setText(result);
                }
            }

            @Override
            public void onLog(String log) {
                if (log != null) {
                    txtLog.setText(log);
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        AsrUtils.destorySpeeckRecognizer(); //应在退出整个App时destory
        super.onDestroy();
    }
}
