# Android反编译 #
##工具介绍：
###apktool  
资源文件获取，可以提取出图片文件和布局文件进行使用查看  
反编译、重新生成工具  
###dex2jar
将apk反编译成Java源码（classes.dex转化成jar文件）
###jd-gui
查看APK中classes.dex转化成出的jar文件，即源码文件

## apktool的使用 ##

Apktool:[ApkTool最新下载](http://www.softpedia.com/get/Programming/Debuggers-Decompilers-Dissasemblers/ApkTool.shtml)  
apktool.bat:[apktool.bat下载](http://download.csdn.net/download/vipzjyno1/7025111)  
aapt.exe: 建议使用最新版 比如: .\SDK\build-tools\24.0.1\aapt.exe


Apktol 需把aapt.exe、apktool.bat、apktool.jar 复制到到你的Windows安装目录下(比如C:\Windows)，以方便使用Dos命令  

###decode 反编译

该命令用于进行反编译apk文件，一般用法为

	apktool d <file.apk> -o <dir>

	//<file.apk>代表了要反编译的apk文件的路径，最好写绝对路径，比如C:\MusicPlayer.apk
	//<dir>代表了反编译后的文件的存储位置，比如C:\MusicPlayer，如果你给定的<dir>已经存在，那么输入完该命令后会提示你，并且无法执行，需要你重新修改命令加入-f指令  
	
	apktool d –f <file.apk> <dir>
	
	//这样就会强行覆盖已经存在的文件

###build 创建(重新创建apk)

该命令用于编译修改好的文件，一般用法为

	apktool b <dir>

	//这里的<dir>就是刚才你反编译时输入的<dir>（如C:\MusicPlayer）,输入这行命令后，如果一切正常，  
	//你会发现C:\MusicPlayer内多了2个文件夹build和dist，其中分别存储着编译过程中逐个编译的文件以及最终打包的apk文件。

比如，我们可以把decode生成的目录下的res\mipmap\ic_launcher.png替换成自己的图片，然后再用build生成一个新的apk，之后进行apk签名后，就成功替换了图标了，可安装到手机上了 ~

## Apk签名 ##
　　创建key，需要用到keytool.exe (位于jdk1.6.0_24jre\bin目录下)，使用产生的key对apk签名用到的是jarsigner.exe (位于jdk1.6.0_24\bin目录下)，把上两个软件所在的目录添加到环境变量path后，打开cmd输入

####  ####
   	D:>keytool -genkey -alias demo.keystore -keyalg RSA -validity 40000 -keystore demo.keystore
   	/*说明：-genkey 产生密钥
           -alias demo.keystore 别名 demo.keystore
           -keyalg RSA 使用RSA算法对签名加密
           -validity 40000 有效期限4000天
           -keystore demo.keystore */
       
	D:>jarsigner -verbose -keystore demo.keystore -signedjar demo_signed.apk demo.apk demo.keystore
    /*说明：-verbose 输出签名的详细信息
           -keystore  demo.keystore 密钥库位置
           -signedjar demor_signed.apk demo.apk demo.keystore 正式签名，三个参数中
			依次为签名后产生的文件demo_signed，要签名的文件demo.apk和密钥库demo.keystore.*/



> 注意事项：Android工程的bin目录下的demo.apk默认是已经使用debug用户签名的，所以不能使用上述步骤对此文件再次签名。正确步骤应该是:在工程点击右键->Anroid Tools-Export Unsigned Application Package导出的apk采用上述步骤签名。  

## Apk反编译得到Java源代码 ##
下载上述工具中的[dex2jar](https://sourceforge.net/projects/dex2jar/)和 [jd-gui](http://jd.benow.ca/) ，解压  
将要反编译的APK后缀名改为.rar或则 .zip，并解压，得到其中的额classes.dex文件（它就是java文件编译再通过dx工具打包而成的），将获取到的classes.dex放到之前解压出来的工具dex2jar-x.x.x 文件夹内，
在命令行下定位到dex2jar.bat所在目录

	d2j-dex2jar.bat   classes.dex

在改目录下会生成一个classes_dex2jar.jar的文件，然后打开工具jd-gui文件夹里的jd-gui.exe，之后用该工具打开之前生成的classes_dex2jar.jar文件，便可以看到源码了  


## 其他 ##

### 下载 ###
[2016年8月份最新aapt、dex2jar、jd.gui打包下载](http://download.csdn.net/detail/ethanco/9589859)

### 参考 ###

> 参考 [http://blog.csdn.net/vipzjyno1/article/details/21039349/](http://blog.csdn.net/vipzjyno1/article/details/21039349/)  

