package com.zhk.hellondk_m;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends Activity {

	static{
		System.loadLibrary("hello"); //����SO ȥ��libǰ׺��.so��׺
	}
	
	//����һ��native���� (û�жԸ÷���ʵ��)
	public static native String getStringFromC();

	private TextView tvInfo;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		tvInfo =(TextView) findViewById(R.id.tvInfo);
		tvInfo.setText(getStringFromC());
	}
}
