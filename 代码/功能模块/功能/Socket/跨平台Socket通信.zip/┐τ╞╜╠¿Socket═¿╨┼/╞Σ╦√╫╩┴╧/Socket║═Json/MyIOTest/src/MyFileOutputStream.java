import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;

import net.sf.json.JSONObject;


public class MyFileOutputStream {
	public static void main(String[] args) throws IOException{
		Socket socket = new Socket("127.0.0.1", 3456);
		OutputStreamWriter osw =new OutputStreamWriter(socket.getOutputStream());
		BufferedWriter bufw = new BufferedWriter(osw);
		JSONObject JObject = new JSONObject();
		JObject.put("fire", "false");
		bufw.write(JObject.toString()+"\r\n");
		bufw.close();
	}
}
