package Test;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class Test {
		static DataOutputStream out;
	 	static DataInputStream in;
		static Socket socket;
	public static void main(String[] args) {

		try {
			socket = new Socket("127.0.0.1", 9999);//����Socket
			System.out.println("client: "+"client start");
			
			//�������������Ϣ
			out = new DataOutputStream(socket.getOutputStream());
			out.writeUTF("send Message");
			out.flush();

			//�������Է���������Ϣ
			in = new DataInputStream(socket.getInputStream());
			String readMsg = in.readUTF();
			if (readMsg != null) {
				System.out.println("client: "+readMsg);
			}			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(out!=null){
				try {
					out.close();//�ر������
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(in!=null){
				try {
					in.close();//�ر�������
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(socket!=null){
				try {
					socket.close();//�رմ򿪵�socket
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}