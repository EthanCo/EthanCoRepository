﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace TT2
{
    class Program
    {
        //接受端
        static void Main(string[] args)
        {
            Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint ipEndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1007); //创建端口
            serverSocket.Bind(ipEndPoint);
            serverSocket.Listen(10);
            while (true)
            {
                Socket clientSocket = serverSocket.Accept();
                byte[] tempByte = new byte[20480];  //可自定义大小
                int count = clientSocket.Receive(tempByte);

                String str = Encoding.UTF8.GetString(tempByte).Replace("\0","");
                Console.WriteLine(str);
            }
        }
    }
}
