import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;

import net.sf.json.JSONObject;


public class Test {

	public static void main(String[] args) {
			Socket socket;
			try {
				socket = new Socket("127.0.0.1", 1007);
				BufferedWriter myBufferedWriter = new BufferedWriter(
						new OutputStreamWriter(socket.getOutputStream())
					);
				/*
				JSONObject jo = new JSONObject();
				jo.put("fire", "on");
				myBufferedWriter.write(jo.toString()+"\r\n");
				*/
				//myBufferedWriter.write(new JSONObject().put("fire", "on").toString()+"\r\n"); ������󣬷��ص�put���ֵ������JsonObject
				myBufferedWriter.write("on");
				myBufferedWriter.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
