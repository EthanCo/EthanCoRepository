﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace TT1
{
    class Program
    {
        //发送端
        static void Main(string[] args)
        {
            Socket clientSocket = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
            IPEndPoint ipEndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1005); //发送到的IP地址及端口
            clientSocket.Connect(ipEndPoint);
            Alarm alarm = new Alarm();
            alarm.fire = "on";
            String jString = JsonConvert.SerializeObject(alarm);
            Console.WriteLine(jString);
            clientSocket.Send(Encoding.UTF8.GetBytes(jString));
            Console.Read();
        }
    }
}
