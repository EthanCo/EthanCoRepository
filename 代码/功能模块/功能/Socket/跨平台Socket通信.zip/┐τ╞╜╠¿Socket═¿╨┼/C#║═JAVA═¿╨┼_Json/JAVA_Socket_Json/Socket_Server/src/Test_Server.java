import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import net.sf.json.JSONObject;


public class Test_Server {

	public static void main(String[] args) {
		ServerSocket serverSocket = null ;
		try {
			serverSocket = new ServerSocket(1005);
			while (true) {
				// ����ServerSocket��accept()����,���տͻ��������͵�����,����ͻ���û�з�������,��ô���߳̾�ֹͣ������
				Socket socket = serverSocket.accept();
				
				//���տͻ�����Ϣ
				/*
				InputStreamReader isr = new InputStreamReader(socket.getInputStream());
				BufferedReader bfr = new BufferedReader(isr);
				String jString = bfr.readLine();
				JSONObject jo = JSONObject.fromObject(jString);
				System.out.println(jo.toString());
				//String str = jo.getString("fire");
				*/
				DataInputStream dis = new DataInputStream(socket.getInputStream());
				byte[] bytes = new byte[1024];
				dis.read(bytes);
				String str = new String(bytes);
				str = str.replace("\0", "");
				JSONObject jo = JSONObject.fromObject(str);
				System.out.println(jo.getString("fire"));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if (serverSocket!=null) {
				try {
					serverSocket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
