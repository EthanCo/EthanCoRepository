import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;

import net.sf.json.JSONObject;


public class Test {

	public static void main(String[] args) {
			Socket socket=null;
			try {
				socket = new Socket("127.0.0.1", 1001);
				BufferedWriter myBufferedWriter = new BufferedWriter(
						new OutputStreamWriter(socket.getOutputStream())
					);
				JSONObject jo = new JSONObject();
				jo.put("fire", "on");
				myBufferedWriter.write(jo.toString()+"\r\n");
				//myBufferedWriter.write(new JSONObject().put("fire", "on").toString()+"\r\n"); ������󣬷��ص�put���ֵ������JsonObject
				myBufferedWriter.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
	}
}
