package com.zhk.clipdrawable;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.graphics.drawable.ClipDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;
public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ImageView imageview = (ImageView)findViewById(R.id.image);
		final ClipDrawable drawable = (ClipDrawable)imageview.getDrawable();
		
		final Handler mhandler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				if(msg.what==0x1123){
				//�޸�ClipDrawable��levelֵ
				drawable.setLevel(drawable.getLevel()+200);
				}
			}
		};
		
		final Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				Message msg = new Message();
				msg.what=0x1123;
				mhandler.sendMessage(msg);
				//ȡ����ʱ��
				if(drawable.getLevel()>=20000){ 
					timer.cancel();
				}
			}
		}, 0, 150); //0 ��ʱ,150 ִ��һ��
	}
}
