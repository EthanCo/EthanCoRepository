package com.zhk.sqlitetest;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;

public class MainActivity extends Activity {
	Cursor mCursor;
	SimpleCursorAdapter mCursorAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		ListView bookLstView = (ListView)findViewById(R.id.mainListView);
		DBUtils dbUtils = new DBUtils(this);
		mCursor = dbUtils.queryForCursor();
		/**
		 * ���α�������
		 * context:������
		 * layout:�б���ֵ�id
		 * c:cursor:�α�
		 * from: �������������α���Ǹ��ֶ���
		 * to:������ȥ,���б���ֵ��Ǹ��ؼ�ȥ
		 * flags:�Զ�ע�����ݼ���
		 */
		mCursorAdapter = new SimpleCursorAdapter
				(this, R.layout.item, mCursor, new String[]{"name","price"}, 
						new int[]{R.id.tvBookName,R.id.tvBookPrice},CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
		bookLstView.setAdapter(mCursorAdapter);
		
		//�����б���������б��ɾ��
		bookLstView.setOnItemLongClickListener(new OnItemLongClickListener() {
			//id ��ǰ�б������ݵ�id����ֵ���к�
			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
				DBUtils utils = new DBUtils(MainActivity.this);
				utils.delete((int)id);
				mCursor.requery(); //��д��ѯ
				mCursorAdapter.notifyDataSetChanged();//֪ͨlistview���ݼ��Ѿ��ı�
				/*
				new Thread(){
					public void run() {
						mCursor.requery();
					};
				}.start();
				*/
				return true;
			}
		});		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		
		if (mCursor!=null) {
			mCursor.close(); //�ر��α�
		}
	}
}
