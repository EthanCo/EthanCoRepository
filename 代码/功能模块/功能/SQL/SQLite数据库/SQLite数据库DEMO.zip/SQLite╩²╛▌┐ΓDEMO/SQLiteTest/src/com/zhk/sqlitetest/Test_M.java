package com.zhk.sqlitetest;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.test.AndroidTestCase;

public class Test_M extends AndroidTestCase {
		public void create(){
			DBHelper dbHelper = new DBHelper(getContext());
			SQLiteDatabase db = dbHelper.getReadableDatabase();
		}
		public void insert(){
			DBUtils utils = new DBUtils(getContext());
			for (int i = 0; i < 20; i++) {
				ContentValues values = new ContentValues();
				values.put("name", "���Android����"+i);
				values.put("price", i*2);
				int res = utils.insert(values);
				
				/**
				 * ����
				 * assertEquals(expected, actual);
				 * assertEquals(����ֵ, ʵ��ֵ);
				 */
				assertEquals(true, res>0);
			}
		}
		
		public void update(){
			DBUtils utils = new DBUtils(getContext());
			ContentValues values = new ContentValues();
			values.put("_id", "2");
			values.put("name", "���������");
			values.put("price", 100);
			int res = utils.update(values );
			
			assertEquals(true, res==1);
		}
		
		public void delete(){
			DBUtils utils = new DBUtils(getContext());
			int res = utils.delete(5);
			
			assertEquals(true, res==1);
		}
}
