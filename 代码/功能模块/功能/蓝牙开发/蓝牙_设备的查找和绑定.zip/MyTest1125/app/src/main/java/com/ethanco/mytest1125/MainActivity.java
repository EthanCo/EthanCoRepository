package com.ethanco.mytest1125;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private BlueToothController mController;
    private List<BluetoothDevice> mBondedDeviceList;
    private Toast mToast;

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)) {//开始查找
                //开始查找 可用作ListView的初始化
                Log.i("zhk-MainActivity", "onReceive: 开始查找");
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {//结束查找
                //结束查找
                Log.i("zhk-MainActivity", "onReceive: 结束查找");
            } else if (BluetoothDevice.ACTION_FOUND.equals(action)) { //查找设备
                //查找设备
                //找到一个设备
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                Log.i("zhk-MainActivity", "onReceive: 找到一个设备:" + device.getName());
            } else if (BluetoothAdapter.ACTION_SCAN_MODE_CHANGED.equals(action)) {//设备扫描模式改变
                int scanMode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, 0);
                if (scanMode == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
                    //能被发现的
                    Log.i("zhk-MainActivity", "onReceive: 能被发现");
                } else {
                    //不能被发现
                    Log.i("zhk-MainActivity", "onReceive: 不能被发现");
                }
            } else if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) { //状态改变
                int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1);
                switch (state) {
                    case BluetoothAdapter.STATE_OFF:
                        Log.i("zhk-MainActivity", "onReceive: STATE_OFF");
                        toast("STATE_OFF");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        Log.i("zhk-MainActivity", "onReceive: STATE_ON");
                        toast("STATE_ON");
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        Log.i("zhk-MainActivity", "onReceive: STATE_TURNING_ON");
                        toast("STATE_TURNING_ON");
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        Log.i("zhk-MainActivity", "onReceive: STATE_TURNING_OFF");
                        toast("STATE_TURNING_OFF");
                        break;
                    default:
                        Log.i("zhk-MainActivity", "onReceive: STATE");
                        toast("unknown STATE");
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IntentFilter filter = new IntentFilter();
        //开始查找
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        //结束查找
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        //查找设备
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        //设备扫描模式改变
        filter.addAction(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        //绑定设备
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(receiver, filter);

        mController = new BlueToothController();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            default:
        }
    }

    private void toast(String msg) {
        if (mToast == null) {
            mToast = Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT);
        } else {
            mToast.setText(msg);
        }
        mToast.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.enable_visiblity:
                //设置蓝牙可见5分钟
                mController.enableVisibly(this);
                return true;
            case R.id.find_device:
                //查找设备
                mController.findDevice();
                return true;
            case R.id.bonded_device:
                //查看已绑定设备
                mBondedDeviceList = mController.getBondedDeviceList();
                Log.i("zhk-MainActivity", "onContextItemSelected: 已绑定设备数量:" + mBondedDeviceList.size());
                for (BluetoothDevice device : mBondedDeviceList) {
                    Log.i("zhk-MainActivity", "onContextItemSelected: 已绑定设备:" + device);
                }
                break;
            default:
        }
        return super.onContextItemSelected(item);
    }
}
