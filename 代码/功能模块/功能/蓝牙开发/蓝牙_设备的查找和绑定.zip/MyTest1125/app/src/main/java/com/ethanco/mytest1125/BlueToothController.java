package com.ethanco.mytest1125;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Zhk on 2015/11/24.
 */
public class BlueToothController {
    private BluetoothAdapter mAdapter;

    public BlueToothController() {
        mAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    /**
     * 是否支持蓝牙
     *
     * @return true 支持 false 不支持
     */
    public boolean isSupportBlueTooth() {
        if (mAdapter != null) {
            return true;
        }
        return false;
    }

    /**
     * 判断当前蓝牙状态
     *
     * @return true 打开 false 关闭
     */
    public boolean getBlueToothStatus() {
        assert mAdapter != null;
        return mAdapter.isEnabled();
    }

    /**
     * 打开蓝牙 返回值在onActivityResult中
     *
     * @param activity
     * @param requestCode
     */
    public void tureOnBlueThooth(Activity activity, int requestCode) {
        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        activity.startActivityForResult(intent, requestCode);
        //mAdapter.enable(); //可以不经过手动设置即打开蓝牙，但google不推荐这么做
    }

    /**
     * 关闭蓝牙
     */
    public void tureOffBlueTooth() {
        mAdapter.disable();
    }

    /**
     * 设置蓝牙可见 - 5分钟内
     *
     * @param context
     */
    public void enableVisibly(Context context) {
        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        context.startActivity(discoverableIntent);
    }

    /**
     * 查找设备
     */
    public void findDevice() {
        assert (mAdapter != null);
        mAdapter.startDiscovery();
    }

    /**
     * 取消查找设备
     */
    public void cancelFindDevice() {
        if (mAdapter.isDiscovering()) {
            mAdapter.cancelDiscovery();
        }
    }

    /**
     * 获取绑定设备
     *
     * @return
     */
    public List<BluetoothDevice> getBondedDeviceList() {
        return new ArrayList<>(mAdapter.getBondedDevices());
    }
}
