package com.ethanco.mytest1125;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int BLUETOOTH_REQUEST_CODE = 10086;
    private BlueToothController blueToothController;
    private Toast mToast;

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1);
            switch (state) {
                case BluetoothAdapter.STATE_OFF:
                    toast("STATE_OFF");
                    break;
                case BluetoothAdapter.STATE_ON:
                    toast("STATE_ON");
                    break;
                case BluetoothAdapter.STATE_TURNING_ON:
                    toast("STATE_TURNING_ON");
                    break;
                case BluetoothAdapter.STATE_TURNING_OFF:
                    toast("STATE_TURNING_OFF");
                    break;
                default:
                    toast("unknown STATE");
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(receiver, filter);

        blueToothController = new BlueToothController();
        findViewById(R.id.btnIsSupport).setOnClickListener(this);
        findViewById(R.id.btnBlueToothStatus).setOnClickListener(this);
        findViewById(R.id.btnTurnOnBlueTooth).setOnClickListener(this);
        findViewById(R.id.btnTurnOffBlueTooth).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnIsSupport:
                toast(String.valueOf(blueToothController.isSupportBlueTooth()));
                break;
            case R.id.btnBlueToothStatus:
                toast(String.valueOf(blueToothController.getBlueToothStatus()));
                break;
            case R.id.btnTurnOnBlueTooth:
                blueToothController.tureOnBlueThooth(this, BLUETOOTH_REQUEST_CODE);
                break;
            case R.id.btnTurnOffBlueTooth:
                blueToothController.tureOffBlueTooth();
                toast("关闭成功");
                break;
            default:
        }
    }

    private void toast(String msg) {
        if (mToast == null) {
            mToast = Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT);
        } else {
            mToast.setText(msg);
        }
        mToast.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == BLUETOOTH_REQUEST_CODE) {
            toast("打开成功");
        } else if (resultCode == RESULT_FIRST_USER && requestCode == BLUETOOTH_REQUEST_CODE) {
            toast("打开失败");
        }
    }
}
