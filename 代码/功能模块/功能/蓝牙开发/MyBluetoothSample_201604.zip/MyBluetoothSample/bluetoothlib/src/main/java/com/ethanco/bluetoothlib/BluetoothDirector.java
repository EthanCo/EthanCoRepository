package com.ethanco.bluetoothlib;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import com.ethanco.bluetoothlib.connect.Constant;
import com.ethanco.bluetoothlib.controller.BlueToothController;
import com.ethanco.bluetoothlib.controller.ChatController;

public class BluetoothDirector {

    private Activity mActivity;
    private static final int TURN_ON_BLUETHOOTH = 123990123;
    private BlueToothController controller;

    /**
     * 建立连接
     *
     * @param device
     */
    public void conn(BluetoothDevice device) {
        ChatController.getInstance().startChatWith(device, controller.getAdapter(), mUIHandler);
    }

    /**
     * 等待连接
     */
    public void waitConn() {
        ChatController.getInstance().waitingForFriends(controller.getAdapter(), mUIHandler);
    }

    /**
     * 发送数据
     *
     * @param msg
     */
    public void send(String msg) {
        ChatController.getInstance().sendMessage(msg);
    }

    /**
     * 进行配对
     *
     * @param device
     */
    public void startBond(BluetoothDevice device) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            device.createBond();
        }
    }

    public void destory() {
        boolean status = controller.getBlueToothStatus();
        if (status) {
            controller.tureOffBlueTooth();
        }
    }


    public BluetoothDirector(Activity activity) {
        this.mActivity = activity;

        controller = new BlueToothController();
        mUIHandler = new MyHandler(Looper.getMainLooper());
        registerReceiver();
        boolean isSupportBlueTooth = controller.isSupportBlueTooth();
        if (!isSupportBlueTooth) { //是否支持蓝牙
            Toast.makeText(mActivity, "设备不支持蓝牙", Toast.LENGTH_SHORT).show();
        } else {
            boolean status = controller.getBlueToothStatus();
            if (!status) { //蓝牙状态
                controller.tureOnBlueThooth(mActivity, TURN_ON_BLUETHOOTH);
            } else {
                controller.findDevice();
            }
        }
    }

    private void registerReceiver() {
        IntentFilter filter = new IntentFilter();
        //开始查找
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        //结束查找
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        //查找设备
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        //设备扫描模式改变
        filter.addAction(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        //绑定设备
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        //绑定状态
        filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        mActivity.registerReceiver(receiver, filter);
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)) {//开始查找
                //开始查找 可用作ListView的初始化
                Log.i("zhk-MainActivity", "onReceive: 开始查找");
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {//结束查找
                //结束查找
                Log.i("zhk-MainActivity", "onReceive: 结束查找");
            } else if (BluetoothDevice.ACTION_FOUND.equals(action)) { //查找设备
                //查找设备
                //找到一个设备
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                Log.i("zhk-MainActivity", "onReceive: 找到一个设备:" + device.getName());
            } else if (BluetoothAdapter.ACTION_SCAN_MODE_CHANGED.equals(action)) {//设备扫描模式改变
                int scanMode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, 0);
                if (scanMode == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
                    //能被发现的
                    Log.i("zhk-MainActivity", "onReceive: 能被发现");
                } else {
                    //不能被发现
                    Log.i("zhk-MainActivity", "onReceive: 不能被发现");
                }
            } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
                BluetoothDevice remoteDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (remoteDevice == null) {
                    Log.i("zhk-MainActivity", "onReceive no device: ");
                    return;
                }
                int status = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, 0);
                if (status == BluetoothDevice.BOND_BONDED) { //配对(绑定)
                    Log.i("zhk-MainActivity", "onReceive Bonded " + remoteDevice.getName() + ": ");
                } else if (status == BluetoothDevice.BOND_BONDING) {
                    Log.i("zhk-MainActivity", "onReceive Bonding" + remoteDevice.getName() + ": ");
                } else if (status == BluetoothDevice.BOND_NONE) {
                    Log.i("zhk-MainActivity", "onReceive Not bond" + remoteDevice.getName() + ": ");
                }
            } else if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) { //状态改变
                int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1);
                switch (state) {
                    case BluetoothAdapter.STATE_OFF:
                        Toast.makeText(mActivity, "蓝牙已关闭", Toast.LENGTH_SHORT).show();
                        break;
                    case BluetoothAdapter.STATE_ON:
                        Toast.makeText(mActivity, "蓝牙已打开", Toast.LENGTH_SHORT).show();
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        Toast.makeText(mActivity, "正在打开蓝牙", Toast.LENGTH_SHORT).show();
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        Toast.makeText(mActivity, "正在关闭蓝牙", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        Toast.makeText(mActivity, "未知", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    private Handler mUIHandler;

    private class MyHandler extends Handler {
        public MyHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case Constant.MSG_START_LISTENING:
                    //开始监听
                    break;
                case Constant.MSG_FINISH_LISTENING:
                    //结束监听
                    break;
                case Constant.MSG_GOT_DATA:
                    //收到数据
                    byte[] data = (byte[]) msg.obj;
                    String s = ChatController.getInstance().decodeMessage(data);
                    break;
                case Constant.MSG_ERROR:
                    break;
                case Constant.MSG_CONNECTED_TO_SERVER:
                    break;
                case Constant.MSG_GOT_A_CLINET:
                    break;
            }
        }
    }
}
