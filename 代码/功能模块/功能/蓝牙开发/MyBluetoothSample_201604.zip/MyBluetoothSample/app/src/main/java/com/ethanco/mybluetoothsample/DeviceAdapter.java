package com.ethanco.mybluetoothsample;

import android.bluetooth.BluetoothDevice;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ethanco.mybluetoothsample.databinding.ItemBluetoothDeviceBinding;

import java.util.List;

/**
 * Created by EthanCo on 2016/4/11.
 */
public class DeviceAdapter extends RecyclerView.Adapter<DeviceAdapter.ItemViewHodler> {
    List<BluetoothDevice> list;

    public DeviceAdapter(List<BluetoothDevice> list) {
        this.list = list;
    }

    @Override
    public ItemViewHodler onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bluetooth_device, parent, false);
        return new ItemViewHodler(view);
    }

    @Override
    public void onBindViewHolder(final ItemViewHodler holder, final int position) {
        holder.bind(list.get(position));
        holder.binding.layoutDeviceRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mItemClickListener.onClick(v, list.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void addData(List<BluetoothDevice> devices) {
        Log.i("Z-DeviceAdapter", "addData devices.size: " + devices.size());
        int start = list.size();
        list.addAll(devices);
        notifyItemRangeInserted(0, devices.size());
        //notifyItemRangeChanged(0, devices.size()+1);
    }

    public void addData(BluetoothDevice device) {
        list.add(device);
        notifyItemInserted(list.size() - 1);
    }

    public void clearData() {
        int end = list.size();
        list.clear();
        notifyItemRangeChanged(0, end);
    }

    public interface OnItemClickListener {
        void onClick(View v, BluetoothDevice device);
    }

    public void setItemClickListener(OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    private OnItemClickListener mItemClickListener = new OnItemClickListener() {
        @Override
        public void onClick(View v, BluetoothDevice device) {

        }
    };

    class ItemViewHodler extends RecyclerView.ViewHolder {
        private ItemBluetoothDeviceBinding binding;

        public ItemViewHodler(View itemView) {
            super(itemView);
            binding = ItemBluetoothDeviceBinding.bind(itemView);
        }

        public void bind(BluetoothDevice device) {
            binding.setDevice(device);
        }
    }
}
