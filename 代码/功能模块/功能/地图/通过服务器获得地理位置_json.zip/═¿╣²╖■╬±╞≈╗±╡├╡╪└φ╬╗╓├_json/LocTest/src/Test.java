import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;

import net.sf.json.JSONObject;

public class Test {
	private static final String BAIDU_URI = "http://api.map.baidu.com/location/ip?ak=vks3atcZ9V2GKnRXpTl6htmG";

	public static void main(String[] args) throws URISyntaxException, IOException {
		URL url = new URL(BAIDU_URI);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setReadTimeout(5000);
		conn.setRequestMethod("GET");
		//		conn.connect();
		if (conn.getResponseCode() == 200) {
			InputStream in = conn.getInputStream();
			InputStreamReader inr = new InputStreamReader(in);
			BufferedReader bfr = new BufferedReader(inr);
			String str = null;
			StringBuilder builder = new StringBuilder();
			while ((str = bfr.readLine()) != null) {
				builder.append(str);
			}
			String JString = builder.toString();
			JSONObject JObject = JSONObject.fromObject(JString);
			JSONObject content = JObject.getJSONObject("content");
			String address = content.getString("address");
			System.out.println(address);
			bfr.close();
			conn.disconnect();
		}
	}

	public static String changeCharset(String str, String oldCharset, String newCharset) throws UnsupportedEncodingException {
		if (str != null) {
			//�þɵ��ַ���������ַ�����������ܻ�����쳣��
			byte[] bs = str.getBytes(oldCharset);
			//���µ��ַ����������ַ���
			return new String(bs, newCharset);
		}
		return null;
	}
}
