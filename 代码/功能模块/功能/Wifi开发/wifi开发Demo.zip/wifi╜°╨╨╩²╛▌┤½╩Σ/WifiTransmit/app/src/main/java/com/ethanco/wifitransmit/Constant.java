package com.ethanco.wifitransmit;

/**
 * Created by EthanCo on 2016/4/24.
 */
public class Constant {
    public final static String END="end";
    public final static String HOST_SPOT_SSID="HotSpotRobin";
    public final static String HOST_SPOT_PASS_WORD="123456789";
}