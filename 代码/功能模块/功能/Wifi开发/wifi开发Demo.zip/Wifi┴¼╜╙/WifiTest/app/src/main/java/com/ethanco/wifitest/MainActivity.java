package com.ethanco.wifitest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private WifiManager wifiManager;
    private List<ScanResult> wifiList;
    private RecyclerView listWifi;
    private WifiAdmin wifiAdmin;
    private WifiAdapter wifiAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listWifi = (RecyclerView) findViewById(R.id.list_wifi);
        listWifi.setLayoutManager(new LinearLayoutManager(this));

        //获取wifiManager
        //wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        //使用工具类更方便
        wifiAdmin = new WifiAdmin(this);

        //打开wifi
        wifiAdmin.openWifi();

        if (wifiAdmin.getWifiManager().isWifiEnabled()) {
            initWifiList();
        }

        registerWifiReciver();
    }

    private void initWifiList() {
        //扫描Wifi，得到wifiList
        //wifiList = wifiManager.getScanResults();
        wifiAdmin = new WifiAdmin(this);
        wifiAdmin.startScan();
        wifiList = (wifiAdmin.getWifiList());

        wifiAdapter = new WifiAdapter(this, wifiList, wifiAdmin);
        listWifi.setAdapter(wifiAdapter);
    }

    private void registerWifiReciver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(new NetworkConnectChangedReceiver(), filter);
    }

    class NetworkConnectChangedReceiver extends BroadcastReceiver {
        private static final String TAG = "NetworkConnect";

        @Override
        public void onReceive(Context context, Intent intent) {
            if (WifiManager.WIFI_STATE_CHANGED_ACTION.equals(intent.getAction())) {// 这个监听wifi的打开与关闭，与wifi的连接无关
                int wifiState = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, 0);
                Log.e("H3c", "wifiState" + wifiState);
                switch (wifiState) {
                    case WifiManager.WIFI_STATE_DISABLED:
                        Toast.makeText(getApplication(), "Wifi关闭", Toast.LENGTH_SHORT).show();
                        break;
                    case WifiManager.WIFI_STATE_DISABLING:
                        Toast.makeText(getApplication(), "Wifi正在关闭", Toast.LENGTH_SHORT).show();
                        break;
                    case WifiManager.WIFI_STATE_ENABLED:
                        Toast.makeText(getApplication(), "wifi打开", Toast.LENGTH_SHORT).show();
                        initWifiList();
                        break;
                    case WifiManager.WIFI_STATE_ENABLING:
                        Toast.makeText(getApplication(), "wifi正在打开", Toast.LENGTH_SHORT).show();
                        break;
                    //
                }
            }
            // 这个监听wifi的连接状态即是否连上了一个有效无线路由，当上边广播的状态是WifiManager.WIFI_STATE_DISABLING，和WIFI_STATE_DISABLED的时候，根本不会接到这个广播。
            // 在上边广播接到广播是WifiManager.WIFI_STATE_ENABLED状态的同时也会接到这个广播，当然刚打开wifi肯定还没有连接到有效的无线
            if (WifiManager.NETWORK_STATE_CHANGED_ACTION.equals(intent.getAction())) {
                Parcelable parcelableExtra = intent
                        .getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
                if (null != parcelableExtra) {
                    NetworkInfo networkInfo = (NetworkInfo) parcelableExtra;
                    NetworkInfo.State state = networkInfo.getState();
                    boolean isConnected = state == NetworkInfo.State.CONNECTED;// 当然，这边可以更精确的确定状态
                    Toast.makeText(getApplication(), "isConnected:" + isConnected, Toast.LENGTH_SHORT).show();
                    Log.e("H3c", "isConnected" + isConnected);
                    if (isConnected) {
                    } else {

                    }
                }
            }
            // 这个监听网络连接的设置，包括wifi和移动数据的打开和关闭。.
            // 最好用的还是这个监听。wifi如果打开，关闭，以及连接上可用的连接都会接到监听。见log
            // 这个广播的最大弊端是比上边两个广播的反应要慢，如果只是要监听wifi，我觉得还是用上边两个配合比较合适
            if (ConnectivityManager.CONNECTIVITY_ACTION.equals(intent.getAction())) {
                ConnectivityManager manager = (ConnectivityManager) context
                        .getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo gprs = manager
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                NetworkInfo wifi = manager
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                Log.i(TAG, "网络状态改变:" + wifi.isConnected() + " 3g:" + gprs.isConnected());
                initWifiList();
                NetworkInfo info = intent.getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
                if (info != null) {
                    Log.e("H3c", "info.getTypeName()" + info.getTypeName());
                    Log.e("H3c", "getSubtypeName()" + info.getSubtypeName());
                    Log.e("H3c", "getState()" + info.getState());
                    Log.e("H3c", "getDetailedState()"
                            + info.getDetailedState().name());
                    Log.e("H3c", "getDetailedState()" + info.getExtraInfo());
                    Log.e("H3c", "getType()" + info.getType());

                    if (NetworkInfo.State.CONNECTED == info.getState()) {
                    } else if (info.getType() == 1) {
                        if (NetworkInfo.State.DISCONNECTING == info.getState()) {

                        }
                    }
                }
            }
        }
    }
}
