package com.ethanco.wifitest;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;

import java.util.List;

/**
 * Created by EthanCo on 2016/4/23.
 */
public class WifiAdapter extends RecyclerView.Adapter<WifiAdapter.ItemViewHodler> {
    private final WifiAdmin wifiAdmin;
    private List<ScanResult> wifiList;
    private Context mContent;

    public WifiAdapter(Context context, List<ScanResult> wifiList, WifiAdmin wifiAdmin) {
        this.mContent = context;
        this.wifiList = wifiList;
        this.wifiAdmin = wifiAdmin;
    }

    @Override
    public ItemViewHodler onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater mInflater = LayoutInflater.from(context);
        View view = mInflater.inflate(R.layout.item_wifi_info, parent, false);
        return new ItemViewHodler(view);
    }

    @Override
    public void onBindViewHolder(ItemViewHodler holder, int position) {
        final ScanResult wifi = wifiList.get(position);
        holder.tvWifiSSID.setText(wifi.SSID);
        Log.i("Z-WifiAdapter", "onBindViewHolder : "+(wifi.BSSID.equals(wifiAdmin.getBSSID())));
        holder.tvWifiStatus.setText(wifi.BSSID.equals(wifiAdmin.getBSSID()) ? "已连接" : "未连接");
        holder.layoutWifiInfoRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new MaterialDialog.Builder(mContent)
                        .title("连接" + wifi.SSID)
                        .content("")
                        .inputType(InputType.TYPE_TEXT_VARIATION_PASSWORD)
                        .input("", "", new MaterialDialog.InputCallback() {
                            @Override
                            public void onInput(@NonNull MaterialDialog dialog, CharSequence input) {
                                Toast.makeText(mContent, "" + input, Toast.LENGTH_SHORT).show();
                                String pwd = input.toString();
                                WifiConfiguration wifiInfo;
                                if (!TextUtils.isEmpty(pwd)) {
//                                    int type = 1;
//                                    if (wifi.capabilities.toLowerCase().contains("wep")) {
//                                        type = 2;
//                                    } else if (wifi.capabilities.toLowerCase().contains("wpa")) {
//                                        type = 3;
//                                    }
//                                    Log.i("Z-WifiAdapter", "onInput type: " + type);
                                    wifiInfo = wifiAdmin.createWifiInfo(wifi.SSID, input.toString(), 3);
                                    List<WifiConfiguration> configList = wifiAdmin.getConfiguration();
                                    //wifiAdmin.get
                                } else {
                                    wifiInfo = wifiAdmin.createWifiInfo(wifi.SSID, input.toString(), 1);
                                }
                                wifiAdmin.addNetwork(wifiInfo);
                            }
                        }).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        if (wifiList != null) {
            return wifiList.size();
        }
        return 0;
    }

    class ItemViewHodler extends RecyclerView.ViewHolder {
        private final TextView tvWifiSSID;
        private final ViewGroup layoutWifiInfoRoot;
        private final TextView tvWifiStatus;

        public ItemViewHodler(View itemView) {
            super(itemView);
            tvWifiSSID = (TextView) itemView.findViewById(R.id.tv_wifi_ssid);
            layoutWifiInfoRoot = (ViewGroup) itemView.findViewById(R.id.layout_wifi_info_root);
            tvWifiStatus = (TextView) itemView.findViewById(R.id.tv_wifi_status);
        }
    }
}
