//package com.ethanco.wifitest;
//
//import android.net.wifi.WifiConfiguration;
//import android.util.Log;
//
///**
// * Created by EthanCo on 2016/4/23.
// */
//public class WifiUtil {
//    private static final String TAG = "WifiUtil";
//
//    /***
//     * 配置要连接的WIFI热点信息
//     * @param SSID
//     * @param password
//     * @param type  加密类型
//     * @return
//     */
//    public static WifiConfiguration createWifiInfo(String SSID, String password, int type) {
//
//        Log.e(TAG, "SSID = " + SSID + "## Password = " + password + "## Type = " + type);
//
//        WifiConfiguration config = new WifiConfiguration();
//        config.allowedAuthAlgorithms.clear();
//        config.allowedGroupCiphers.clear();
//        config.allowedKeyManagement.clear();
//        config.allowedPairwiseCiphers.clear();
//        config.allowedProtocols.clear();
//        config.SSID = "\"" + SSID + "\"";
//
//        //增加热点时候 如果已经存在SSID 则将SSID先删除以防止重复SSID出现
//        WifiConfiguration tempConfig = wifiAdmin.IsExsits(SSID);
//        if (tempConfig != null) {
//            settingWifiAdmin.wifiManager.removeNetwork(tempConfig.networkId);
//        }
//
//        // 分为三种情况：没有密码   用wep加密  用wpa加密
//        if(Type == WifiCipherType.WIFICIPHER_NOPASS)
//        {
//            config.hiddenSSID = true;
////        config.wepKeys[0] = "";
//            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
////        config.wepTxKeyIndex = 0;
//        }
//        if (type == SECURITY_NONE) {   // WIFICIPHER_NOPASS
//            config.wepKeys[0] = "";
//            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
//            config.wepTxKeyIndex = 0;
//
//        } else if (type == SECURITY_WEP) {  //  WIFICIPHER_WEP
//            config.hiddenSSID = true;
//            config.wepKeys[0] = """ + password + """;
//            config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.SHARED);
//            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
//            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
//            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
//            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);
//            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
//            config.wepTxKeyIndex = 0;
//
//        } else if (type == SECURITY_PSK) {   // WIFICIPHER_WPA
//            config.preSharedKey = """ + password + """;
//            config.hiddenSSID = true;
//            config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
//            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
//            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
//            config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
//            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
//            config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
//            config.status = WifiConfiguration.Status.ENABLED;
//        }
//        return config;
//    }
//
//}
