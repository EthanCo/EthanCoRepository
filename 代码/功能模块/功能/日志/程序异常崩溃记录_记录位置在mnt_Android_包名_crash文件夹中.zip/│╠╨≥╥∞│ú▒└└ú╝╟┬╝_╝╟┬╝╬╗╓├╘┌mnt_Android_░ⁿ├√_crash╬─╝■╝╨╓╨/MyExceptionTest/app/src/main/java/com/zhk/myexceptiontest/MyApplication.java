package com.zhk.myexceptiontest;

/**
 * Created by YOLANDA on 2015-10-08.
 */
public class MyApplication extends BaseApplication {
    @Override
    protected void onBaseCreate() {
        
    }
}
