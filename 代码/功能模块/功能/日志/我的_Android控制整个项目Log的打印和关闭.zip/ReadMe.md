## LogUtil ##
	控制日志的输出

### BuildConfig.DEBUG ###
    ADT(r17)中添加了一个新功能可以允许开发者只在Debug模式下允许某些代码。  
	Build系统生成一个名称为BuildConfig的类，该类包含一个DEBUG 常量，该常量会根据您的Build类型自动设置值。  
	您可以通过(BuildConfig.DEBUG) 常量来编写只在Debug模式下运行的代码。
    如果有些代码不想在发布后执行，就可以使用该功能。
    比如调试日志，你不想在软件发布后被其他开发者看到，过去的方式是你设置一个全局变量，标记软件为DEBUG模式还是发布模式。
- 在debug或release版本中，自动编译为true
- 在正式发布的版本中，自动编译为false

### LOG_LEVEL ###
	输出级别
- 5 全部输出
- 0 全部不输出