package com.zhk.mytest1012;

import android.util.Log;

public class LogUtil {
    public static int ERROR = 1;
    public static int WARN = 2;
    public static int INFO = 3;
    public static int DEBUG = 4;
    public static int VERBOS = 5;

    public static int LOG_LEVEL = 5; //输出级别 5:全部输出 0:全部不输出
    public static boolean isDebug = BuildConfig.DEBUG; //是否是调试状态

    public static void e(String tag, String msg) {
        if (isDebug && LOG_LEVEL >= ERROR)
            Log.e(tag, msg);
    }

    public static void w(String tag, String msg) {
        if (isDebug && LOG_LEVEL >= WARN)
            Log.w(tag, msg);
    }

    public static void w(String tag, String msg, Throwable tr) {
        if (isDebug && LOG_LEVEL >= WARN)
            Log.w(tag, msg, tr);
    }

    public static void i(String tag, String msg) {
        if (isDebug && LOG_LEVEL >= INFO)
            Log.i(tag, msg);
    }

    public static void d(String tag, String msg) {
        if (isDebug && LOG_LEVEL >= DEBUG)
            Log.d(tag, msg);
    }

    public static void v(String tag, String msg) {
        if (isDebug && LOG_LEVEL >= VERBOS)
            Log.v(tag, msg);
    }
}
