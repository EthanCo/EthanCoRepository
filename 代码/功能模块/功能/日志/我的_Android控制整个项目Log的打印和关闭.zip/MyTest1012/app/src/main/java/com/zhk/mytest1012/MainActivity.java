package com.zhk.mytest1012;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LogUtil.v(TAG, "onCreate ");
        LogUtil.d(TAG, "onCreate ");
        LogUtil.i(TAG, "onCreate ");
        LogUtil.w(TAG, "onCreate ");
        LogUtil.e(TAG, "onCreate ");
    }
}
