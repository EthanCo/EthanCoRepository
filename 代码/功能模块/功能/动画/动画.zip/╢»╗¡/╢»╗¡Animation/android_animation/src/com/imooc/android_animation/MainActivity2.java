package com.imooc.android_animation;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity2 extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main2);
	}
	
}
