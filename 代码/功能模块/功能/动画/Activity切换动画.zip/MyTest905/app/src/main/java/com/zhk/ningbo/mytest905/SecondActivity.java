package com.zhk.ningbo.mytest905;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Zhk on 2015/9/5.
 */
public class SecondActivity extends AppCompatActivity {
    private FragmentManager fm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_main);


        fm = getSupportFragmentManager();
        Fragment fragment = fm.findFragmentById(getFragmentContainer());
        if (fragment == null) {
            fragment = new SecondFragment();
            fm.beginTransaction().add(getFragmentContainer(), fragment).commit();
        }
    }

    private int getFragmentContainer() {
        return R.id.second_activity_container;
    }
}
