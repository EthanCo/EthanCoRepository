package com.zhk.ningbo.mytest905;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    private Button btnJump;

    public MainActivityFragment() {
    }

	/*******************************与Fragment实现OnTouchEvent相关的部分，与Activity动画无关*********************************/
    private MainActivity.MyOnTouchEvent myOnTouchEvent = new MainActivity.MyOnTouchEvent() {
        @Override
        public boolean onTouchEvent(MotionEvent event) {
            Log.i("zhklog", "Fragment ontouchEvent");
            return false;
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((MainActivity) getActivity()).addMyOnTouchEvent(myOnTouchEvent);
        return inflater.inflate(R.layout.fragment_main, container, false);
    }
	/*******************************与Fragment实现OnTouchEvent相关的部分，与Activity动画无关*********************************/

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        btnJump = (Button) view.findViewById(R.id.btnJump);
        btnJump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), SecondActivity.class);
                startActivity(intent);
                //getActivity().overridePendingTransition(R.anim.activity_open, R.anim.activity_curr); 方法二
            }
        });
        super.onViewCreated(view, savedInstanceState);
    }
}
