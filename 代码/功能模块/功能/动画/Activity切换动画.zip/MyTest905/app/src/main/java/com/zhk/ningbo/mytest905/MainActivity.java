package com.zhk.ningbo.mytest905;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private float originX;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

	/*******************************与Fragment实现OnTouchEvent相关的部分，与Activity动画无关*********************************/
	
    public interface MyOnTouchEvent {
        boolean onTouchEvent(MotionEvent event);
    }

    public List<MyOnTouchEvent> touchEventList = new ArrayList<>();

    public void addMyOnTouchEvent(MyOnTouchEvent myOnTouchEvent) {
        touchEventList.add(myOnTouchEvent);
    }

    public void removeOnTouchEvent(MyOnTouchEvent myOnTouchEvent) {
        touchEventList.remove(myOnTouchEvent);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        for (MyOnTouchEvent myOnTouchEvent : touchEventList) {
            myOnTouchEvent.onTouchEvent(event);
        }

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                Log.i("zhklog", "MainActivity onTouchEvent down");
                originX = event.getX();
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            case MotionEvent.ACTION_UP:
                if (event.getX() - originX > 50) {
                    Log.i("zhklog", "从左往右");
                } else if (event.getX() - originX < 50) {
                    Log.i("zhklog", "从右往左");
                }
                break;
            case MotionEvent.ACTION_CANCEL:
                break;
        }
        return super.onTouchEvent(event);
    }
	/*******************************与Fragment实现OnTouchEvent相关的部分，与Activity动画无关*********************************/
}
