/** Automatically generated file. DO NOT MODIFY */
package com.jikexueyuan.alphaanimation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}