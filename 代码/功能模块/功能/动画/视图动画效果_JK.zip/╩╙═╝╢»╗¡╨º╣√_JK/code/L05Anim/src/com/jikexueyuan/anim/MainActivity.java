package com.jikexueyuan.anim;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	
//	private AnimationSet as;
	

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
//        as= new AnimationSet(true);
//        as.setDuration(1000);
//        
//        AlphaAnimation aa = new AlphaAnimation(0, 1);
//        aa.setDuration(1000);
//        as.addAnimation(aa);
//        
//        TranslateAnimation ta = new TranslateAnimation(200, 0, 200, 0);
//        ta.setDuration(1000);
//        as.addAnimation(ta);

        findViewById(R.id.btnAnimMe).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
//				arg0.startAnimation(as);
				
				Animation a = AnimationUtils.loadAnimation(MainActivity.this, R.anim.anim);
				a.setAnimationListener(new Animation.AnimationListener() {
					
					@Override
					public void onAnimationStart(Animation animation) {
					}
					
					@Override
					public void onAnimationRepeat(Animation animation) {
					}
					
					@Override
					public void onAnimationEnd(Animation animation) {
						Toast.makeText(MainActivity.this, "Animation end", Toast.LENGTH_SHORT).show();
					}
				});
				
				arg0.startAnimation(a);
			}
		});
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


}
