/** Automatically generated file. DO NOT MODIFY */
package com.zhk.myhandler_looper_messagequeue;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}