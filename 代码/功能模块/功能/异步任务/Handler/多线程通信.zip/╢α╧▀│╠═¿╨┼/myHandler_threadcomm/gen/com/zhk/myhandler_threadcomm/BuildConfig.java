/** Automatically generated file. DO NOT MODIFY */
package com.zhk.myhandler_threadcomm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}