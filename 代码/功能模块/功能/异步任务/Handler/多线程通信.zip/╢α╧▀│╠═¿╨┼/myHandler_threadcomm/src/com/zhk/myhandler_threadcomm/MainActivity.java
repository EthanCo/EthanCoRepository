package com.zhk.myhandler_threadcomm;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.os.UserHandle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
/*
 * 1.���̺߳����̵߳Ļ���ͨѶ
	2.ȡ��queue��δ����������
 * */
public class MainActivity extends Activity implements OnClickListener {
	int a =1;
	int b=2;
	int c =3;
	//���߳�handler
	private Handler uHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			System.out.println("main handler");
			tHandler.sendEmptyMessageDelayed(b, 2500);
		};
	};

	private Handler tHandler;

	private Button btSend;

	private Button btCancel;
	private HandlerThread hThread;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btSend = (Button)findViewById(R.id.btSend);
		btCancel = (Button)findViewById(R.id.btCancel);
		btSend.setOnClickListener(this);
		btCancel.setOnClickListener(this);
		hThread = new HandlerThread("zhe shi mingzi a");
		hThread.start();
		tHandler = new Handler(hThread.getLooper()) {


			//���߳�handler
			@Override
			public void handleMessage(Message msg) {
				System.out.println("thread handler");
				uHandler.sendEmptyMessageDelayed(c, 5000);
			}
		};
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btSend:
//			uHandler.sendEmptyMessage(c);
			tHandler.sendEmptyMessage(a);
			break;
		case R.id.btCancel:
			Log.i("log.i","remove");

			uHandler.removeMessages(c);
			tHandler.removeMessages(b);
			break;
		default:
			break;
		}
	}
}
