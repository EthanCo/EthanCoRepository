package com.zhk.myhandler;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;

/*
 * Handler�����ã�
 * 1.�ṩ����UI��һ�׻���
 * 2.Ҳ��һ����Ϣ��������
 * */
public class MainActivity extends Activity {

	private TextView tv;
	private ImageView iv;
	private Button btStop;
	
	private int images[] = {R.drawable.a,R.drawable.b,R.drawable.c};
	private int index;

	private Runnable r = new MyRunnable();
	
	class MyRunnable implements Runnable{

		@Override
		public void run() {
			index++;
			index = index%images.length;
			iv.setImageResource(images[index]);
			mHandler.postDelayed(r, 1000);
		}
	}
	
	private Handler mHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			tv.setText(""+msg.arg1+" - "+msg.arg2+" - "+msg.obj);
		};
	};
	
	/*
	 * ���Խػ�handler���͵���Ϣ
	 * */
	private Handler mHandler2 = new Handler(new Handler.Callback() {
		
		@Override
		public boolean handleMessage(Message msg) {
			Toast.makeText(getApplicationContext(), "1", Toast.LENGTH_SHORT).show();
			return false; //�������Ϊtrue,���ʾ�ػ�ɹ�,2����ִ��
		}
	}){
		public void handleMessage(android.os.Message msg) {
			Toast.makeText(getApplicationContext(), "2", Toast.LENGTH_SHORT).show();
		};
	};
	


	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		tv = (TextView) findViewById(R.id.tv);
		iv = (ImageView) findViewById(R.id.iv); //��ʵ��Ӧ������ȫ����ʹ��viewpager,�˴�Ϊ�˼�����
		btStop =(Button) findViewById(R.id.btStop);
		


//		new Thread() {
//			public void run() {
//				try {
//					Thread.sleep(1000);
//					// tv.setText("����UI");//����ֱ�������߳������
//					mHandler.post(new Runnable() {
//
//						@Override
//						public void run() {
//							tv.setText("����UI");
//						}
//					});
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			};
//		}.start();
//		
		
		mHandler.postDelayed(r, 1000);
		
		new Thread(){
			public void run() {
				try {
					Thread.sleep(2000);
					//�Լ�������Message����
//					Message msg = new Message();
//					msg.arg1=88;
//					msg.arg2=100;
//					Person p = new Person();
//					p.setName("�����");
//					p.setAge(18);
//					msg.obj=p;
//					mHandler.sendMessage(msg);
					//��ȡϵͳ��Message����(��Щ�����û��Ҫȥ����һ��Message����,����ȥ����һ��ϵͳ��message)
					Message msg = mHandler.obtainMessage();
					msg.arg1=88;
					msg.arg2=100;
					Person p = new Person();
					p.setName("�����");
					p.setAge(18);
					msg.obj=p;
//					mHandler.sendMessage(msg);
					msg.sendToTarget(); //�ڲ���������mHandler.sendMessage(msg)
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			};
			
		}.start();
		
		btStop.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				mHandler.removeCallbacks(r); //��mHandler���Ƴ�Runnable r
				mHandler2.sendEmptyMessage(0); //��mHandler2������Ϣ
			}
		});
	}
	class Person {
		String name;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		int age;
		@Override
		public String toString() {
			return "Person [name=" + name + ", age=" + age + "]";
		}
	}
}
