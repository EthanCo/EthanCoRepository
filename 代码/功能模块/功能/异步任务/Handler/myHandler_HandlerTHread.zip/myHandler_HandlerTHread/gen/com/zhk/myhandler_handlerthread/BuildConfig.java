/** Automatically generated file. DO NOT MODIFY */
package com.zhk.myhandler_handlerthread;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}