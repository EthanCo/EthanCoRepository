package com.zhk.myhandler;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Build;

/*
 * Handler�����ã�
 * 1.�ṩ����UI��һ�׻���
 * 2.Ҳ��һ����Ϣ��������
 * */
public class MainActivity extends Activity {

	private TextView tv;
	private ImageView iv;
	
	private int images[] = {R.drawable.a,R.drawable.b,R.drawable.c};
	private int index;
	private Runnable r = new MyRunnable();
	
	class MyRunnable implements Runnable{

		@Override
		public void run() {
			index++;
			index = index%images.length;
			iv.setImageResource(images[index]);
			mHandler.postDelayed(r, 1000);
		}
		
	}
	
	private Handler mHandler = new Handler();

	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		tv = (TextView) findViewById(R.id.tv);
		iv = (ImageView) findViewById(R.id.iv); //��ʵ��Ӧ������ȫ����ʹ��viewpager,�˴�Ϊ�˼�����

		new Thread() {
			public void run() {
				try {
					Thread.sleep(1000);
					// tv.setText("����UI");//����ֱ�������߳������
					mHandler.post(new Runnable() {

						@Override
						public void run() {
							tv.setText("����UI");
						}
					});
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			};
		}.start();
		
		mHandler.postDelayed(r, 1000);  //�ӳ�post		
	}
}
