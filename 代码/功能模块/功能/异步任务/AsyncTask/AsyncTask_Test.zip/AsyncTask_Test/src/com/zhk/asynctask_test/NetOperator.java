package com.zhk.asynctask_test;

//ģ�����绷��  
public class NetOperator {

	public void operator() {
		try {
			//����1��  
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block  
			e.printStackTrace();
		}
	}
}
