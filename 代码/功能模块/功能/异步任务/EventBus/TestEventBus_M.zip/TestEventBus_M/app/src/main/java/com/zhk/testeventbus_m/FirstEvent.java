package com.zhk.testeventbus_m;

/**
 *
 * Created by YOLANDA on 2015/7/27
 */
public class FirstEvent {

    private String mMsg;
    public FirstEvent(String msg) {
        mMsg = msg;
    }
    public String getMsg(){
        return mMsg;
    }
}
