package com.zhk.testeventbus_m;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import de.greenrobot.event.EventBus;

/**
 * Created by YOLANDA on 2015/7/27
 */
public class SecondActivity extends Activity {

    private Button btnFristEvent;
    private Button btn_FirstEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        initView();
        initEvent();
    }

    private void initView(){
        btnFristEvent = (Button) findViewById(R.id.btn_first_event);
    }

    private void initEvent(){
        btnFristEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EventBus.getDefault().post(new FirstEvent("FirstEvent btn clicked"));
            }
        });
    }
}
