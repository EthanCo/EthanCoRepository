package com.zhk.ningbo.mypopuptest;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private LayoutInflater mLayoutInflater;
    private List<Integer> popupLayoutList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btn = (Button) findViewById(R.id.btn);
        mLayoutInflater = LayoutInflater.from(this);
        popupLayoutList = new ArrayList<Integer>();
        popupLayoutList.add(R.layout.layout_1);
        popupLayoutList.add(R.layout.layout_2);
        btn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               DisplayMetrics outMetrics = new DisplayMetrics();
               getWindowManager().getDefaultDisplay().getMetrics(outMetrics);
               int mScreenHeight = outMetrics.heightPixels;

               View view = mLayoutInflater.inflate(R.layout.layout_popup, null);
               ViewPager viewPager = (ViewPager) view.findViewById(R.id.viewPager);
               viewPager.setAdapter(new PagerAdapter() {
                   @Override
                   public Object instantiateItem(ViewGroup container, int position) {
                       View view = mLayoutInflater.inflate(popupLayoutList.get(position), null);
                       container.addView(view);
                       return view;
                   }

                   @Override
                   public void destroyItem(ViewGroup container, int position, Object object) {
                       container.removeView((View) object);
                   }

                   @Override
                   public boolean isViewFromObject(View view, Object obj) {
                       return view == obj;
                   }

                   @Override
                   public int getCount() {
                       return popupLayoutList.size();
                   }
               });
               PopupWindow popup = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, (int) (mScreenHeight * 0.6), true);
               popup.setTouchable(true);
               popup.setTouchInterceptor(new View.OnTouchListener() {
                   @Override
                   public boolean onTouch(View v, MotionEvent event) {
                       return false;
                   }
               });
               Drawable drawable = getResources().getDrawable(R.mipmap.popup_bg);
               drawable.setAlpha(255);
               popup.setBackgroundDrawable(drawable);
               //popup.setAnimationStyle(R.style.anim_popup_dir);
               popup.setOnDismissListener(new PopupWindow.OnDismissListener() {
                   @Override
                   public void onDismiss() {

                   }
               });

               popup.showAsDropDown(btn, 0, 0);
           }
       }
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
