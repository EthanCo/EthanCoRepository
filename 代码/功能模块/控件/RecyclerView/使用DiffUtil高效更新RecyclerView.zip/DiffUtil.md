## 使用DiffUtil高效更新RecyclerView ##
DiffUtil是RecyclerView support library v7 24.2.0 版本中新增加的类  

用于比较两个数据列表并能计算出一系列将旧数据表转换成新数据表的操作。  

DiffUtil是一个工具类，当你的RecyclerView需要更新数据时，将旧数据集传给它，它就能快速告知adapter有哪些数据需要更新。  

## 优势 ##

相比直接调用adapter.notifyDataSetChange()方法  

	DiffUtil能再收到数据集后，提高UI更新的效率，而且你也不需要自己对新老数据集进行比较了  

凡是数据集的比较DiffUtil都能做，所以用处并不止于更新RecyclerView，DiffUtil也提供了回调让你可以进行其他操作。本文只讨论使用DiffUtil更新RecyclerView。  

DiffUtil用最简单的方式将一个数据集转换为另一个。  
DiffUtil可以识别意向数据在数据集中的移动。(如果数据集中数据不存在移位情况，你可以关闭移动识别功能来提高性能)  

> 当数据集较大时，你应该在后台线程计算数据集的更新。  

## 使用 ##
使用DiffUtil时设计以下几个核心类  

### DiffUtil.Callback ###
最核心类，不要被命名困惑，它不像日常所使用的回调。你可以将它理解成 **比较新老数据集时的规则**  

### DiffUtil ###
通过静态方法DiffUtil.calculateDiff(DiffUtil.Callback)来计算数据集的更新。  

### DiffResult ###
DiffResult:是DiffUtil的计算结果对象，通过DiffResult.dispatchUpdatesTo(RecyclerView.Adapter)来进行更新。    

> DiffUtil可用于高效进行RecyclerView的数据更新，但DiffUtil本身的作用是计算数据集的最小更新。DiffUtil有强大的算法支撑，可以利用DiffUtil完成许多其他功能。

具体请看  

[https://developer.android.com/reference/android/support/v7/util/DiffUtil.html](https://developer.android.com/reference/android/support/v7/util/DiffUtil.html)  
[https://medium.com/@nullthemall/diffutil-is-a-must-797502bc1149#.mqkrxfjgj](https://medium.com/@nullthemall/diffutil-is-a-must-797502bc1149#.mqkrxfjgj)  

## Demo ##


