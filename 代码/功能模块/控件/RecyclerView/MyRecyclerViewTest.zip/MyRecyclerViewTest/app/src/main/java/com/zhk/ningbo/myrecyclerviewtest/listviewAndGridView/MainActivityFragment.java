package com.zhk.ningbo.myrecyclerviewtest.listviewAndGridView;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.zhk.ningbo.myrecyclerviewtest.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    private RecyclerView mRecyclerView;
    private List<String> mList;
    private MyAdapter mAdapter;

    public MainActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        setHasOptionsMenu(true);//让fragement 的OptionsMenu有效
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initData();

        mRecyclerView = (RecyclerView) view.findViewById(R.id.main_recyclerview);

        mAdapter = new MyAdapter(getActivity(), mList);
        mAdapter.setOnItemClickListener(new MyOnItemClickListener(getActivity())); //设置监听，需自己定义，RecyclerView.Adapter没有setOnItemClickListener的监听
        mRecyclerView.setAdapter(mAdapter);

        //必须设置LayoutManager(布局管理)
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(linearLayoutManager);

        //设置RecyclerView的Item间分割线
        //若要设置分割线的颜色等，需在styles中写上<item name="android:listDivider">@drawable/divider_test</item> 温馨提示:若有多个style，如v11,v14的style，都要写
        //mRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST)); //系统并没有提供一个抽象类，所有要自己写或Github上开源的 https://gist.github.com/alexfu/0f464fc3742f134ccd1e

        //添加动画
        mRecyclerView.setItemAnimator(new DefaultItemAnimator()); //系统只提供了DefaultItemAnimator这一种动画效果，Github上的:https://github.com/gabrielemariotti/RecyclerViewItemAnimators
    }

    private void initData() {
        mList = new ArrayList<String>();
        for (int i = 'A'; i < 'z'; i++) {
            mList.add("" + (char) i);
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_main, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_Add:
                mAdapter.AddData(1);
                break;
            case R.id.action_Delete:
                mAdapter.deleteDate(1);
                break;
            case R.id.action_listView: //垂直的ListView
                mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
                return true;
            case R.id.action_gridView:
                mRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 3)); //3列
                return true;
            case R.id.action_hor_gridViw: //水平的gridView
                mRecyclerView.setLayoutManager(new StaggeredGridLayoutManager(5, StaggeredGridLayoutManager.HORIZONTAL)); //5列
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

class MyOnItemClickListener implements MyAdapter.OnItemClickListener {

    private final Context mContext;

    public MyOnItemClickListener(Context context) {
        this.mContext = context;
    }

    @Override
    public void onItemClick(View view, int position) {
        Toast.makeText(mContext, "Click " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onItemLongClick(View view, int position) {
        Toast.makeText(mContext, "Long Click " + position, Toast.LENGTH_SHORT).show();
    }
}
