package com.zhk.ningbo.myrecyclerviewtest.listviewAndGridView;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.zhk.ningbo.myrecyclerviewtest.R;

import java.util.List;

/**
 * Created by Zhk on 2015/8/23.
 */
public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private final Context mContext;
    private final List<String> mDatas;
    private final LayoutInflater mInflater;

    public interface OnItemClickListener {
        void onItemClick(View view, int position);

        void onItemLongClick(View view, int position);
    }

    private OnItemClickListener mOnItemClickListener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mOnItemClickListener = listener;
    }

    public MyAdapter(Context context, List<String> datas) {
        this.mContext = context;
        this.mDatas = datas;
        this.mInflater = LayoutInflater.from(context);
    }

    @Override //获取Item的count
    public int getItemCount() {
        return mDatas.size();
    }

    @Override //创建ViewHodler
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = mInflater.inflate(R.layout.item_simple_textview, viewGroup, false);
        MyViewHolder viewHolder = new MyViewHolder(view); //itemView : item的布局
        return viewHolder;
    }

    @Override //绑定ViewHodler
    public void onBindViewHolder(final MyViewHolder myViewHolder, final int i) {
        myViewHolder.tv.setText(mDatas.get(i));

        if (mOnItemClickListener != null) {
            myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int layoutPasition = myViewHolder.getLayoutPosition(); // notifyItemInserted(pos);不会刷新所有的View，所有并不会改变item的布局，所有在插入或删除item后position就会混乱，所有用这个
                    //mOnItemClickListener.onItemClick(myViewHolder.itemView, i);
                    mOnItemClickListener.onItemClick(myViewHolder.itemView, layoutPasition);
                }
            });
            myViewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    int layoutPosition = myViewHolder.getLayoutPosition(); // notifyItemInserted(pos);不会刷新所有的View，所有并不会改变item的布局，所有在插入或删除item后position就会混乱，所有用这个
                    //mOnItemClickListener.onItemLongClick(myViewHolder.itemView, i);
                    mOnItemClickListener.onItemLongClick(myViewHolder.itemView, layoutPosition);
                    return true;
                }
            });
        }
    }

    public void AddData(int pos) {
        mDatas.add(pos, "Insert One");
        //notifyItemChanged(pos);
        notifyItemInserted(pos); //注意要调用这个，而不是上面那个!!!!!!!!!!!!!!!!!!!!!!!!! 不会刷新所有的View
    }

    public void deleteDate(int pos) {
        mDatas.remove(pos);
        //notifyItemChanged(pos);
        notifyItemRemoved(pos); //Remove
    }
}

class MyViewHolder extends RecyclerView.ViewHolder {
    TextView tv;

    public MyViewHolder(View itemView) { //itemVIew:item的rootview
        super(itemView);
        tv = (TextView) itemView.findViewById(R.id.id_tv);
    }
}
