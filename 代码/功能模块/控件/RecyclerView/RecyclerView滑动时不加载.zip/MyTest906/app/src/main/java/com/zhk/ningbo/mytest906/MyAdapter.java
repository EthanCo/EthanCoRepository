package com.zhk.ningbo.mytest906;

import android.graphics.Bitmap;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Zhk on 2015/9/6.
 */
public class MyAdapter extends RecyclerView.Adapter<ItemViewHodler> {

    private final List<ItemBean> data;
    private List<ItemViewHodler> viewHolderList = new ArrayList<>();
    private List<Integer> loadList = new ArrayList<>();

    public MyAdapter(List<ItemBean> data) {
        this.data = data;
    }

    @Override
    public ItemViewHodler onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater mLayoutInflater = LayoutInflater.from(parent.getContext());
        View view = mLayoutInflater.inflate(R.layout.item, null);
        return new ItemViewHodler(view);
    }

    @Override
    public void onBindViewHolder(ItemViewHodler holder, int position) {
        viewHolderList.add(holder);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void loadItem(int start, int end) {
        if (end <= viewHolderList.size()) {
            for (int i = start; i <= end; i++) {
                ItemViewHodler viewHodler = viewHolderList.get(i);
                if (viewHodler.imageVIew.getDrawable() == null) {
                    ItemBean itemBean = data.get(start);
                    final int finalI = i;
                    ImageLoader.getInstance().displayImage(itemBean.getUrl(), viewHodler.imageVIew, new ImageLoadingListener() {
                        @Override
                        public void onLoadingStarted(String s, View view) {
                            loadList.add(finalI);
                        }

                        @Override
                        public void onLoadingFailed(String s, View view, FailReason failReason) {

                        }

                        @Override
                        public void onLoadingComplete(String s, View view, Bitmap bitmap) {
                            loadList.remove(Integer.valueOf(finalI));
                        }

                        @Override
                        public void onLoadingCancelled(String s, View view) {

                        }
                    });
                    viewHodler.tvInfo.setText("标题");
                }
            }
        }
    }

    public void cancelLoadItem() {
        for (Integer positon : loadList) {
            ImageLoader.getInstance().cancelDisplayTask(viewHolderList.get(positon).imageVIew);
        }
    }
}

class ItemViewHodler extends RecyclerView.ViewHolder {

    TextView tvInfo;
    ImageView imageVIew;

    public ItemViewHodler(View itemView) {
        super(itemView);

        imageVIew = (ImageView) itemView.findViewById(R.id.imageView);
        tvInfo = (TextView) itemView.findViewById(R.id.tvInfo);
    }
}
