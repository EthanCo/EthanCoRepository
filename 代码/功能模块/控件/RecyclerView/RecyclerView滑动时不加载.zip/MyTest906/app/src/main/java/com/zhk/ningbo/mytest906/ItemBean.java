package com.zhk.ningbo.mytest906;

/**
 * Created by Zhk on 2015/9/6.
 */
public class ItemBean {
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    String url;

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    String info;

    public ItemBean(String url, String info) {
        this.url = url;
        this.info = info;
    }
}
