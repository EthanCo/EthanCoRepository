package com.zhk.ningbo.mytest906;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    private RecyclerView recyclerView;
    private SwipeRefreshLayout refreshSwipe;
    private List<ItemBean> list;
    private MyAdapter myAdapter;
    private GridLayoutManager layoutManager;

    public MainActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        refreshSwipe = (SwipeRefreshLayout) view.findViewById(R.id.swipe_refresh_widget);
        refreshSwipe.setEnabled(false);


        list = new ArrayList<ItemBean>();
        String url = "http://cdnq.duitang.com/uploads/item/201408/23/20140823055947_8fX48.png";
        //String url = "http://imgsrc.baidu.com/forum/w%3D580/sign=aa001a867a3e6709be0045f70bc69fb8/342fb744ebf81a4c5c890a68d22a6059242da6f0.jpg";
        for (int i = 0; i < 100; i++) {
            list.add(new ItemBean(url, "标题"));
        }

        myAdapter = new MyAdapter(list);
        recyclerView.setAdapter(myAdapter);
        recyclerView.setHasFixedSize(true);
        //recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        layoutManager = new GridLayoutManager(getActivity(), 4);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    Log.i("zhklog", "frist:" + layoutManager.findFirstVisibleItemPosition() + " end:" + layoutManager.findLastVisibleItemPosition());
                    myAdapter.loadItem(layoutManager.findFirstVisibleItemPosition(), layoutManager.findLastVisibleItemPosition());
                } else {
                    Log.i("zhklog", "cancelLoadItem");
                    myAdapter.cancelLoadItem();
                }
            }
        });

        ((MainActivity) getActivity()).addOnFocusChanged(new MainActivity.OnFocusChanged() {
            @Override
            public void onFocusChanged(boolean hasFocus) {
                if (hasFocus) {
                    Log.i("zhklog", "onFocusChanged");
                    myAdapter.loadItem(layoutManager.findFirstVisibleItemPosition(), layoutManager.findLastVisibleItemPosition());
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
