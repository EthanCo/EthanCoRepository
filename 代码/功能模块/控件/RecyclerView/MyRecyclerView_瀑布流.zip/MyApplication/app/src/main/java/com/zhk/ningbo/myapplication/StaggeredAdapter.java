package com.zhk.ningbo.myapplication;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 瀑布流Adapter 需动态的控制item的高度
 * 在这里 高度用随机数模拟
 * Created by Zhk on 2015/8/23.
 */
public class StaggeredAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private final Context mContext;
    private final List<String> mDatas;
    private final LayoutInflater mInflater;
    private List<Integer> mHeihts;

    public interface OnItemClickListener {
        void onItemClick(View view, int position);

        void onItemLongClick(View view, int position);
    }

    private OnItemClickListener mOnItemClickListener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mOnItemClickListener = listener;
    }

    public StaggeredAdapter(Context context, List<String> datas) {
        this.mContext = context;
        this.mDatas = datas;
        this.mInflater = LayoutInflater.from(context);

        mHeihts = new ArrayList<>();
        for (int i = 0; i < mDatas.size(); i++) {
            mHeihts.add((int) (100 + Math.random() * 300));
        }
    }

    @Override //获取Item的count
    public int getItemCount() {
        return mDatas.size();
    }

    @Override //创建ViewHodler
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = mInflater.inflate(R.layout.item_simple_textview, viewGroup, false);
        MyViewHolder viewHolder = new MyViewHolder(view); //itemView : item的布局
        return viewHolder;
    }

    @Override //绑定ViewHodler
    public void onBindViewHolder(final MyViewHolder myViewHolder, final int i) {
        //设置Item的高度
        ViewGroup.LayoutParams lp = myViewHolder.itemView.getLayoutParams(); //viewgroup的LayoutParams
        lp.height = mHeihts.get(i);
        myViewHolder.itemView.setLayoutParams(lp);

        myViewHolder.tv.setText(mDatas.get(i));

        if (mOnItemClickListener != null) {
            myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int layoutPasition = myViewHolder.getLayoutPosition(); // notifyItemInserted(pos);不会刷新所有的View，所有并不会改变item的布局，所有在插入或删除item后position就会混乱，所有用这个
                    //mOnItemClickListener.onItemClick(myViewHolder.itemView, i);
                    mOnItemClickListener.onItemClick(myViewHolder.itemView, layoutPasition);
                }
            });
            myViewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    int layoutPosition = myViewHolder.getLayoutPosition(); // notifyItemInserted(pos);不会刷新所有的View，所有并不会改变item的布局，所有在插入或删除item后position就会混乱，所有用这个
                    //mOnItemClickListener.onItemLongClick(myViewHolder.itemView, i);
                    mOnItemClickListener.onItemLongClick(myViewHolder.itemView, layoutPosition);
                    return true;
                }
            });
        }
    }

    public void AddData(int pos) {
        mDatas.add(pos, "Insert One");
        //notifyItemChanged(pos);
        notifyItemInserted(pos); //注意要调用这个，而不是上面那个!!!!!!!!!!!!!!!!!!!!!!!!!
    }

    public void deleteDate(int pos) {
        mDatas.remove(pos);
        //notifyItemChanged(pos);
        notifyItemRemoved(pos); //Remove
    }
}

class MyViewHolder extends RecyclerView.ViewHolder {
    TextView tv;

    public MyViewHolder(View itemView) { //itemVIew:item的rootview
        super(itemView);
        tv = (TextView) itemView.findViewById(R.id.id_tv);
    }
}
