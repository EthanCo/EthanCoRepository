package com.zhk.ningbo.testpopupmenu_m;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.internal.view.menu.MenuPopupHelper;
import android.support.v7.widget.PopupMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.lang.reflect.Field;


/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    private View view;
    private Button btnShow;
    private Button btnShow2;

    public MainActivityFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_main, container, false);
        btnShow = (Button) view.findViewById(R.id.btn_show_popupMenu);
        btnShow2 = (Button) view.findViewById(R.id.btn_show_popupMenu2);
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(getActivity(), v);
                popup.inflate(R.menu.menu_main);
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                    @Override
                    public boolean onMenuItemClick(MenuItem arg0) {
                        switch (arg0.getItemId()) {
                            case R.id.menu_item1:
                                Toast.makeText(getActivity(), "show", Toast.LENGTH_SHORT).show();
                                break;
                        }
                        return false;
                    }
                });
                try {
                    Field mpopup = popup.getClass().getDeclaredField("mPopup");
                    mpopup.setAccessible(true);
                    MenuPopupHelper mPopup = (MenuPopupHelper) mpopup.get(popup);
                    mPopup.setForceShowIcon(true);
                } catch (Exception e) {

                }
                popup.show();
            }
        });
        btnShow2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                com.zhk.ningbo.testpopupmenu_m.PopupMenu popup = new com.zhk.ningbo.testpopupmenu_m.PopupMenu(getActivity(), v);
                popup.inflate(R.menu.menu_main);
                popup.setOnMenuItemClickListener(new com.zhk.ningbo.testpopupmenu_m.PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem var1) {
                        return false;
                    }
                });
                popup.show();
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }
}
