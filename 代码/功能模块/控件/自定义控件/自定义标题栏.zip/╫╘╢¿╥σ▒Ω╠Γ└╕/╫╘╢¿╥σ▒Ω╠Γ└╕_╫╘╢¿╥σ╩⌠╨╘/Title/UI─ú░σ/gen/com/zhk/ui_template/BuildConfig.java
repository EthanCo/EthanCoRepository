/** Automatically generated file. DO NOT MODIFY */
package com.zhk.ui_template;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}