package com.zhk.myframelayout;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MyFragment extends FrameLayout {

	private CharSequence mDateTvText;
	private CharSequence mMsgTvText;
	private TextView mDateTextView;
	private TextView mMsgTextView;

	public MyFragment(Context context) {
		super(context);
	}

	public MyFragment(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

    public MyFragment(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        View view1 = LayoutInflater.from(context).inflate(R.layout.from_msg, this, true);  //layoutInflater.from(context) 
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.my_framelayout_property);

        mDateTvText = a.getText(R.styleable.my_framelayout_property_text_date);
        mMsgTvText = a.getText(R.styleable.my_framelayout_property_text_msg);
        
        a.recycle();
//        view1.setVisibility(View.GONE); //��view��Ϊ���ɼ�
    }
    
    @Override
    protected void onFinishInflate() {
//    	super.onFinishInflate();
        this.mDateTextView= (TextView) this.findViewById(R.id.from_msg_date);
        if (this.mDateTvText != null) {
            this.mDateTextView.setText(mDateTvText);
        }
        this.mMsgTextView = (TextView)this.findViewById(R.id.from_msg_msg);
        if(this.mMsgTextView!=null){
        	this.mMsgTextView.setText(mMsgTvText);
        }
    }
}
