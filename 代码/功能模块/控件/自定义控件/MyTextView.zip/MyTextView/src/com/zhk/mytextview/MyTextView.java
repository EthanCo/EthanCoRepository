package com.zhk.mytextview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.TextView;

public class MyTextView extends TextView {
	public MyTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		Paint paint = new Paint();
		paint.setColor(Color.RED);//���廭����ɫ
		int tempX =this.getWidth()-1;
		int tempY =this.getHeight()-1;
		canvas.drawLine(0, 0, tempX, 0, paint);//(0,0)��(tempX,0)
		canvas.drawLine(0, 0, 0, tempY, paint);//(0,0)dao(0,tempY)
		canvas.drawLine(tempX, 0, tempX, tempY, paint);//(tempX,0)��(tempX,tempY)
		canvas.drawLine(0, tempY, tempX, tempY, paint);//(0,tempX)��(0,tempY)
	}
}
