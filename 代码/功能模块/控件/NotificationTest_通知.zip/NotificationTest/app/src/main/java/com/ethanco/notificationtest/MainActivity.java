package com.ethanco.notificationtest;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public static final int NOTIFICATION_ID = 8899;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.btnShow).setOnClickListener(this);
        findViewById(R.id.btnCancle).setOnClickListener(this);
        findViewById(R.id.btnCancle2).setOnClickListener(this);
    }

    private static void showNotification(Context context, String path) {
        Notification.Builder builder = new Notification.Builder(context);
        Intent clickIntent = new Intent(context, NotificationClickReceiver.class); //点击通知之后要发送的广播
        clickIntent.setAction("dfsdfsdfd");
        clickIntent.putExtra("path", path);
        PendingIntent contentIntent = PendingIntent.getBroadcast(context, 0, clickIntent, 0);

        builder.setContentIntent(contentIntent);
        builder.setAutoCancel(true);
        builder.setSmallIcon(R.mipmap.ic_launcher);
        builder.setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.mipmap.ic_launcher));
        builder.setContentTitle("title");
        builder.setContentText("content");

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            //builder.setSubText("XXXXXXXXX");
            notificationManager.notify(NOTIFICATION_ID, builder.build());
        } else {
            notificationManager.notify(NOTIFICATION_ID, builder.getNotification());
        }
    }

    public static void cancelInstallNotification(Context context) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(NOTIFICATION_ID);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnShow:
                showNotification(this, "gggg");
                break;
            case R.id.btnCancle:
                cancelInstallNotification(this);
                break;
            case R.id.btnCancle2:
                Intent intent = new Intent(this, NotificationClickReceiver.class);
                sendBroadcast(intent);
                break;
            default:

        }
    }
}
