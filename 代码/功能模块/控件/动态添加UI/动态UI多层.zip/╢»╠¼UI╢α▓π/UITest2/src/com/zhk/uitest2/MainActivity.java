package com.zhk.uitest2;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

@SuppressLint("ResourceAsColor")
public class MainActivity extends Activity{

	private ImageView imgApple2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	public void click(View v){
		//�ֶ�����imageview
		FrameLayout mainLayout = (FrameLayout)findViewById(R.id.frameLayout);
        imgApple2 = new ImageView(this);
        imgApple2.setImageResource(R.drawable.ic_launcher);
        imgApple2.setId(1120);	//ע����� ����id
        imgApple2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "123", 1).show();
			}
		});
        FrameLayout.LayoutParams lp1 = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
//        lp1.addRule(RelativeLayout.ALIGN_TOP);
//        lp1.setMargins(30, 50, 100, 100);//(int left, int top, int right, int bottom)
        lp1.leftMargin=30;
        lp1.topMargin = 100;
        mainLayout.addView(imgApple2,lp1);
	}
	
	public void click2(View v){
		FrameLayout mainLayout =(FrameLayout) findViewById(R.id.frameLayout);
		RelativeLayout relativeLayout = new RelativeLayout(this);
		relativeLayout.setBackgroundColor(R.color.my_background);
		FrameLayout.LayoutParams lp1 = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
		ImageView imageView = new ImageView(this);
		imageView.setImageResource(R.drawable.codeimg);
		RelativeLayout.LayoutParams lp2 =  new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
		lp2.addRule(RelativeLayout.CENTER_IN_PARENT);
		relativeLayout.addView(imageView,lp2);
		mainLayout.addView(relativeLayout, lp1);
	}
}
