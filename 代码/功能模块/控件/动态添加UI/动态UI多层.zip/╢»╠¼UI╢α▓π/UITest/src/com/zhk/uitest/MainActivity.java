package com.zhk.uitest;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

@SuppressLint("ResourceAsColor")
public class MainActivity extends Activity implements OnClickListener{

	private ImageView imgApple2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	public void click(View v){
		//�ֶ�����imageview
        RelativeLayout mainLayout = (RelativeLayout)findViewById(R.id.relaGameZhaiGuoZi);
        imgApple2 = new ImageView(this);
        imgApple2.setImageResource(R.drawable.ic_launcher);
        imgApple2.setId(1120);	//ע����� ����id
        imgApple2.setOnClickListener(this);
        RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
//        lp1.addRule(RelativeLayout.ALIGN_TOP);
//        lp1.setMargins(30, 50, 100, 100);//(int left, int top, int right, int bottom)
        lp1.leftMargin=30;
        lp1.topMargin = 100;
        mainLayout.addView(imgApple2,lp1);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}
	
	public void click2(View v){
		RelativeLayout mainLayout =(RelativeLayout) findViewById(R.id.relaGameZhaiGuoZi);
		LinearLayout linearLayout = new LinearLayout(this);
		linearLayout.setBackgroundColor(R.color.my_background);
		RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
		ImageView imageView = new ImageView(this);
		imageView.setImageResource(R.drawable.codeimg);
		LinearLayout.LayoutParams lp2 =  new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
		lp2.gravity=Gravity.CENTER_VERTICAL; 
//		lp2.addRule(RelativeLayout.LEFT_OF, R.id.id_to_be_left_of); //ָ��id��
		linearLayout.addView(imageView,lp2);
		mainLayout.addView(linearLayout, lp1);
	}
}
