package com.ethanco.myfragmentdialog;

import android.content.DialogInterface;

/**
 * Created by YOLANDA on 2015-12-02.
 */
public class DialogButton {

    public DialogButton() {
    }

    public DialogInterface.OnMultiChoiceClickListener getOnMultiChoiceClickListener() {
        return onMultiChoiceClickListener;
    }

    public void setOnMultiChoiceClickListener(DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener) {
        this.onMultiChoiceClickListener = onMultiChoiceClickListener;
    }

    private DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener;

    public String getName() {
        if (null == name) {
            name = "";
        }
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DialogInterface.OnClickListener getOnClickListener() {
        if (onClickListener == null) {
            onClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //do nothing
                }
            };
        }
        return onClickListener;
    }

    public void setOnClickListener(DialogInterface.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public DialogButton(DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener) {
        this.onMultiChoiceClickListener = onMultiChoiceClickListener;
    }

    private String name;
    private DialogInterface.OnClickListener onClickListener;

    public DialogButton(DialogInterface.OnClickListener onClickListener) {
        this(null, onClickListener);
    }

    public DialogButton(String name, DialogInterface.OnClickListener onClickListener) {
        this.name = name;
        this.onClickListener = onClickListener;
    }

    public DialogButton(String name, DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener) {
        this.name = name;
        this.onMultiChoiceClickListener = onMultiChoiceClickListener;
    }

    @Override
    public String toString() {
        return getName();
    }
}
