package com.ethanco.myfragmentdialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.support.annotation.NonNull;

/**
 * Created by YOLANDA on 2015-12-02.
 */
public class AlertDialogFragment extends DialogFragment {
    String[] items = null;
    private final DialogBean dialogBean;

    public AlertDialogFragment(DialogBean dialogBean) {
        this.dialogBean = dialogBean;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder builder = getBuilder();
        switch (dialogBean.getType()) {
            case DialogBean.DIALOG_COMMON:
                builder.setMessage(dialogBean.getContent().get(0));
                builder.setPositiveButton(getDialogBtn(DialogBean.DIALOG_BUTTON_OK).getName(),
                        getDialogBtn(DialogBean.DIALOG_BUTTON_OK).getOnClickListener());
                builder.setNeutralButton(getDialogBtn(DialogBean.DIALOG_BUTTON_MIDDLE).getName(),
                        getDialogBtn(DialogBean.DIALOG_BUTTON_MIDDLE).getOnClickListener());
                builder.setNegativeButton(getDialogBtn(DialogBean.DIALOG_BUTTON_CANCEL).getName(),
                        getDialogBtn(DialogBean.DIALOG_BUTTON_CANCEL).getOnClickListener());
                break;
            case DialogBean.DIALOG_SELECT:
                items = dialogBean.getContent().toArray(new String[dialogBean.getContent().size()]);
                builder.setItems(items, getDialogBtn(DialogBean.DIALOG_BUTTON_CHECKED).getOnClickListener());
                break;
            case DialogBean.DIALOG_SINGLE_SELECT:
                items = dialogBean.getContent().toArray(new String[dialogBean.getContent().size()]);
                builder.setSingleChoiceItems(items, 0, getDialogBtn(DialogBean.DIALOG_BUTTON_CHECKED).getOnClickListener());
                builder.setPositiveButton(getDialogBtn(DialogBean.DIALOG_BUTTON_OK).getName(),
                        getDialogBtn(DialogBean.DIALOG_BUTTON_OK).getOnClickListener());
                break;
            case DialogBean.DIALOG_MULTI_SELECT:
                items = dialogBean.getContent().toArray(new String[dialogBean.getContent().size()]);
                final boolean[] checkedItems = new boolean[items.length];
                builder.setMultiChoiceItems(items, checkedItems, getDialogBtn(DialogBean.DIALOG_BUTTON_CHECKED).getOnMultiChoiceClickListener());
                builder.setPositiveButton(getDialogBtn(DialogBean.DIALOG_BUTTON_OK).getName(),
                        getDialogBtn(DialogBean.DIALOG_BUTTON_OK).getOnClickListener());
                break;
            default:
        }

        AlertDialog dialog = builder.create();
        return dialog;
    }

    @NonNull
    private AlertDialog.Builder getBuilder() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setCancelable(dialogBean.isCancelable());//屏蔽回退键
        builder.setTitle(dialogBean.getTitile());
        return builder;
    }


    private DialogButton getDialogBtn(int key) {
        DialogButton dialogButton = dialogBean.getButtonMap().get(key);
        return checkDialogButton(dialogButton);
    }

    @NonNull
    private DialogButton checkDialogButton(DialogButton dialogButton) {
        if (dialogButton == null) {
            dialogButton = new DialogButton();
        }
        return dialogButton;
    }
}
