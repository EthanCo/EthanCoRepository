package com.ethanco.myfragmentdialog;

import android.util.SparseArray;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by YOLANDA on 2015-12-02.
 */
public class DialogBean {
    /**
     * 肯定
     */
    public static final int DIALOG_BUTTON_OK = 587;
    /**
     * 否定
     */
    public static final int DIALOG_BUTTON_CANCEL = 843;

    /**
     * 中间的
     */
    public static final int DIALOG_BUTTON_MIDDLE = 907;

    /**
     * 正选中的
     */
    public static final int DIALOG_BUTTON_CHECKED = 666;

    public static final int DIALOG_COMMON = 886;

    /**
     * 单选
     */
    public static final int DIALOG_SELECT = 479;

    /**
     * 单选_有确定按钮
     */
    public static final int DIALOG_SINGLE_SELECT = 418;

    /**
     * 多选
     */
    public static final int DIALOG_MULTI_SELECT = 633;

    /**
     * 等待
     */
    public static final int DIALOG_WAIT = 723;

    /**
     * 默认普通对话框
     *
     * @param titile
     * @param contentStr
     */
    public DialogBean(String titile, String contentStr) {
        type = DIALOG_COMMON;
        this.content.add(contentStr);
        this.titile = titile;
    }

    public DialogBean(int type, String titile) {
        this(type, titile, null);
    }

    public DialogBean(int type, String titile, List<String> content) {
        this.type = type;
        this.titile = titile;
        if (content == null) {
            content = new ArrayList<>();
        }
        this.content = content;
    }

    private String titile;

    public List<String> getContent() {
        return content;
    }

    public void setContent(List<String> content) {
        this.content = content;
    }

    public void addItem(String s) {
        content.add(s);
    }

    private List<String> content = new ArrayList<String>();

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    private int type;

    public boolean isCancelable() {
        return cancelable;
    }

    public void setCancelable(boolean cancelable) {
        this.cancelable = cancelable;
    }

    private boolean cancelable;

    public String getTitile() {
        return titile;
    }

    public void setTitile(String titile) {
        this.titile = titile;
    }

    public SparseArray<DialogButton> getButtonMap() {
        return buttonMap;
    }

    private SparseArray<DialogButton> buttonMap = new SparseArray<DialogButton>();
    ;
}
