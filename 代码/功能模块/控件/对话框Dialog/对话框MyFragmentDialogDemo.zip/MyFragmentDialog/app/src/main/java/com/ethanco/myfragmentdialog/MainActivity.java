package com.ethanco.myfragmentdialog;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btn_showCommondDialog).setOnClickListener(this);
        findViewById(R.id.btn_showSelect).setOnClickListener(this);
        findViewById(R.id.btn_showSingleSelect).setOnClickListener(this);
        findViewById(R.id.btn_showMultiSelect).setOnClickListener(this);
        findViewById(R.id.btn_ShowWaitDialog).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_showCommondDialog:
                DialogBean dialogBean = new DialogBean("Title", "Content");
                dialogBean.getButtonMap().put(DialogBean.DIALOG_BUTTON_OK, new DialogButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "确定", Toast.LENGTH_SHORT).show();
                    }
                }));
                dialogBean.getButtonMap().put(DialogBean.DIALOG_BUTTON_CANCEL, new DialogButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "取消", Toast.LENGTH_SHORT).show();
                    }
                }));
                dialogBean.getButtonMap().put(dialogBean.DIALOG_BUTTON_MIDDLE, new DialogButton("以后再说", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "以后再说", Toast.LENGTH_SHORT).show();
                    }
                }));
                AlertDialogFragment alertDialog = new AlertDialogFragment(dialogBean);
                alertDialog.onCancel(new DialogInterface() {
                    @Override
                    public void cancel() {
                        Toast.makeText(getApplicationContext(), "cancel", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void dismiss() {
                        Toast.makeText(getApplicationContext(), "dismiss", Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog.show(getFragmentManager(), "commondDialog");
                break;
            case R.id.btn_showSelect:
                final DialogBean selectBean = new DialogBean(DialogBean.DIALOG_SELECT, "单选");
                selectBean.addItem("item1");
                selectBean.addItem("item2");
                selectBean.addItem("item3");
                AlertDialogFragment selectDialog = new AlertDialogFragment(selectBean);
                selectBean.getButtonMap().put(DialogBean.DIALOG_BUTTON_CHECKED, new DialogButton(new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "选中了:" + selectBean.getContent().get(which), Toast.LENGTH_SHORT).show();
                    }
                }));
                selectDialog.show(getFragmentManager(), "selectDialog");
                break;
            case R.id.btn_showSingleSelect:
                final DialogBean singleselectBean = new DialogBean(DialogBean.DIALOG_SINGLE_SELECT, "单选确定");
                singleselectBean.addItem("item1");
                singleselectBean.addItem("item2");
                singleselectBean.addItem("item3");
                singleselectBean.getButtonMap().put(DialogBean.DIALOG_BUTTON_OK, new DialogButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "确定", Toast.LENGTH_SHORT).show();
                    }
                }));
                singleselectBean.getButtonMap().put(DialogBean.DIALOG_BUTTON_CHECKED, new DialogButton(new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "选中了:" + singleselectBean.getContent().get(which), Toast.LENGTH_SHORT).show();
                    }
                }));
                AlertDialogFragment singleSelectDilaog = new AlertDialogFragment(singleselectBean);
                singleSelectDilaog.show(getFragmentManager(), "singleSelectDialog");
                break;
            case R.id.btn_showMultiSelect:
                final DialogBean multiBean = new DialogBean(DialogBean.DIALOG_MULTI_SELECT, "多选");
                multiBean.addItem("item1");
                multiBean.addItem("item2");
                multiBean.addItem("item3");
                multiBean.getButtonMap().put(DialogBean.DIALOG_BUTTON_OK, new DialogButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "确定", Toast.LENGTH_SHORT).show();
                    }
                }));
                multiBean.getButtonMap().put(DialogBean.DIALOG_BUTTON_CHECKED, new DialogButton(new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        Toast.makeText(getApplicationContext(), "多选:+" + which + " " + isChecked, Toast.LENGTH_SHORT).show();
                    }
                }));
                AlertDialogFragment multiDilaog = new AlertDialogFragment(multiBean);
                multiDilaog.show(getFragmentManager(), "multiDilaog");
                break;
            case R.id.btn_ShowWaitDialog:
                //方法一
                //ProgressDialog dialog = ProgressDialog.show(this, "标题", "内容", false, true); //cancelable 返回键是否可用

                //方法二
                ProgressDialog dialog = new ProgressDialog(this);
                //dialog.setTitle("Title");
                dialog.setMessage("等待...");
                dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                dialog.setMax(10);
                dialog.show();
                dialog.setProgress(5);
                break;
        }
    }
}
