package com.yipwey.dialogactivity;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Administrator on 2016/8/12 0012.
 */
public class DialogActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFinishOnTouchOutside(false);
        setContentView(R.layout.activity_main);
    }
}
