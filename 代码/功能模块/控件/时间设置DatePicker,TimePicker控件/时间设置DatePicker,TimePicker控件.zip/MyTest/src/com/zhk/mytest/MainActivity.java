package com.zhk.mytest;

import java.util.Calendar;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;
import android.os.Build;

public class MainActivity extends Activity {

	private int year;
	private int month;
	private int day;
	private int hour;
	private int minute;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		DatePicker dataPicker = (DatePicker) findViewById(R.id.datePicker1);
		TimePicker timePicker = (TimePicker) findViewById(R.id.timePicker1);
		// ��õ�ǰ���ꡢ�¡��ա�Сʱ������
		Calendar c = Calendar.getInstance();
		year = c.get(Calendar.YEAR);
		month = c.get(Calendar.MONTH);
		day = c.get(Calendar.DAY_OF_MONTH);
		hour = c.get(Calendar.HOUR);
		minute = c.get(Calendar.MINUTE);
		// ��ʼ��DatePicker�������ʼ��ʱָ��������
		dataPicker.init(year, month, day, new OnDateChangedListener() {

			@Override
			public void onDateChanged(DatePicker view, int year,
					int monthOfYear, int dayOfMonth) {
				MainActivity.this.year = year;
				MainActivity.this.month = monthOfYear;
				MainActivity.this.day = dayOfMonth;
				//��ʾ��ǰ���ڡ�ʱ��
				showDate(year, monthOfYear, dayOfMonth, hour, minute);
			}
		});
		timePicker.setOnTimeChangedListener(new OnTimeChangedListener() {
			
			@Override
			public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
				MainActivity.this.hour=hourOfDay;
				MainActivity.this.minute=minute;
				//��ʾ��ǰ���ڡ�ʱ��
				showDate(year, month, day, hour, minute);
			}
		});
	}
	
	private void showDate(int year,int month,int day,int hour,int minute){
		int realMonth=month+1;
		System.out.println("ʱ�䣺"+year+"��"+realMonth+"��"+day+"��"+hour+"��"+minute+"��");
	}
}
