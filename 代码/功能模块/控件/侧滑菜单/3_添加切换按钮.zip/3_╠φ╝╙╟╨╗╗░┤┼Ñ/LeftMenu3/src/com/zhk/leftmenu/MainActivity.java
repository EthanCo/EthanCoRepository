package com.zhk.leftmenu;

import com.zhk.view.slidingMenu;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends Activity {

	private slidingMenu menu;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		menu = (slidingMenu)findViewById(R.id.menu);
	}
	public void toggleMenu(View v){
		menu.toggle();//�л��˵�
	}
}
