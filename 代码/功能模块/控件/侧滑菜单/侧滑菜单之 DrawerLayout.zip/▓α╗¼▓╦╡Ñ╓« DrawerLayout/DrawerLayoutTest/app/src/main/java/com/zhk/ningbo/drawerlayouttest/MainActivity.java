package com.zhk.ningbo.drawerlayouttest;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends Activity implements AdapterView.OnItemClickListener {

    private ListView mDrawer;
    private DrawerLayout mDrawerLayout;
    private List<String> menuLists;
    private ActionBarDrawerToggle mDrawerToggle;
    private String mTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTitle = (String) getTitle();
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawer = (ListView) findViewById(R.id.left_drawer);
        menuLists = new ArrayList<String>();
        for (int i = 1; i <= 5; i++) {
            menuLists.add("Item" + i);
        }
        mDrawer.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, menuLists));
        mDrawer.setOnItemClickListener(this);
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
                R.drawable.ic_drawer, R.string.drawer_open,
                R.string.drawer_close) {
            @Override //被打开
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                getActionBar().setTitle("请选择");
                invalidateOptionsMenu(); //系统会重绘OptionMenu 自动调用oonPrepareOptionsMenu
            }

            @Override //被关闭
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                getActionBar().setTitle(mTitle);
                invalidateOptionsMenu();//系统会重绘OptionMenu 自动调用oonPrepareOptionsMenu
            }
        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);

        //开启ActionBar上App ICON的功能
        getActionBar().setDisplayHomeAsUpEnabled(true); //启用返回图标
        getActionBar().setHomeButtonEnabled(true); //使HomeButton可用
        //getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setDisplayShowCustomEnabled(true);


        /*
        ActionBar actionBar = getActionBar();
        actionBar.show();*/
        /*
        actionBar.setLogo(R.drawable.ic_launcher);
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true); //启用返回图标
        actionBar.setHomeButtonEnabled(true); //使HomeButton可用*/
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        //动态添加fragment
        ContentFragment contentFragment = new ContentFragment();
        Bundle args = new Bundle();
        args.putString("text", menuLists.get(position));
        contentFragment.setArguments(args);

        FragmentManager fm = getFragmentManager();
        fm.beginTransaction().replace(R.id.content_main, contentFragment).commit();

        mDrawerLayout.closeDrawer(mDrawer);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        boolean isDrawOpen = mDrawerLayout.isDrawerOpen(mDrawer); //是否打开侧滑菜单
        menu.findItem(R.id.action_search).setVisible(!isDrawOpen);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        //需要将ActionBarToggle与DrawerLayout的状态同步
        //将ActionBarDrawerToggle中的drawer图标设置为ActionBar中的Home-Button的图标
        mDrawerToggle.syncState();
    }

    @Override //当系统状态改变(比如屏幕旋转等)
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //将ActionBar上的图标与Drawer结合起来
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        switch (item.getItemId()) {
            case R.id.action_search:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
