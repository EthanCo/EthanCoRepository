package com.zhk.drawerlayouttest_e;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements AdapterView.OnItemClickListener {

	private ListView mDrawer;
	private DrawerLayout mDrawerLayout;
	private List<String> menuLists;
	private ActionBarDrawerToggle mDrawerToggle;
	private String mTitle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mTitle = (String) getTitle();
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawer = (ListView) findViewById(R.id.left_drawer);
		menuLists = new ArrayList<String>();
		for (int i = 1; i <= 5; i++) {
			menuLists.add("Item" + i);
		}
		mDrawer.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, menuLists));
		mDrawer.setOnItemClickListener(this);
		mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.drawable.ic_drawer, R.string.drawer_open, R.string.drawer_close) {
			@Override
			//����
			public void onDrawerOpened(View drawerView) {
				super.onDrawerOpened(drawerView);
				getActionBar().setTitle("��ѡ��");
				invalidateOptionsMenu(); //ϵͳ���ػ�OptionMenu �Զ�����oonPrepareOptionsMenu
			}

			@Override
			//���ر�
			public void onDrawerClosed(View drawerView) {
				super.onDrawerClosed(drawerView);
				getActionBar().setTitle(mTitle);
				invalidateOptionsMenu();//ϵͳ���ػ�OptionMenu �Զ�����oonPrepareOptionsMenu
			}
		};
		mDrawerLayout.setDrawerListener(mDrawerToggle);

		//����ActionBar��App ICON�Ĺ���
		getActionBar().setDisplayHomeAsUpEnabled(true); //���÷���ͼ��
		getActionBar().setHomeButtonEnabled(true); //ʹHomeButton����
		
		mDrawerToggle.syncState();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		//��̬����fragment
		ContentFragment contentFragment = new ContentFragment();
		Bundle args = new Bundle();
		args.putString("text", menuLists.get(position));
		contentFragment.setArguments(args);

		FragmentManager fm = getFragmentManager();
		fm.beginTransaction().replace(R.id.content_main, contentFragment).commit();

		mDrawerLayout.closeDrawer(mDrawer);
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean isDrawOpen = mDrawerLayout.isDrawerOpen(mDrawer); //�Ƿ�򿪲໬�˵�
		menu.findItem(R.id.action_search).setVisible(!isDrawOpen);
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		//��Ҫ��ActionBarToggle��DrawerLayout��״̬ͬ��
		//��ActionBarDrawerToggle�е�drawerͼ������ΪActionBar�е�Home-Button��ͼ��
		//mDrawerToggle.syncState();
	}

	@Override
	//��ϵͳ״̬�ı�(������Ļ��ת��)
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		mDrawerToggle.onConfigurationChanged(newConfig);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		//��ActionBar�ϵ�ͼ����Drawer�������
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		switch (item.getItemId()) {
		case R.id.action_search:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
}
