package com.zhk.ningbo.videoviewtest;

import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;

/**
 * 需要
 * android.permission.READ_EXTERNAL_STORAGE
 * 权限
 */
public class MainActivity extends AppCompatActivity {

    private VideoView video1;
    private MediaController mediaco;
    private String TAG = "zhk VideoTest";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        video1 = (VideoView) findViewById(R.id.video1);
        mediaco = new MediaController(this);
        File file = new File(Environment.getExternalStorageDirectory(), "mypath/guanggao2.mp4");
        Log.i(TAG, "onCreate filePath: " + file.getAbsolutePath());
        Log.i(TAG, "onCreate file.exists(): " + file.exists());
        if (file.exists()) {
            //VideoView与MediaController进行关联
            video1.setVideoPath(file.getAbsolutePath());
            video1.setMediaController(mediaco);
            mediaco.setMediaPlayer(video1);
            //让VideiView获取焦点
            video1.requestFocus();
        } else {
            Toast.makeText(MainActivity.this, "文件不存在", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
