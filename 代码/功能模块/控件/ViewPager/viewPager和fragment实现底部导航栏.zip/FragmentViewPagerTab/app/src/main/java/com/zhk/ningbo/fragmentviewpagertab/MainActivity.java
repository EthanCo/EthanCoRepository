package com.zhk.ningbo.fragmentviewpagertab;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Zhk on 2015/8/29.
 */
public class MainActivity extends FragmentActivity {

    private ViewPager viewpager;
    private List<Fragment> fragmnetList;
    private FragmentManager fm;
    private RadioGroup tabRdoGroup;
    private RadioButton tabFristRdoBtn;
    private RadioButton tabSecondRdoBtn;
    private RadioButton tabThirdRaoBtn;
    private ArrayList<RadioButton> tabRdoBtnList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_main);

        fragmnetList = new ArrayList<>();
        fragmnetList.add(new FirstFragment());
        fragmnetList.add(new SecondFragment());
        fragmnetList.add(new ThirdFragment());
        fm = getSupportFragmentManager();

        tabRdoGroup = (RadioGroup) findViewById(R.id.rdoGroup_tab);
        tabFristRdoBtn = (RadioButton) findViewById(R.id.rdoBtn_tab_first);
        tabSecondRdoBtn = (RadioButton) findViewById(R.id.rdoBtn_tab_second);
        tabThirdRaoBtn = (RadioButton) findViewById(R.id.rdoBtn_tab_third);
        tabRdoBtnList = new ArrayList<>();
        tabRdoBtnList.add(tabFristRdoBtn);
        tabRdoBtnList.add(tabSecondRdoBtn);
        tabRdoBtnList.add(tabThirdRaoBtn);
        for (int i = 0; i < tabRdoBtnList.size(); i++) {
            RadioButton rdoBtn = tabRdoBtnList.get(i);
            final int position = i;
            rdoBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        viewpager.setCurrentItem(position);
                    }
                }
            });
        }

        viewpager = (ViewPager) findViewById(R.id.layout_main_container);
        viewpager.setAdapter(new FragmentPagerAdapter(fm) {
            @Override
            public Fragment getItem(int i) {
                return fragmnetList.get(i);
            }

            @Override
            public int getCount() {
                return fragmnetList.size();
            }
        });

        viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                RadioButton rdoBtn = tabRdoBtnList.get(i);
                rdoBtn.setChecked(true);
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

        tabFristRdoBtn.setChecked(true);
    }

    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);

    }
}
