package cn.itcast.pageloaddata;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import cn.itcast.service.DataService;

public class MainActivity extends Activity {
    /** Called when the activity is first created. */
	protected static final int SUCCESS_GET_DATA = 0;
	private ListView listview;
	private DataService service;
	private List<String> data;//���ص�������
	private ArrayAdapter<String> adapter;
	
	private boolean finish = true;//�Ƿ�������
	
	private View footer;
	
	private Handler mHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case SUCCESS_GET_DATA:
				ArrayList<String> result = (ArrayList<String>) msg.obj;
				data.addAll(result);
				adapter.notifyDataSetChanged();//��listview�Զ�ˢ��
				finish = true;
				if(listview.getFooterViewsCount() > 0){
					listview.removeFooterView(footer);
				}
				break;

			default:
				break;
			}
		};
	};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        listview = (ListView) findViewById(R.id.listview);
        service = new DataService();
        data = new ArrayList<String>();
        List<String> result = service.getData(0, 20);
        data.addAll(result);
        adapter = new ArrayAdapter<String>(this, R.layout.item, R.id.tv_info, data);
        
        footer = View.inflate(this, R.layout.footer, null);
        
        listview.addFooterView(footer);
        listview.setAdapter(adapter);
        listview.removeFooterView(footer);
        
        listview.setOnScrollListener(new MyOnScrollListener());
        
        
    }
    
    private final class MyOnScrollListener implements OnScrollListener{
    	

		private int countPage = 5;//���ص���ҳ��
    	private int pageSize = 20;//ÿҳ����20������

		public void onScrollStateChanged(AbsListView view, int scrollState) {
			// TODO Auto-generated method stub
			Log.i("i", " scrollState " + scrollState);
		}

		public void onScroll(AbsListView view, int firstVisibleItem,
				int visibleItemCount, int totalItemCount) {
			// TODO Auto-generated method stub
			Log.i("i", " firstVisibleItem :" + firstVisibleItem + ",visibleItemCount :" + visibleItemCount + ",totalItemCount :" + totalItemCount);
			final int totalCount = firstVisibleItem + visibleItemCount;
			int currentPage = totalCount/pageSize;// ��ǰҳ
			int nextPage = currentPage + 1;//��һҳ
			if(totalCount == totalItemCount && nextPage <= countPage && finish){//�Ѿ��ƶ�����listview�����
				
				finish = false;
				//����ҳ��
				listview.addFooterView(footer);
				new Thread(){
					public void run() {
						SystemClock.sleep(3000);
						List<String> result = service.getData(totalCount + 1, pageSize);
						Message msg = new Message();
						msg.what = SUCCESS_GET_DATA;
						msg.obj = result;
						mHandler.sendMessage(msg);
					};
				}.start();
			}
		}
    	
    }
}