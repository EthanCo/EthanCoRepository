package com.example.listviewdownrefresh;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ListViewBaseAdapter extends BaseAdapter{
	List<Person> totalList;
	LayoutInflater inflater;
	public ListViewBaseAdapter(Context context,List<Person> list) {
		this.totalList=list;
		this.inflater = LayoutInflater.from(context);
	}
	
	@Override
	public int getCount() {
		return totalList.size();
	}

	@Override
	public Object getItem(int position) {
		return totalList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Person p =totalList.get(position);
		ViewHolder holder;
		if(convertView==null){
			holder = new ViewHolder();
//			View item = View.inflate(getApplicationContext(), R.layout.item, null);
			convertView = inflater.inflate(R.layout.item, null);
			holder.tvName = (TextView) convertView.findViewById(R.id.tvName);
			holder.tvAge = (TextView) convertView.findViewById(R.id.tvAge);
			holder.tvClass = (TextView) convertView.findViewById(R.id.tvClass);
			

			convertView.setTag(holder);
		}else{
			holder = (ViewHolder)convertView.getTag();
		}
		holder.tvName.setText(p.getName());
		holder.tvAge.setText(p.getAge()+"");
		holder.tvClass.setText(p.getMyclass());
		
		return convertView;
	}
	
	class ViewHolder{
		TextView tvName;
		TextView tvAge;
		TextView tvClass;
	}
	
	public void onDataChange(List<Person> list){
		this.totalList=list;
		this.notifyDataSetChanged();
	}
}
