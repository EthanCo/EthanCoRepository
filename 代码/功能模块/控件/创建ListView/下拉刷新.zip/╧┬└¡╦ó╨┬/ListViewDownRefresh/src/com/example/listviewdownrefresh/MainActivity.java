package com.example.listviewdownrefresh;

import java.util.ArrayList;
import java.util.List;

import com.example.listviewdownrefresh.MyListView.IRefreshListener;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity implements IRefreshListener{

	private MyListView lv;
	private List<Person> list;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setData();
		showList(list);
	}
	
	public void setData(){
		list = new ArrayList<Person>();
		list.addAll(new PersonServer().getPersons(0, 10)); //��������
	}
	
	ListViewBaseAdapter adapter;
	public void showList(List<Person> list){
		if(adapter==null){
		 	lv = (MyListView)findViewById(R.id.lv);
		 	lv.setInterface(this);
		 	adapter = new ListViewBaseAdapter(this,list);
		 	lv.setAdapter(adapter);
		}else{
			adapter.onDataChange(list);
		}
	}

	void addData(){
		list.addAll(0,new PersonServer().getPersons(10, 20)); //��0����
	}
	
	@Override
	public void onRefresh() {
		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			
			@Override
			public void run() {
				//��ȡ��������
				addData();
				//֪ͨ������ʾ
				showList(list);
				//֪ͨlistview:ˢ���������
				lv.refreshComplete();
			}
		}, 2000);
	}
}
