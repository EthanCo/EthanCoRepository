package com.example.listviewdownrefresh;

import java.util.ArrayList;
import java.util.List;

public class PersonServer {
	public List<Person> getPersons(int start,int end){
		List<Person> list = new ArrayList<Person>();
		for (int i = start; i < end; i++) {
			Person p = new Person("����"+i, i, "�༶"+i*2);
			list.add(p);
		}
		return list;
	}
}
