/** Automatically generated file. DO NOT MODIFY */
package com.example.listviewdownrefresh;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}