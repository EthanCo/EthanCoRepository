package com.zhk.mywebviewandjs;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

public class MainActivity extends Activity {
    /** Called when the activity is first created. */
    private WebView webView;
    private Button button;
    @SuppressLint("JavascriptInterface")
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        webView=(WebView) this.findViewById(R.id.webView);
        button=(Button) this.findViewById(R.id.button);
        
        WebSettings setting=webView.getSettings();
        //����֧��javascript
        setting.setJavaScriptEnabled(true);
          //���ӽӿڷ���,��htmlҳ�����  
        webView.addJavascriptInterface(new Object(){
        	
        	 //�����Ҷ�����һ������ķ���  
            public void startPhone(String num){
                Intent intent=new Intent();
                
                intent.setAction(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:"+num));
                startActivity(intent);
            }
        }, "demo");
       
        //����ҳ��
        webView.loadUrl("file:///android_asset/demo.html");
        
        button.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                webView.loadUrl("javascript:show('activity������������')");
            }
        });
    }
}