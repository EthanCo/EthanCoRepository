package com.zhk.ningbo.webviewtest1;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;


/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    private WebView webVi;
    private Button btn;
    private TextView textView;

    public MainActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_main, container, false);
        initView(v);
        initEvent();
        return v;
    }

    private void initView(View v) {
        webVi = (WebView) v.findViewById(R.id.webView);
        btn = (Button) v.findViewById(R.id.button);
        textView = (TextView) v.findViewById(R.id.textView);
    }

    private void initEvent() {
        webVi.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url); //自行加载网页，使其不跳转到系统浏览器ͳ�������
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override //webView出现错误的时候
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                webVi.loadUrl("file:///android_asset/error.html");//对用户进行友好的处理，加载本地html
            }
        });
        webVi.setWebChromeClient(new WebChromeClient() {
            @Override //当接收到标题时
            public void onReceivedTitle(WebView view, String title) {
                textView.setText(title); //设置标题
                super.onReceivedTitle(view, title);
            }
        });
        webVi.setDownloadListener(new DownloadListener() {
            @Override //当下载开始时
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                Log.i("zhklog", url);
                if (url.endsWith(".apk")) {
                    new HttpThread(url).start();
                }
                /*
                //通过调动浏览器来下载文件
                Uri uri =Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                startActivity(intent);*/
            }
        });
        webVi.loadUrl("http://www.baidu.com"); //加载网页

        btn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   webVi.loadUrl(" http://60.167.138.17/softfile.3g.qq.com/msoft/rcps/d/78985/com.tencent.android.qqdownloader_4.6.0_4603129_78985_141121173524a.apk?mkey=55be3d2df4089cc9&f=178a&p=.apk");
               }
           }
        );
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }
}
