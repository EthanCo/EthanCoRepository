package com.zhk.ningbo.webviewtest1;

import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Administrator on 2015/8/2.
 */
public class HttpThread extends Thread {

    private String mUrl;

    public HttpThread(String url) {
        this.mUrl = url;
    }

    @Override
    public void run() {
        try {
            URL httpUrl = new URL(mUrl);
            HttpURLConnection conn = (HttpURLConnection) httpUrl.openConnection();
            conn.setDoInput(true);
            /**
             android 4.0以上的系统中设置conn.setDoOutput(true),将导致请求以post方式提交,但实际情况是你不需要向服务器提交参数信息，我视频中的代码在4.0以下手机都是可以运行的，但android操作系统开发人员在4.0以上的手机对http请求进行了修改，所以才会出现你说的异常。
             修改方式是
             conn.setDoInput(true);
             //	conn.setDoOutput(true);
             conn.setRequestMethod("GET")
             */
            //conn.setDoOutput(true);
            conn.setRequestMethod("GET");
            File downloadFile;
            File sdFile;
            FileOutputStream out;
            if (conn.getResponseCode() == 200) {
                Log.i("zhklog", "download start");
                InputStream in = conn.getInputStream();
                Log.i("zhklog", "get input stream");
                if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                    Log.i("zhklog", "exter storage exit");
                    downloadFile = Environment.getExternalStorageDirectory();
                    sdFile = new File(downloadFile, "test1.apk");
                    out = new FileOutputStream(sdFile);

                    byte[] b = new byte[6 * 1024];
                    int len;
                    Log.i("zhklog", "download start write");
                    while ((len = in.read(b)) != -1) {
                        Log.i("zhklog", "len:" + len);
                        if (out != null) {
                            out.write(b, 0, len);
                        }
                    }
                    Log.i("zhklog", "download success");
                    if (out != null) {
                        out.close();
                    }
                    if (in != null) {
                        in.close();
                    }
                } else {
                    Log.i("zhklog", "exter storage not exit");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.i("zhklog", "exception:" + e.getMessage());
        }
    }
}
