#  Android 沉浸式状态栏完美实现
[博客地址](http://blog.majiajie.me/2016/03/14/Android-%E6%B2%89%E6%B5%B8%E5%BC%8F%E7%8A%B6%E6%80%81%E6%A0%8F%E5%AE%8C%E7%BE%8E%E5%AE%9E%E7%8E%B0/)

![statusbar](http://img.blog.csdn.net/20160314231916497)
