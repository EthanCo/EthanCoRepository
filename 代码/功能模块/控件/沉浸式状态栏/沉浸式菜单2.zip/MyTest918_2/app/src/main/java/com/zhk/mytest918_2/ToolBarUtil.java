package com.zhk.mytest918_2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;

import java.lang.reflect.Field;

/**
 * Created by YOLANDA on 2015-09-18.
 */
public class ToolBarUtil {
    @SuppressLint("NewApi")
    public static void hideSystemUI(View view) {

        view.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @SuppressLint("NewApi")
    public static void showSystemUI(View view) {

        view.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    /**
     * 获状态栏高度
     *
     * @param context 上下文
     * @return 通知栏高度
     */

    public static int getStatusBarHeight(Context context) {
        int statusBarHeight = 0;

        try {

            Class<?> clazz = Class.forName(
                    "com.android.internal.R$dimen");

            Object obj = clazz.newInstance();
            Field field = clazz.getField("status_bar_height");

            int temp = Integer.parseInt(field.get(obj).toString());
            statusBarHeight = context.getResources().getDimensionPixelSize(temp);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return statusBarHeight;
    }
}
