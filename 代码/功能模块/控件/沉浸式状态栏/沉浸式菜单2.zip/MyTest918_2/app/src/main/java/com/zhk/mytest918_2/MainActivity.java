package com.zhk.mytest918_2;

import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import com.readystatesoftware.systembartint.SystemBarTintManager;

/**
 * 沉浸模式，有个小问题，不能使用menu是never的(会弹出一个菜单的那个)，会导致不兼容
 */
public class MainActivity extends AppCompatActivity {

    private Button hide;
    private Toolbar mToolbar;
    private Button show;
    private SystemBarTintManager tintManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mToolbar.setTitle("");
        setSupportActionBar(mToolbar);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) { //大于4.4使用
            //如果使用的是SystemBarTintManager这个类进行的状态栏的着色，除上方的操作外，还要在对应的监听里增加状态栏着色的禁止和启动的功能。可解决5.0的状态栏颜色较深的问题
            tintManager = new SystemBarTintManager(this);
            tintManager.setStatusBarTintResource(R.color.colorPrimaryDark);
            //tintManager.setStatusBarTintEnabled(true);


            hide = (Button) findViewById(R.id.hide);
            hide.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            View view = getWindow().getDecorView();
                            ToolBarUtil.hideSystemUI(view);
                            mToolbar.setOnSystemUiVisibilityChangeListener(
                                    new View.OnSystemUiVisibilityChangeListener() {

                                        @Override
                                        public void onSystemUiVisibilityChange(int visibility) {

                                            mToolbar.setPadding(mToolbar.getPaddingLeft(),
                                                    0, mToolbar.getPaddingRight(),
                                                    //mToolbar.getPaddingBottom()); 部分机型可能底部padding过大
                                                    0);
                                            tintManager.setStatusBarTintEnabled(false); //进入沉浸模式，要禁用
                                        }
                                    });
                        }
                    });

            show = (Button) findViewById(R.id.show);
            show.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    View view = getWindow().getDecorView();
                    ToolBarUtil.showSystemUI(view);
                    mToolbar.setOnSystemUiVisibilityChangeListener(
                            new View.OnSystemUiVisibilityChangeListener() {

                                @Override
                                public void onSystemUiVisibilityChange(int visibility) {

                                    mToolbar.setPadding(mToolbar.getPaddingLeft(),
                                            ToolBarUtil.getStatusBarHeight(MainActivity.this),
                                            mToolbar.getPaddingRight(),
                                            //mToolbar.getPaddingBottom()); 部分机型底部padding可能过大
                                            0);
                                    tintManager.setStatusBarTintEnabled(true); //退出沉浸模式，要启动
                                }
                            });
                }
            });
        }
    }
}
