package com.zhk.ningbo.myactiveandroidtest;

import android.app.Application;

import com.activeandroid.ActiveAndroid;

/**
 * Created by Zhk on 2015/10/12.
 */
public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        ActiveAndroid.initialize(this); //做初始化工作
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        ActiveAndroid.dispose(); //做清理工作
    }
}
