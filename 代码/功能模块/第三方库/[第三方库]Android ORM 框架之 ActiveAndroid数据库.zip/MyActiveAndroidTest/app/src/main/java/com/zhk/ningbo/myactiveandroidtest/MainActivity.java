package com.zhk.ningbo.myactiveandroidtest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.activeandroid.ActiveAndroid;
import com.activeandroid.query.Select;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //单个插入
        Category restaurants = new Category();
        restaurants.name = "Restaurants";
        restaurants.save();

        //批量插入时最好使用事务 (使用事务的话只用了 40ms，不然的话需要4秒)
        ActiveAndroid.beginTransaction();
        try {
            for (int i = 0; i < 10; i++) {
                Category category = new Category();
                category.name = "category" + i;
                category.save();

                for (int j = 0; j < 10; j++) {
                    Item item = new Item();
                    item.name = "N" + i + "Example" + j;
                    item.category = category;
                    item.save();
                }
            }
            ActiveAndroid.setTransactionSuccessful();
        } finally {
            ActiveAndroid.endTransaction();
        }

        //删除记录

        /*
        //方法一
        Item item = Item.load(Item.class, 1);
        item.delete();
        //方法二
        Item.delete(Item.class, 2);
        //方法三
        new Delete().from(Item.class).where("ID=?", 3).execute();*/


        //查询

        Category category = Category.load(Category.class, 5);
        Item item = getRandom(category);
        Toast.makeText(MainActivity.this, item.name, Toast.LENGTH_SHORT).show();

        List<Item> itemList = getAll(category, 7);
        for (int i = 0; i < itemList.size(); i++) {
            Log.i("zhk", "zhklog item name:" + itemList.get(i).name);
        }

        //更新的操作和插入的一样
    }

    /**
     * 随机查询
     *
     * @param category
     * @return
     */
    public static Item getRandom(Category category) {
        //查询支持Delete，From，Join，Select，Set，Updat
        return new Select().from(Item.class)
                .where("Category=?", category.getId())
                .orderBy("Name desc")
                .executeSingle();
    }

    /**
     * 分页查询
     *
     * @param category
     * @param num      分页大小
     * @return
     */
    public static List<Item> getAll(Category category, int num) {
        return new Select()
                .from(Item.class)
                .where("Category = ?", category.getId())
                .orderBy("Name ASC")
                .limit(num)
                .execute();
    }
}
