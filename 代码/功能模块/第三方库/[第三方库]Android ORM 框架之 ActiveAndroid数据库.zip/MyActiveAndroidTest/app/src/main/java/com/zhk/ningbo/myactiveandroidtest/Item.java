package com.zhk.ningbo.myactiveandroidtest;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

/**
 * Created by Zhk on 2015/10/12.
 */
@Table(name = "Items") //表示表
public class Item extends Model {
    @Column(name = "Name") //表示列
    public String name;

    @Column(name = "Category")
    public Category category;
}
