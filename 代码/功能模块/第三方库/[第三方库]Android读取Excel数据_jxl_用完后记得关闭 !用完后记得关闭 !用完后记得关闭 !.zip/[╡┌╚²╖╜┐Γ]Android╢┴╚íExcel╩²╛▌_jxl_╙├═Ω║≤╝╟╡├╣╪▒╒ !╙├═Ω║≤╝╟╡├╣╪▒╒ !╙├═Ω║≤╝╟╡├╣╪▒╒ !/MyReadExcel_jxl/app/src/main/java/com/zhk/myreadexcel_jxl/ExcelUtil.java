package com.zhk.myreadexcel_jxl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ExcelUtil {
	private static Workbook wb;

	public static void openExcel(InputStream is) {
		try {
			wb = Workbook.getWorkbook(is);
		} catch (BiffException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void openExcel(File file) {
		try {
			wb = Workbook.getWorkbook(file);
		} catch (BiffException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Sheet readSheet(int sheetIndex) {
		if (wb != null) {
			return wb.getSheet(sheetIndex);
		} else {
			throw new RuntimeException("必须先openExcel");
		}
	}
	
	public static void closeExcel() {
		if (wb != null) {
			if (inputStream!=null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			wb.close();
			wb = null;
		}
	}
	
	public static boolean isOpen() {
		return wb != null ? true : false;
	}

//		public static String readXLSX(String path) {    
//			                    String str = "";    
//			                   String v = null;    
//			                    boolean flat = false;    
//			                    List<String> ls = new ArrayList<String>();    
//			                    try {
//			                            ZipFile xlsxFile = new ZipFile(new File(path));    
//			                            ZipEntry sharedStringXML = xlsxFile    
//			                                            .getEntry("xl/sharedStrings.xml");    
//			                            InputStream inputStream = xlsxFile.getInputStream(sharedStringXML);    
//			                            XmlPullParser xmlParser = Xml.newPullParser();    
//			                            xmlParser.setInput(inputStream, "utf-8");    
//			                            int evtType = xmlParser.getEventType();    
//			                            while (evtType != XmlPullParser.END_DOCUMENT) {    
//			                                    switch (evtType) {    
//			                                    case XmlPullParser.START_TAG:    
//			                                            String tag = xmlParser.getName();    
//			                                            if (tag.equalsIgnoreCase("t")) {    
//			                                                    ls.add(xmlParser.nextText());    
//			                                            }    
//			                                            break;    
//			                                    case XmlPullParser.END_TAG:    
//			                                            break;    
//			                                    default:    
//			                                            break;    
//			                                    }
//			                                    evtType = xmlParser.next();    
//			                            }    
//			                            ZipEntry sheetXML = xlsxFile.getEntry("xl/worksheets/sheet1.xml");    
//			                            InputStream inputStreamsheet = xlsxFile.getInputStream(sheetXML);    
//			                            XmlPullParser xmlParsersheet = Xml.newPullParser();    
//			                            xmlParsersheet.setInput(inputStreamsheet, "utf-8");    
//			                            Log.i("zhklog","zhklog"+ xmlParsersheet.toString());
//			                            /*
//			 * int evtTypesheet = xmlParsersheet.getEventType(); while
//			 * (evtTypesheet != XmlPullParser.END_DOCUMENT) { switch
//			 * (evtTypesheet) { case XmlPullParser.START_TAG: String tag =
//			 * xmlParsersheet.getName(); if (tag.equalsIgnoreCase("row")) { }
//			 * else if (tag.equalsIgnoreCase("c")) { String t =
//			 * xmlParsersheet.getAttributeValue(null, "t"); if (t != null) {
//			 * flat = true; System.out.println(flat + "有"); } else {
//			 * System.out.println(flat + "没有"); flat = false; } } else if
//			 * (tag.equalsIgnoreCase("v")) { v = xmlParsersheet.nextText(); if
//			 * (v != null) { if (flat) { str += ls.get(Integer.parseInt(v)) +
//			 * "  "; } else { str += v + "  "; } } } break; case
//			 * XmlPullParser.END_TAG: if
//			 * (xmlParsersheet.getName().equalsIgnoreCase("row") && v != null) {
//			 * str += "\n"; } break; } evtTypesheet = xmlParsersheet.next(); }
//			 * System.out.println(str);
//			 */
//			                    } catch (ZipException e) {    
//			                            e.printStackTrace();    
//			                    } catch (IOException e) {    
//			                            e.printStackTrace();    
//			                    } catch (XmlPullParserException e) {    
//			                            e.printStackTrace();    
//			                    }    
//			                    if (str == null) {    
//			                            str = "解析文件出现问题";    
//			                    }    
//			         
//			                    return str;   
//			                    
//	}
}
