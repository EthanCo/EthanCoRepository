package com.zhk.myreadexcel_jxl;

import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.io.File;

import jxl.Cell;
import jxl.Sheet;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File xlsFile = new File(Environment.getExternalStorageDirectory(), "d.xls");
            ExcelUtil.openExcel(xlsFile);
            Sheet sheet = ExcelUtil.readSheet(0);
            int row = sheet.getRows();
            for (int i = 0; i < row; i++) {
                Cell cell_1 = sheet.getCell(0, i);//sheet.getCell(列,行)
                Cell cell_2 = sheet.getCell(1, i);
                Log.i("zhklog", "行" + i + "列0: " + cell_1.getContents());
                Log.i("zhklog", "行" + i + "列1: " + cell_2.getContents());
            }
			ExcelUtil.closeExcel();//记得关闭
        } else {
            Toast.makeText(MainActivity.this, "储存卡不存在", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
