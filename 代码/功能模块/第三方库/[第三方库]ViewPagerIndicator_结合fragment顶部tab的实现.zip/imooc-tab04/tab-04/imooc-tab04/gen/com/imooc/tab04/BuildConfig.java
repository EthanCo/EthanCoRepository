/** Automatically generated file. DO NOT MODIFY */
package com.imooc.tab04;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}