/**
 * @author joe
 *2015-4-29
 *
 */
package com.ebanswers.freezer.net;

import java.io.IOException;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpResponseException;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;
import android.os.Handler;
import android.os.Message;
import com.ebanswers.freezer.serialize.IWeatherResultCallBack;
import com.ebanswers.freezer.util.Constants;

/**
 * @author joe
 * @description
 */
public class WeatherSOAP {
	private String mResult;
	public Handler handler;
	private IWeatherResultCallBack mCallBack;

	public WeatherSOAP() {
		handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				if (msg.what == 0) {
					mCallBack.onResult(mResult);
				}
			}

		};
	}

	/*
	 * @author joe
	 * 
	 * @param cityName
	 * 
	 * @param gpsTf----is using GPS to get location
	 */
	public int getWeather(final String cityName, Boolean gpsTf,
			IWeatherResultCallBack callBack) {
		this.mCallBack = callBack;
		if (gpsTf) {
			// using gps
			// cityName=gps.getlocation
		}
		new Thread(new Runnable() {
			public void run() {
				try {
					SoapObject rpc = new SoapObject(
							Constants.WEATHER_WEBSERVICE_NAMESPACE,
							Constants.WEATHER_WEBSERVICE_METHODNAME);
					SoapSerializationEnvelope envelope;
					// XXX
					rpc.addProperty(Constants.CITYNAME, cityName);
					rpc.addProperty(Constants.USERID, Constants.USERIDNUM);
					envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);
					envelope.bodyOut = rpc;
					envelope.dotNet = true;
					envelope.setOutputSoapObject(rpc);
					HttpTransportSE ht = new HttpTransportSE(
							Constants.WEATHER_WEBSERVICE_URL);
					ht.debug = true;
					ht.call(Constants.WEATHER_SOAP_ACTION, envelope);
					if (envelope.getResponse() != null) {
						SoapObject result = (SoapObject) envelope.getResponse();
						String temperature = result.getProperty(4).toString();
						System.out.println(temperature);
						mResult = temperature.split("；")[0].split("：")[2];
						String o2quality = result.getProperty(5).toString();
						mResult = mResult + ","
								+ o2quality.split("；")[0].split("：")[1];
						System.out.println(mResult);
						Message msg = handler.obtainMessage();
						msg.what = 0;
						handler.sendMessage(msg);
					} else {
						Message msg = handler.obtainMessage();
						msg.what = 1;
						mResult = "error";
						handler.sendMessage(msg);
					}
				} catch (HttpResponseException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (XmlPullParserException e) {
					e.printStackTrace();
				}
			}
		}).start();
		return 0;
	}
}