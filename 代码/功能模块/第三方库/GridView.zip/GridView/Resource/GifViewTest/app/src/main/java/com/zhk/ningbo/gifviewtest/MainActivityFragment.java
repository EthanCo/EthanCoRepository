package com.zhk.ningbo.gifviewtest;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ant.liao.GifView;


/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    private GifView gif;

    public MainActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_main, container, false);
        gif =(GifView) v.findViewById(R.id.gif2);
        gif.setGifImage(R.drawable.img1);
        gif.setShowDimension(200, 150); //设置高度和宽度
        //gif.showCover(); //展示缩略图/////////////////////////
        //gif.setGifImageType(GifView.GifImageType.WAIT_FINISH);//设置类型
        return  v;
    }
}
