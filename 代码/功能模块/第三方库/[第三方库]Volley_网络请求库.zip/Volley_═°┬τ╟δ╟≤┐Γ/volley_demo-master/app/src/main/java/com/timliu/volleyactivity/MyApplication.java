package com.timliu.volleyactivity;

import android.app.Application;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

/**
 * Created by tim2 on 15/8/9.
 */
public class MyApplication extends Application
{
    public static RequestQueue queues; //建立队列

    @Override
    public void onCreate() {
        super.onCreate();
        queues = Volley.newRequestQueue(getApplicationContext());
    }

    public static RequestQueue getHttpQueues() //暴露的方法，用于获取请求队列
    {
        return queues;
    }
}
