package com.ethanco.frescotest;

import android.graphics.drawable.Animatable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.controller.BaseControllerListener;
import com.facebook.drawee.controller.ControllerListener;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.image.ImageInfo;

public class MainActivity extends AppCompatActivity {

    private SimpleDraweeView draweeView;
    private Button btnLoadPng;
    private Button btnLoadGif;


    //------------------Z- 注意 Fresco的Uri只支持绝对路径 ------------------------<<<<<<<<<<<<<<<<<<<<<<<<<
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        draweeView = (SimpleDraweeView) findViewById(R.id.my_image_view);
        btnLoadPng = (Button) findViewById(R.id.btnLoadPng);
        btnLoadGif = (Button) findViewById(R.id.btnLoadGif);

        /****************************** Z-下载Png ******************************/
        btnLoadPng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Uri uri = Uri.parse("https://raw.githubusercontent.com/facebook/fresco/gh-pages/static/fresco-logo.png");
                Uri uri = Uri.parse("asset://com.ethanco.frescotest/p1.png");
                draweeView.setImageURI(uri);
            }
        });

        /****************************** Z-下载Gif并播放 ******************************/
        btnLoadGif.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  //final Uri uri = Uri.parse("http://i4.tietuku.com/f2309200a69bca6c.gif");
                  final Uri uri = Uri.parse("res://com.ethanco.frescotest/"+R.drawable.g1);
                  //final Uri uri = Uri.parse("asset://com.ethanco.frescotest/g1.gif");
                  /* 自动播放
                  ImageRequest request = ImageRequestBuilder.newBuilderWithSource(uri).build();
                  DraweeController controller = Fresco.newDraweeControllerBuilder()
                          .setImageRequest(request)
                          .setAutoPlayAnimations(true)
                          .build();
                  draweeView.setController(controller);*/

                  //手动控制播放 图片下载完之后自动播放，同时，当View从屏幕移除时，停止播放
                  DraweeController controller = Fresco.newDraweeControllerBuilder()
                          .setUri(uri)
                          .setControllerListener(controllerListener)
                          .build();
                  draweeView.setController(controller);

                  Animatable animation = draweeView.getController().getAnimatable();
                  if (animation != null) {
                      // 开始播放
                      animation.start();
                      // 一段时间之后，根据业务逻辑，停止播放
//                      animation.stop();
                  }
              }
          }
        );
    }

    ControllerListener controllerListener = new BaseControllerListener<ImageInfo>() {
        @Override
        public void onFinalImageSet(
                String id,
                @Nullable ImageInfo imageInfo,
                @Nullable Animatable anim) {
            if (anim != null) {
                anim.start();
            }
        }
    };
}