package com.ethanco.frescotest;

import android.app.Application;

import com.facebook.drawee.backends.pipeline.Fresco;

/**
 * @Description TODO
 * Created by YOLANDA on 2015-12-14.
 */
public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        Fresco.initialize(this);
    }
}
