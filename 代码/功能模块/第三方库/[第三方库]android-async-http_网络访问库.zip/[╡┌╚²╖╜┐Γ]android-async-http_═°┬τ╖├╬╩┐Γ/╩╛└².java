String path = ·��;
                RequestParams params = new RequestParams();
                params.add(key, value);
                params.add(key, value);
                AsyncHttpClient client = new AsyncHttpClient();
                client.setTimeout(5000);
                //client.post();
                client.get(path,params, new TextHttpResponseHandler() {
                    @Override
                    public void onFailure(int i, org.apache.http.Header[] headers, String s, Throwable throwable) {
                        //onFailre ���ж��-----------------------------------------------------------------------------<<<<<<<<<<<<<<
                    }

                    @Override
                    public void onFailure(int statusCode, org.apache.http.Header[] headers, byte[] responseBytes, Throwable throwable) {
                        super.onFailure(statusCode, headers, responseBytes, throwable);
                        //onFailre ���ж��-----------------------------------------------------------------------------<<<<<<<<<<<<<<
                    }

                    @Override
                    public void onSuccess(int i, org.apache.http.Header[] headers, String s) {

                    }
                });