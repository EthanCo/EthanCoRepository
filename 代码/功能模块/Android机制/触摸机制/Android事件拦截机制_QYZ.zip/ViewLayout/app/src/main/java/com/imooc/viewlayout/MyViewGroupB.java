package com.imooc.viewlayout;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.LinearLayout;

public class MyViewGroupB extends LinearLayout {

    public MyViewGroupB(Context context) {
        super(context);
    }

    public MyViewGroupB(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyViewGroupB(Context context, AttributeSet attrs,
                        int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Log.d("xys", "ViewGroupB dispatchTouchEvent" + ev.getAction());
        boolean res = super.dispatchTouchEvent(ev);
        Log.d("xys", "ViewGroupB dispatchTouchEvent END"+" "+res+" " + + ev.getAction());
        return res;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        Log.d("xys", "ViewGroupB onInterceptTouchEvent" + ev.getAction());
        boolean res = super.onInterceptTouchEvent(ev);
        Log.d("xys", "ViewGroupB onInterceptTouchEvent END"+" "+res+" " + + ev.getAction());
        return res;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.d("xys", "ViewGroupB onTouchEvent" + event.getAction());
        boolean res = super.onTouchEvent(event);
        Log.d("xys", "ViewGroupB onTouchEvent END"+" "+res+" " + event.getAction());
        return res;
    }
}
