package com.imooc.viewlayout;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.LinearLayout;

public class MyViewGroupA extends LinearLayout {

    public MyViewGroupA(Context context) {
        super(context);
    }

    public MyViewGroupA(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyViewGroupA(Context context, AttributeSet attrs,
                        int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Log.d("xys", "ViewGroupA dispatchTouchEvent" + ev.getAction());
        boolean res = super.dispatchTouchEvent(ev);
        Log.d("xys", "ViewGroupA dispatchTouchEvent END" +" "+res+" " + ev.getAction());
        return res;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        Log.d("xys", "ViewGroupA onInterceptTouchEvent" + ev.getAction());
        boolean res = super.onInterceptTouchEvent(ev);
        Log.d("xys", "ViewGroupA onInterceptTouchEvent END" +" "+res+" " + ev.getAction());
        return res;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.d("xys", "ViewGroupA onTouchEvent" + event.getAction());
        boolean res = super.onTouchEvent(event);
        Log.d("xys", "ViewGroupA onTouchEvent END" +" "+res+" " + event.getAction());
        return res;
    }
}
