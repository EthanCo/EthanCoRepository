package com.imooc.viewlayout;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class MyView extends View {

    public MyView(Context context) {
        super(context);
    }

    public MyView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyView(Context context, AttributeSet attrs,
                  int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.d("xys", "View onTouchEvent" + event.getAction());
//        boolean res = super.onTouchEvent(event);
        boolean res = true;
        Log.d("xys", "View onTouchEvent END" + " " + res + " " + event.getAction());
        return res;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        Log.d("xys", "View dispatchTouchEvent" + event.getAction());
        boolean res = super.dispatchTouchEvent(event);
        Log.d("xys", "View dispatchTouchEvent END" + " " + res + " " + event.getAction());
        return res;
    }

}
