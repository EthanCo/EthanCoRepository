## View的事件分发机制 ##
### 点击事件的传递规则 ###
#### dispatchTouchEven ####
进行事件的分发  
返回值受该View的onTouchEvent和下级View的dispatchTouchEvent影响
#### onInterceptTouchEvent ####
进行事件的拦截  
如果该View拦截的某个事件，那么在同一个事件序列中，此方法不会被再次调用
#### onTouchEvent ####
进行事件的处理  

#### 上面三个方法的关系 ####
可用伪代码表示  

	public boolean dispatchTouchEvent(MotionEvent ev){
		boolean consume = false;
		if(onInterceptTouchEvent(ev)){
			consume = onTouchEvent(ev);
		}else{
			consume = childView.dispatchTouchEvent(ev);		
		}
		return consume;
	}

#### 事件传递机制的结论 ####
- 一个事件序列为: down开始-任意个move-up终止
- 一般情况下一个事件序列只能被一个Vive处理
	- 可将自己处理的事件传递给onTouchEvent强制传给其他View处理 来实现多个view处理同个事件。
- 某个View一旦决定拦截，那个这个事件序列都只能由它来处理(如果事件序列能传递到该View)
	- 它的onInterceptTouchVent不会再被调用
- 否个View开始处理事件，如果它不消耗ACTION_DOWN，那么同一事件序列其他事件都不会再交给它处理。
	- 并且事件将重新交由它的父元素处理(父元素的onTouchEvent会被调用)
- 如果View不消耗除ACTION_DOWN外的其他事件，那么这个事件将会直接传递给Activity处理(不会传递给父元素的onTouchEvent)
	- 并且该View还会持续受到后续的事件。
- ViewGroup默认不拦截任何事件，onInterceptTouchEvent默认返回false
- View没有onInterceptTouchEnvent方法
	- 一旦有点击事件传递给它，就会直接调用onTouchEvent
- View的onTouchEvent默认都会消耗事件。
	- 除非是不可点击的(clickable和longclickable同时为false)
		- View的lonogClickable默认都为false
		- clickable分情况
			- Button之类的默认为true
			- TextView之类的默认为false
- View的Enable属性不影响onTouchEvent的默认返回值
	- 只要它的clickable或者longClickable有一个为true，那么onTouchEvent就返回true
- click会发生的前提是View是可点击的，并且受到的down和up的事件。
- 事件的传递是由外向内的。通过requestDisallowInterceptTouchEvent方法可以在子元素中干预父元素的分发过程。
	- 但是父元素onInterceptTouchEvent中的ACTION_DOWN优先级高于子元素的requestDisallowInterceptTouchEvent，只有父元素的onInterceptTouchEvent的ACTION_DOWN不消耗事件，子元素的requestDisallowInterceptTouchEvent才会生效。

### 事件分发源码分析 ###
事件的传递顺序 Activity -> Window -> decor view -> (setContentView所设置的View)
#### Activity对点击事件的分发过程 ####

	public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            onUserInteraction(); //事件分发前调用，不会对分发造成影响
        }
        if (getWindow().superDispatchTouchEvent(ev)) {//交给Activity附属的Window进行分发
            return true; //如果返回true，整个循环结束
        }
        //如果返回false，那么Activity的onTouchEvent就会被调用
        return onTouchEvent(ev);
    }

##### Window将事件传递给DecorView #####
通过源码，我们可以发现window是个抽象类，并且他的superDispatchTouchEvent方法也是一个抽象方法。所以，必须要找到window的实现类 (通过阅读window的注释可以发现 window有个唯一的实现类-android.policy.PhoneWindow)
	
	window类可以控制顶级View(Decor View)的外观和行为策略

PhoneWidow的superDisPatchTouchEvent  
直接将事件传递给DecorView了

    public boolean superDispatchTouchEvent(MotionEvent event) {
        return mDecor.superDispatchTouchEvent(event);
    }

#### DecorView #####
(DecorView是PhoneWindow的内部类)
由于DecorView类继承自FrameLayout且是父View，所以最终事件会传递给其子View  

[ 题外话 ] 可通过下面的方法获取Activity所设置的View，因为所设置的View就是DecorView的子View  

	(ViewGroup)(getWindow().getDecorView().findViewById(android.R.id.content))

#### 顶级ViewGroup对点击事件的分发过程 ####
顶级ViewGroup是DecorView的子类(顶级ViewGroup就是Activity中setCOntentView的View)  
- 如果顶级ViewGroup拦截事件返回true，则由ViewGroup处理  
	- 这时如果ViewGroup的mOnTouchListener被设置，则onTouch会被调用
	- 否则，onTouchEvent会被调用
- 如果顶级ViewGroup拦截事件返回false，则会传递给它所在的点击事件链上的子View，这时，子View的dispatchTouchEvent会被调用。

ViewGroup的dispatchTouchEvent  

	// Check for interception.
    final boolean intercepted;
    //mFirstTouchTarget:如果ViewGroup的子元素成功处理时，mFirstTouchTarget会被赋值并指向子元素
    if (actionMasked == MotionEvent.ACTION_DOWN || mFirstTouchTarget != null) { //判断是否要拦截当前事件
        /*FLAG_DISALLOW_INTERCEPT: 通过requestDisallowInterceptTouchEvent方法来设置，一般用于子View
        * 一旦设置以后，ViewGroup将无法拦截除ACTION_DOWN以外的点击事件(如果是ACTION_DOWN，会通过resetTouchState()重置)
        * */
        final boolean disallowIntercept = (mGroupFlags & FLAG_DISALLOW_INTERCEPT) != 0;
        if (!disallowIntercept) {
            intercepted = onInterceptTouchEvent(ev);
            ev.setAction(action); // restore action in case it was changed
        } else {
            intercepted = false;
        }
    } else {
        // There are no touch targets and this action is not an initial down
        // so this view group continues to intercept touches.
        intercepted = true;
    }

如果是ACTION_DOWN，会通过resetTouchState()重置 FLAG_DISALLOW_INTERCEPT 

	 // Handle an initial down.
    if (actionMasked == MotionEvent.ACTION_DOWN) {
        // Throw away all previous state when starting a new touch gesture.
        // The framework may have dropped the up or cancel event for the previous gesture
        // due to an app switch, ANR, or some other state change.
        cancelAndClearTouchTargets(ev);
        resetTouchState(); //重置FLAG_DISALLOW_INTERCEPT
    }

可知:  

- 当ViewGroup决定拦截事件后，那么后续的点击事件将会默认交给它处理且不再调用onInterceptTouchEvent方法  
- 子View通过requestDisallowInterceptTouchEvent可以设置父ViewGroup的FLAG_DISALLOW_INTERCEPT从而不拦截事件(ACTION_DOWN除外)
- onInterceptTouchEvent不会每次都调用，如果我们想提前处理所有的点击事件，要选择dispatchTouchEvent方法  
- 当面对滑动冲突时，可通过FLAG_DISALLOW_INTERCEPT解决

#### 如果ViewGroup不拦截事件的时候 ####
事件会向下分发交由它的子View进行处理。
	
	final View[] children = mChildren;
	for (int i = childrenCount - 1; i >= 0; i--) { //遍历所有子元素
	    final int childIndex = customOrder
	            ? getChildDrawingOrder(childrenCount, i) : i;
	    final View child = (preorderedList == null)
	            ? children[childIndex] : preorderedList.get(childIndex);
		
	    // If there is a view that has accessibility focus we want it
	    // to get the event first and if not handled we will perform a
	    // normal dispatch. We may do a double iteration but this is
	    // safer given the timeframe.
	    if (childWithAccessibilityFocus != null) {
	        if (childWithAccessibilityFocus != child) {
	            ontinue;
	        }
	        childWithAccessibilityFocus = null;
	        i = childrenCount - 1;
	    }
		
	    //canViewReceivePointerEvents 是否可以接受Pointer事件
	    //isTransformedTouchPointInView 点击事件是否在子元素区域内
	    if (!canViewReceivePointerEvents(child)
	            || !isTransformedTouchPointInView(x, y, child, null)) {
	        ev.setTargetAccessibilityFocus(false);
	        continue;
	    }
		
	    newTouchTarget = getTouchTarget(child);
	    if (newTouchTarget != null) {
	        // Child is already receiving touch within its bounds.
	        // Give it the new pointer in addition to the ones it is handling.
	        newTouchTarget.pointerIdBits |= idBitsToAssign;
	        break;
	    }
		
	    resetCancelNextUpFlag(child);
	    if (dispatchTransformedTouchEvent(ev, false, child, idBitsToAssign)) {
	        // Child wants to receive touch within its bounds.
	        mLastTouchDownTime = ev.getDownTime();
	        if (preorderedList != null) {
	            // childIndex points into presorted list, find original index
	            for (int j = 0; j < childrenCount; j++) {
	                if (children[childIndex] == mChildren[j]) {
	                    mLastTouchDownIndex = j;
	                    break;
	                }
	            }
	        } else {
	            mLastTouchDownIndex = childIndex;
	        }
	        mLastTouchDownX = ev.getX();
	        mLastTouchDownY = ev.getY();
			//mFirstTouchTarget真正的复制过程在addTouchTarget内部完成的
	        newTouchTarget = addTouchTarget(child, idBitsToAssign);
	        alreadyDispatchedToNewTouchTarget = true;
	        break;
	    }
	}

dispatchTransformedTouchEvent实际上就是调用子元素的dispatchTouchEvent方法  
如下  

    if (child == null) {
        handled = super.dispatchTouchEvent(event);
    } else {
        handled = child.dispatchTouchEvent(event);
    }

mFirstTouchTarget真正的复制过程在addTouchTarget内部完成的

	private TouchTarget addTouchTarget(View child, int pointerIdBits) {
        TouchTarget target = TouchTarget.obtain(child, pointerIdBits);
        target.next = mFirstTouchTarget;
        mFirstTouchTarget = target;
        return target;
    }

如果遍历所有的子元素后事件都没有被合适地处理  

- viewGroup没有子元素
- 子元素处理了点击事件，但是在dispatchTouchEvent中返回了false(这一般是子元素在onTouchEvent中返回了false)  

ViewGroup就会自己处理点击事件  

	// Dispatch to touch targets.
	if (mFirstTouchTarget == null) {
	    // No touch targets so treat this as an ordinary view.
	    handled = dispatchTransformedTouchEvent(ev, canceled, null, //第三个参数为null
	            TouchTarget.ALL_POINTER_IDS);
	} 

#### View对点击事件的处理过程 ####
因为View没有子View，所以事件处理相对比较简单 
 
	public boolean dispatchTouchEvent(MotionEvent event) {
		...

        if (onFilterTouchEventForSecurity(event)) {
            //noinspection SimplifiableIfStatement
            ListenerInfo li = mListenerInfo;
            if (li != null && li.mOnTouchListener != null //先处理OnTouchListener
                    && (mViewFlags & ENABLED_MASK) == ENABLED
                    && li.mOnTouchListener.onTouch(this, event)) {
                result = true;
            }

            if (!result && onTouchEvent(event)) { //如果OntouchListener返回false，处理OnTouchEvent
                result = true;
            }
        }

        if (!result && mInputEventConsistencyVerifier != null) {
            mInputEventConsistencyVerifier.onUnhandledEvent(event, 0);
        }

		...

        return result;
    }

## Viw的滑动冲突 ##
### 常见的滑动冲突场景 ###
- 场景一: 外部滑动方向和内部滑动方向不一致
- 场景二: 外部滑动方向和内部滑动方向一致
- 场景三: 上面两种情况的嵌套

### 解决办法 ###
#### 外部拦截法 ####
ACTION_MOVE的时候根据需要设置是否拦截，其他的事件一律置为false

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        boolean intercepted = false;
        int x = (int) ev.getX();
        int y = (int) ev.getY();
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                intercepted = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (父容器需要当前的事件) {
                    intercepted = true;
                } else {
                    intercepted = false;
                }
                break;
            case MotionEvent.ACTION_UP:
                intercepted = false;
                break;
            default:
                break;
        }

        mLastXIntercept = x;
        mLastYIntercept =y;
        return intercepted;
    }

#### 内部拦截法 ####

子View  

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                break;
            case MotionEvent.ACTION_MOVE:
                int dx = x - mLastX;
                int dy = y = mLastY;
                if (/*父容器需要此类点击事件*/) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                break;
            case MotionEvent.ACTION_UP:
                break;
            default:
        }
        mLastX = x;
        mLastY = y;
        return super.dispatchTouchEvent(event);
    }

父ViewGroup  

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            return false; //ACTION_DOWN 不能拦截
        } else {
            return true; //其他的事件，如果子View调用getParent().requestDisallowInterceptTouchEvent(true);父元素能够继续拦截
        }
    }      

