package com.ethanco.mydatabindingtest;

import android.databinding.BindingConversion;
import android.graphics.drawable.ColorDrawable;

/**
 * @Description TODO
 * Created by YOLANDA on 2015-12-25.
 */
public class Converts {
    @BindingConversion
    public static ColorDrawable convertColorToDrawable(int color) {
        return new ColorDrawable(color);
    }

    @BindingConversion
    public static String convertIntToString(int s) {
        return String.valueOf(s);
    }
}
