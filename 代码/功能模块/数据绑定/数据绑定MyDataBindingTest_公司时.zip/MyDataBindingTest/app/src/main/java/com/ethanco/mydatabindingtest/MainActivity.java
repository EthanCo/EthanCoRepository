package com.ethanco.mydatabindingtest;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.ethanco.mydatabindingtest.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        final Person person = new Person("name", 18);
//        final ActivityMainBinding mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
//        mainBinding.setPerson(person);
//
//        new Thread() {
//            @Override
//            public void run() {
//                SystemClock.sleep(3000);
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        person.setName("你好~");
//                        Toast.makeText(MainActivity.this, person.getName(), Toast.LENGTH_SHORT).show();
//                    }
//                });
//            }
//        }.start();


        final Person person = new Person();
        person.name.set("name");
        person.age.set(20);
        final ActivityMainBinding mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        mainBinding.setPerson(person);

        new Thread() {
            @Override
            public void run() {
                SystemClock.sleep(3000);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        person.name.set("HELLO");
                        Toast.makeText(MainActivity.this, person.name.get(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }.start();
    }
}
