package com.ethanco.mydatabinding;

import android.util.Log;
import android.view.View;
import android.widget.Toast;

/**
 * Created by Zhk on 2015/12/23.
 */
public class MyHandlers {
    public void onClick(View view) {
        Log.i("zhk-MyHandlers", "onClick: ");
        Toast.makeText(view.getContext(), "onClick", Toast.LENGTH_SHORT).show();
    }
}