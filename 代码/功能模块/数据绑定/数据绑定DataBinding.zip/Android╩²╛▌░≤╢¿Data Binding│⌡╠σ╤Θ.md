# Android数据绑定Data Binding初体验 #
## 配置 ##
新版的Android Studio 已内置数据绑定框架，只需在app的build.gradle中添加

	android {
	    ....
	    dataBinding {
	        enabled = true
	    }
	}

## 布局文件的改变 ##
比起原来的布局文件，增加了layout为root节点，data节点进行数据的声明

	<layout xmlns:android="http://schemas.android.com/apk/res/android">
    	<data>
    	</data>
    	<!--原先的根节点（Root Element）-->
    	<LinearLayout>
    	....
    	</LinearLayout>
	</layout>

### Data节点 ###
在data节点中声明数据变量  
name为声明的名称  
type为该类的包名+类名

	<variable
            name="user"
            type="com.ethanco.mydatabinding.User" />

## 简单的例子 ##  

### 新建User类 ###
	
	public class User {
	    private final String firstName;
	    private final String lastName;
	
	    public User(String firstName, String lastName) {
	        this.firstName = firstName;
	        this.lastName = lastName;
	    }
	
	    public String getFirstName() {
	        return firstName;
	    }
	
	    public String getLastName() {
	        return lastName;
	    }
	}

### 编写布局 ###

	<?xml version="1.0" encoding="utf-8"?>
	<layout xmlns:android="http://schemas.android.com/apk/res/android">
	    <data>
	        <variable
	            name="user"
	            type="com.ethanco.mydatabinding.User" />
	    </data>
	    <!--原先的根节点（Root Element）-->
	    <LinearLayout
	        android:layout_width="match_parent"
	        android:layout_height="match_parent"
	        android:orientation="vertical">
	
	        <TextView
	            android:layout_width="wrap_content"
	            android:layout_height="wrap_content"
	            android:text="@{user.firstName}" />
	
	        <TextView
	            android:layout_width="wrap_content"
	            android:layout_height="wrap_content"
	            android:text="@{user.lastName}" />
	    </LinearLayout>
	</layout>

### 绑定数据 ###
当编写好variable，就会自动生成一个继承ViewDataBinding的类，例如activity_main.xml就会生成ActivityMainBinding

	ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
	User user = new User("Test", "User");
	binding.setUser(user);

### 运行程序 ###

即发现TextView的text以显示为Test和User

### 绑定事件 ###
View.OnClickListener有个方法onClick(), 你就可以使用android:onClick属性来绑定一个方法  
**注意:绑定的方法的签名必须和该属性原本对应的方法的签名完全一样，否则编译阶段会报错。**  

#### 新建MyHandlers类 ####

	public class MyHandlers {
	    public void onClick(View view) {
	        Log.i("zhk-MyHandlers", "onClick: ");
	        Toast.makeText(view.getContext(), "onClick", Toast.LENGTH_SHORT).show();
	    }
	}

#### 声明 ####

	<variable
            name="handlers"
            type="com.ethanco.mydatabinding.MyHandlers" />

#### 设置绑定 ####

        <Button
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:onClick="@{handlers.onClick}"
            android:text="ClickMe" />

#### 设置Handlers ####
在Activity中  

	ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
	.....  
	binding.setHandlers(new MyHandlers());

### 运行程序 ###
点击Button发现以绑定了MyHandlers的onClick方法

## 其他 ##
现在Data Binding只支持单向绑定，期待双向绑定，届时，各种注解就正的可以下岗了!

> 参考  
> [https://github.com/LyndonChin/MasteringAndroidDataBinding](https://github.com/LyndonChin/MasteringAndroidDataBinding)  
> [https://github.com/derron/DataBinding-album-sample/blob/master/MVVM.md](https://github.com/derron/DataBinding-album-sample/blob/master/MVVM.md)