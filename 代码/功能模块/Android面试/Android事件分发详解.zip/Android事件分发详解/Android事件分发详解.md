# Android事件分发详解 #

在Android系统中，事件是由用户的动作触发的，进而在android硬件层引起硬件状态的变化，android底层会将硬件的状态的变化封装成更加高级的类对象并传递到Android的Framework层，Framework会继续把事件传递给应用层(确切地说是应用层里面应用开发者编写的具体的View的子类对象)，最终应用层会根据事件来进行响应并将响应的结果通过对硬件的调用反馈给用户。  

## 输入事件类型 ##
Android中所有的事件被抽象成了一个java类，InputEvent  
它有两个直接子类，MotionEvent和KeyEvent，分别代表了动作事件(通常由触摸屏所产生，也是最常见的)的事件和按键所产生的事件。  

但事实上InputEvent不止这两种:  

- Sensor InputEvent(传感器输入事件)
- Hook InputEvent(耳机Hook键输入事件)
- On InputEvent(开机键输入事件)
- Touch Screen InputEvent(触摸屏输入事件)
- Key InputEvent(按键输入事件，Home/Menu/Back，电视遥控器按键等)
- Hover InputEvent(鼠标动作输入事件)  

## Touch Screen InputEvent ##
Touch Screen InputEvent 被封装成了一个java类 - MotionEvent，它包含三个基础的事件，其它的事件都是在这三个事件的基础之上进行组合封装而成的。，例如，click事件就是一个ACTION_DOWN 和一个 ACTION_UP的组合。  

- ACTION_DOWN   手指按到屏幕上
- ACTION_MOVE   手指在屏幕上移动
- ACTION_UP   手指从屏幕上离开  

### 事件顺序 ###
Touch Screen事件并不是单个出现的，用户的每次交互都会产生一个事件序列，这个序列会以一个ACTION_DOWN开头，中间有0或N个ACTION_MOVE事件，最后已一个ACTION_UP结尾。一个事件序列往往可以组成更加高级的事件，比如点击事件、双击事件、手势事件等，View在消费这些事件的时候也会以一个独立的事件序列作为一个最小单位来消费，而不是一个个的基础事件。   

所以，Touch Screen的事件可分为**两种类型**:

- 基础类型：包含ACTION_DOWN、ACTION_MOVE、ACTION_UP三个。
- 复合类型：由基础类型的事件序列组合称一个代表了用户特定的输入信息的事件。  

### 几个关键方法及作用 ###

#### dispatchTouchEvent() ####
作用  
把事件分发给子类、onTouchListener监听器 以及自身的onTouchEvent方法  

调用者  
View的该方法是由Window调用的，Window的该方法是由Activity调用的，Activity的该方法则是由WindowManagerService调用的。  

#### onInterceptTouchEvent() ####
作用描述  
只在ViewGroup中才有，可以让子类实现是否拦截该事件不再往下一步传递，等于说是给ViewGroup的子类提供了一个打断事件传递的Hook占位方法  

结构型方法  
同一个类的dispatchTouchEvent  
#### onTouchEvent() ####
作用描述  
类自身处理touchEvent，包括对OnClickListener的处理就是在这里处理的;让子类继承该方法来使得子类可以监听到touch Event的发生并处理事件  

调用者  
同一个类的dispatchTouchEvent  

### MotionEvent在不同类之间的传递 ###

硬件层 -> Framework层 -- (WindowManagerService) --> 应用层 -> 当前Activity -> (PhoneWindow.DecorView) -> ViewRoot  

### MotionEvent在View中的传递 ###

以下伪代码可以清晰地展示它们三者的关系：  

	public boolean dispatchTouchEvent(MontionEvent e){
	    boolean consume = false;
	    if(onInterceptTouchEvent(e)){
	        consume = onTouchEvent(e);
	    }else{
	        consume = child.dispatchTouchEvent(e);
	    }
	    
	    return consume;
	}

> 当然，事实上View中的dispatchTouchEvent要复杂的多，它需要处理的东西非常多

### MotionEvent在View中传递的一些结论 ###
	
- MotionEvent事件序列是被当做一个整体来处理的，假如一个View不消耗一个ACTION_DOWN事件，那么随后的其它该序列的事件也将不会传递给它。  
- 当一个View觉得要处理某个时间序列的话，该事件序列的所有子事件都将会被交给它处理。  
- ViewGroup的onInterceptTouchEvent默认返回false，也就是说ViewGroup默认是不拦截事件的。  

## Key InputEvent的处理和传递 ##

在应用层，Key InputEvent被封装成了一个叫做KeyEvent的类，它和MotionEvent一样，也是InputEvent的一个子类。总的来说，KeyEvent在应用层的传递方式和Motion Event是一致的。都是由WindowManagerService获取到事件，由DecorView调用ViewRoot，进而按照Activity－Window－View树的流程传递事件的。  

类似于MotionEvent的关键方法，KeyEvent的关键方法分别是:  

- dispatchKeyEvent
- onKeyEvent
- onInterceptKeyEvent  

在View树中的传递过程与Touch事件的一致，这里不再赘述。  