package com.ethanco.mytest001;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*冒泡排序-最小到最大
        int[] arr = new int[]{10, 90, 80, 40, 60};
        int temp;
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i; j < arr.length; j++) {
                if (arr[i] > arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }

        for (int i = 0; i < arr.length; i++) {
            Log.i("Z-MainActivity", "arr[" + i + "]=" + arr[i]);
        }*/

        //二分查找
        int[] arr = new int[]{10, 40, 60, 80, 90};
        Log.i("Z-MainActivity", "Index:" + halfSearch(arr, 80));
    }

    /** 二分查找，必须保证arr是从小到大排序好的
     * @param arr  数组
     * @param target 查找的目标
     * @return 返回索引，如果没有找到，则返回-1
     */
    private int halfSearch(int[] arr, int target) {
        int min = 0;
        int max = arr.length - 1;
        int mid = (min + max) / 2;

        while (true) {
            if (target > arr[min]) {
                min = mid + 1;
            } else if (target < arr[min]) {
                max = mid - 1;
            } else {
                return mid;
            }

            if (max < min) {
                return -1;
            }
            mid = (min + max) / 2;
        }
    }
}
