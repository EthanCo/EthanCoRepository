package com.ethanco.mytest729;

import com.ethanco.mytest729.bean.RecvBean;

/**
 * Created by EthanCo on 2016/7/29.
 */
public interface IMessageDispatcher {

    void dispatch(RecvBean recvBean);
}
