package com.ethanco.mytest729;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Object o = null;
        if (o == null) {
            Toast.makeText(MainActivity.this, "1", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "2", Toast.LENGTH_SHORT).show();
        }

        if (o.equals(null)) {
            Toast.makeText(MainActivity.this, "3", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "4", Toast.LENGTH_SHORT).show();
        }
    }
}
