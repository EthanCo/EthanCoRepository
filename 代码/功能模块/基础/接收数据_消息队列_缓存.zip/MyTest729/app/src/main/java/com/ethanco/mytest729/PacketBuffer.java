package com.ethanco.mytest729;

import com.ethanco.mytest729.bean.RecvBean;

import java.util.concurrent.LinkedBlockingDeque;

/**
 * Created by HopeHu on 2016/5/25.
 */
public class PacketBuffer {

    //是否分发
    private Boolean dispatchFlag = false;

    //消息队列
    private LinkedBlockingDeque<RecvBean> recvQueue = new LinkedBlockingDeque<>();

    //消息分发
    private IMessageDispatcher dispatcher = null;

    //put
    public void put(byte[] buffer, String remoteIP) {
        RecvBean str = new RecvBean();
        str.setIp(remoteIP);
        str.setCmd(buffer);
        recvQueue.offer(str);
    }

    public void startDispatching() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                dispatchFlag = true;
                while (dispatchFlag) {

                    if (!recvQueue.isEmpty()) {
                        RecvBean recvBean = recvQueue.poll();
                        dispatcher.dispatch(recvBean);
                    }
                }
            }
        }).start();
    }

    public void stopDispatching() {
        dispatchFlag = false;
    }
}



