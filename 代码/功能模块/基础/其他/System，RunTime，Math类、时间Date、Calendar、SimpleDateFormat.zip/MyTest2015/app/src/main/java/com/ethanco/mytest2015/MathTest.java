package com.ethanco.mytest2015;

import android.util.Log;

/**
 * Math 数学类，主要提供了很多的数学公式
 * <p/>
 * Created by Zhk on 2016/1/1.
 */
public class MathTest {
    public void test(double value) {
        double newValue;

        newValue = Math.abs(value); //绝对值
        Log.i("zhk-MathTest", "绝对值: " + newValue);

        newValue = Math.ceil(value); //向上取整
        Log.i("zhk-MathTest", "向上取整: " + newValue);

        newValue = Math.floor(value); //向下取整
        Log.i("zhk-MathTest", "向下取整: " + newValue);

        newValue = Math.round(value); //四舍五入
        Log.i("zhk-MathTest", "四舍五入: " + newValue);

        newValue = Math.random(); //产生一个随机数: 大于等于0.0，且小于1.0的伪随机double值
        Log.i("zhk-MathTest", "产生一个随机数: " + newValue);
    }
}
