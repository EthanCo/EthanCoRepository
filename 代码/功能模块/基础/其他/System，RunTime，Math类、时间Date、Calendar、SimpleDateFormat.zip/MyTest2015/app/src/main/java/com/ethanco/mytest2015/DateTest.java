package com.ethanco.mytest2015;

import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Date日期类
 * <p/>
 * CalenDar类 时间操作类
 * <p/>
 * SimpleDateFormat 日期格式化类
 * <p/>
 * Created by Zhk on 2016/1/1.
 */
public class DateTest {
    public void test() {
        Date date = new Date(); //取当前的系统时间

        Calendar calendar = Calendar.getInstance(); //获取当前的系统时间
        Log.i("zhk-DateTest", "test: 年:" + calendar.get(Calendar.YEAR));
        Log.i("zhk-DateTest", "test: 月:" + calendar.get(Calendar.MONTH) + 1); //外国月份是从0-11，所以要+1
        Log.i("zhk-DateTest", "test: 日:" + calendar.get(Calendar.DATE));
        Log.i("zhk-DateTest", "test: 时" + calendar.get(Calendar.HOUR_OF_DAY)); //24小时制
        Log.i("zhk-DateTest", "test: 分" + calendar.get(Calendar.MINUTE));
        Log.i("zhk-DateTest", "test: 秒" + calendar.get(Calendar.SECOND));

        /**
         * SimpleDateFormat 日期格式化类
         * 作用: 1.可以把日期转换指定格式的字符串 format()
         *      2.可以把一个字符转化为对应的日期 parse()
         */
        //SimpleDateFormat dateFormat = new SimpleDateFormat(); //默认的格式常见一个日期格式化对象
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyy年MM月DD日 HH时mm分ss秒SS毫秒");
        //可以把日期转换指定格式的字符串 format()
        String dateStr = dateFormat.format(date);
        Log.i("zhk-DateTest", "test: " + dateStr);

        //可以把一个字符转化为对应的日期 parse()
        try {
            Date newDate = dateFormat.parse(dateStr); //注意: 指定的字符串格式必须与SimpleDateFormat的模式一致
            Log.i("zhk-DateTest", "test: 转化后" + newDate.toString());
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
