package com.ethanco.mytest2015;

import android.util.Log;

import java.util.List;

/**
 * 泛型类
 *
 * Created by Zhk on 2015/12/31.
 */
public class FanXing<T> {
    /**
     * 泛型方法
     * @param t
     * @param <T>
     */
    public <T> void say(T t) {
        Log.i("zhk-FanXing", "say: t:" + t);
    }

    /**
     * 泛型的上限 String的子类或String
     * @param n
     * @param <N>
     */
    public <N extends String> void see(N n){
    }

    /**
     * 泛型的下限 String的父类或String
     * @param tt
     */
    public void run(List<? super String> tt){

    }

    /**
     * 泛型接口
     * @param <M>
     */
    interface TestInterFace<M> {
        M go(M m);
    }
}
