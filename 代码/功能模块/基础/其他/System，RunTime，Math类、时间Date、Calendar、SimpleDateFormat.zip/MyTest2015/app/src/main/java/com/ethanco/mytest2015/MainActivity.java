package com.ethanco.mytest2015;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SystemTest test = new SystemTest();
        test.test();

        DateTest dateTest = new DateTest();
        dateTest.test();

        MathTest mathTest = new MathTest();
        mathTest.test(3.6);
    }
}
