package com.ethanco.mytest2015;

/**
 * RunTime类 主要代表了应用程序运行的环境
 *
 * getRuntime() 返回当前应用程序的运行环境对象
 * exec(String command) 根据指定的路径执行对应的可执行文件
 * freeMomory() 返回Java虚拟机中的空闲内存量，以字节为单位
 * maxMemory() 返回java虚拟机视图使用的最大内存量
 * totalMemory() 返回Java虚拟机中的内存总量
 *
 * Created by Zhk on 2016/1/1.
 */
public class RunTimeTest {
}
