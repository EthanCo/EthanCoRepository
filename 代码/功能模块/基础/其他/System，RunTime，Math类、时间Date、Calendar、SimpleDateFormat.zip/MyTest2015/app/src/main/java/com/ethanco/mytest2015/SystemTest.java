package com.ethanco.mytest2015;

import android.util.Log;

/**
 * System类，主要用于获取系统的属性数据
 * <p/>
 * 常用方法:
 * arraycopy(Object src,int srcPos,Object dest,int destPos,int length)
 * src - 源数组
 * srcPos - 原数组的起始位置
 * dest - 目标数组
 * destPos - 目标数组的起始位置
 * length - 要复制的数组元素的数量
 *
 * currentTimeMillis() 获取当前系统时间
 *
 * exit(int status) 退出java虚拟机
 * status:非0表示异常终止 0或非0都可以退出java虚拟机，对用户而言没有任何区别，
 * 只对于系统有意义，系统(window、android等会根据退出是否异常来统计系统稳定性)
 *
 * gc() 建议java虚拟机(jvm)赶紧启动垃圾回收器回收垃圾
 * getenv(String name) 根据环境变量的名字获取环境变量
 * getProperty(key)
 *
 */
public class SystemTest {
    public void test() {
        int[] srcArr = new int[]{60, 30, 28, 49};
        int[] targetArr = new int[4];
        System.arraycopy(srcArr, 0, targetArr, 0, srcArr.length);
        for (int i = 0; i < targetArr.length; i++) {
            Log.i("zhk-SystemRunTimeTest", "copy: targetArr[" + i + "]=" + targetArr[i]);
        }
    }
}
