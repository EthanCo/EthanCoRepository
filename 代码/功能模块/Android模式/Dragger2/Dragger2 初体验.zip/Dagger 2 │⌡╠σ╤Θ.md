# Dagger 2 初体验 #
## Gradle配置 ##
### 在 Project 的 Gradle 中添加  

	dependencies {
        classpath 'com.android.tools.build:gradle:2.0.0-alpha3'
        // ---------------- Add ------------------ 
        classpath 'com.neenbedankt.gradle.plugins:android-apt:1.8'
		// ---------------- END ------------------     
	}

### 在 Module 的 Gradle 中添加

添加插件（Dagger2的原理是在编译时注入代码）

	apply plugin: 'com.neenbedankt.android-apt'

添加依赖  

	dependencies {	
		compile 'com.google.dagger:dagger:2.0.2'
	    apt 'com.google.dagger:dagger-compiler:2.0.2'
	    compile 'org.glassfish:javax.annotation:10.0-b28'
	}

最后一个依赖是javax注解的依赖。  


> 参考  
> [http://blog.csdn.net/cn_foolishman/article/details/50235919](http://blog.csdn.net/cn_foolishman/article/details/50235919)  
> [http://codethink.me/2015/08/06/dependency-injection-with-dagger-2/](http://codethink.me/2015/08/06/dependency-injection-with-dagger-2/)