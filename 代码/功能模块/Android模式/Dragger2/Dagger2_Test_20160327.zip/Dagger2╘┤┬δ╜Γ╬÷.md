# Dagger2生成代码解析 #
根据[一个简单的Dagger2示例程序](http://download.csdn.net/detail/ethanco/9473590)，进行进一步的探索，对Dagger2自动生成的代码进行解析

## UML ##


## DaggerActivityComponent.Builder类 ##
作用: 生成该类的父类 (DaggerActivityComponent)

	public static final class Builder {
    private ActivityModule activityModule;
  
	    private Builder() {  
	    }
	  
		/*
		 * 生成Component实现类
		 */
	    public ActivityComponent build() {  
	      if (activityModule == null) {
	        this.activityModule = new ActivityModule();
	      }
	      return new DaggerActivityComponent(this); //Component:被装饰的类
	    }
	  
		/*
		* 设置Module
		*/
	    public Builder activityModule(ActivityModule activityModule) {  
	      if (activityModule == null) {
	        throw new NullPointerException("activityModule");
	      }
	      this.activityModule = activityModule;
	      return this;
	    }
	 }  

## DaggerActivityComponent ##
作用: 初始化Provider<Person>，MembersInjector<MainActivity>，关联Activity和Module，进行注入

	@Generated("dagger.internal.codegen.ComponentProcessor")
	public final class DaggerActivityComponent implements ActivityComponent {
	  private Provider<Person> provideUserModelProvider;
	  private MembersInjector<MainActivity> mainActivityMembersInjector;
	
	  private DaggerActivityComponent(Builder builder) {  
	    assert builder != null;
	    initialize(builder);
	  }
	
	  public static Builder builder() {  
	    return new Builder();
	  }
	
	  public static ActivityComponent create() {  
	    return builder().build();
	  }
	
	  private void initialize(final Builder builder) {  
	    this.provideUserModelProvider = ActivityModule_ProvideUserModelFactory.create(builder.activityModule);
	    this.mainActivityMembersInjector = MainActivity_MembersInjector.create((MembersInjector) MembersInjectors.noOp(), provideUserModelProvider);
	  }
	
	  @Override
	  public void inject(MainActivity activity) {  
	    mainActivityMembersInjector.injectMembers(activity);
	  }
	
	  public static final class Builder {
	    ...
	  }
	}

## ActivityModule_ProvideUserModelFactory ##
Provides工厂，根据ActivityModule获取Person  

	@Generated("dagger.internal.codegen.ComponentProcessor")
	public final class ActivityModule_ProvideUserModelFactory implements Factory<Person> {
	  private final ActivityModule module;
	
	  public ActivityModule_ProvideUserModelFactory(ActivityModule module) {  
	    assert module != null;
	    this.module = module;
	  }
	
	  @Override
	  public Person get() {  
	    Person provided = module.provideUserModel();
	    if (provided == null) {
	      throw new NullPointerException("Cannot return null from a non-@Nullable @Provides method");
	    }
	    return provided;
	  }
	
	  public static Factory<Person> create(ActivityModule module) {  
	    return new ActivityModule_ProvideUserModelFactory(module);
	  }
	}  

## MainActivity_MembersInjector ##
作用:对@Inject注释的变量进行赋值

	@Generated("dagger.internal.codegen.ComponentProcessor")
	public final class MainActivity_MembersInjector implements MembersInjector<MainActivity> {
	  private final MembersInjector<AppCompatActivity> supertypeInjector;
	  private final Provider<Person> personProvider;
	
	  public MainActivity_MembersInjector(MembersInjector<AppCompatActivity> supertypeInjector, Provider<Person> personProvider) {  
	    assert supertypeInjector != null;
	    this.supertypeInjector = supertypeInjector;
	    assert personProvider != null;
	    this.personProvider = personProvider;
	  }
	
	  @Override
	  public void injectMembers(MainActivity instance) {  
	    if (instance == null) {
	      throw new NullPointerException("Cannot inject members into a null reference");
	    }
	    supertypeInjector.injectMembers(instance);
	    instance.person = personProvider.get(); //赋值给MainActivity.person
	  }
	
	  public static MembersInjector<MainActivity> create(MembersInjector<AppCompatActivity> supertypeInjector, Provider<Person> personProvider) {  
	      return new MainActivity_MembersInjector(supertypeInjector, personProvider);
	  }
	}

## 多层依赖的情况 ##
在多层依赖的情况下，最大的改变只是在MembersInjector的injectMembers中赋值部分添加了赋值的语句

	@Override
  	public void injectMembers(MainActivity instance) {  
	    if (instance == null) {
	      throw new NullPointerException("Cannot inject members into a null reference");
	    }
	    supertypeInjector.injectMembers(instance);
		//以下为多层依赖情况下的赋值
	    instance.person = personProvider.get(); 
	    instance.shoppingCart = shoppingCartProvider.get();
	}

