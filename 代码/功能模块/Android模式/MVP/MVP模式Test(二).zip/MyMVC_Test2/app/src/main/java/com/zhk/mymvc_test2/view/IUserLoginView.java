package com.zhk.mymvc_test2.view;

import com.zhk.mymvc_test2.bean.User;

/**
 * Created by YOLANDA on 2015-09-17.
 */
public interface IUserLoginView {
    //用户登录
    String getPasswrod();

    String getUserName();

    //登录结果
    void toMainActivity(User user);

    void showFailedError(String error);

    //界面显示
    void showLogining();

    void hideLogining();


}
