package com.zhk.mymvc_test2.view;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.zhk.mymvc_test2.R;
import com.zhk.mymvc_test2.bean.User;
import com.zhk.mymvc_test2.presenter.UserLoginPresenter;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment implements IUserLoginView {

    private EditText etUserName;
    private EditText etPassword;
    private Button btnLogin;
    private ProgressBar proBarLogin;

    private UserLoginPresenter presenter = new UserLoginPresenter(this);

    public MainActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etUserName = (EditText) view.findViewById(R.id.etUserName);
        etPassword = (EditText) view.findViewById(R.id.etPassword);
        btnLogin = (Button) view.findViewById(R.id.btnLogin);
        proBarLogin = (ProgressBar) view.findViewById(R.id.proBarLogin);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                presenter.login();
            }
        });
    }

    public void clear() {
        etUserName.setText("");
        etPassword.setText("");
    }

    @Override
    public String getPasswrod() {
        return etPassword.getText().toString();
    }

    @Override
    public String getUserName() {
        return etUserName.getText().toString();
    }

    @Override
    public void toMainActivity(User user) {
        Toast.makeText(getActivity(), "跳转到主Activity", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showFailedError(String error) {
        Toast.makeText(getActivity(), error, Toast.LENGTH_SHORT).show();
        clear();
    }

    @Override
    public void showLogining() {
        proBarLogin.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLogining() {
        proBarLogin.setVisibility(View.INVISIBLE);
    }
}
