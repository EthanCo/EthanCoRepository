package com.zhk.mymvc_test2.model;

import com.zhk.mymvc_test2.bean.User;

/**
 * Created by YOLANDA on 2015-09-17.
 */
public interface IUserModel {
    void login(User user, OnLoginListener onLoginListener);
}
