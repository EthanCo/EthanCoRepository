package com.zhk.mymvc_test2.model;

import com.zhk.mymvc_test2.bean.User;

/**
 * Created by YOLANDA on 2015-09-17.
 */
public class UserModel implements IUserModel {
    @Override
    public void login(final User user, final OnLoginListener onLoginListener) {
        new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (onLoginListener != null) {
                    if ("zhk".equals(user.getUserName()))
                        if ("123".equals(user.getPassword())) {
                            onLoginListener.onLoginSucccess(user);
                        } else {
                            onLoginListener.onLoginFail("账号或密码错误");
                        }
                    else {
                        onLoginListener.onLoginFail("登录失败");
                    }
                }
            }
        }.start();

    }
}
