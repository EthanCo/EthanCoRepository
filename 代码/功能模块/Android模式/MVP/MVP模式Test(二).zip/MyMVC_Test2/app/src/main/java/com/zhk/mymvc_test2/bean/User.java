package com.zhk.mymvc_test2.bean;

import android.text.TextUtils;

/**
 * Created by YOLANDA on 2015-09-17.
 */
public class User {
    private String userName;
    private String password;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public User(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public boolean isEmpty() {
        if (TextUtils.isEmpty(userName) || TextUtils.isEmpty(password)) {
            return true;
        }
        return false;
    }
}
