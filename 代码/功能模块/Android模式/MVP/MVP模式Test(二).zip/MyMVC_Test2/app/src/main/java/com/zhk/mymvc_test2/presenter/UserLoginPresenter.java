package com.zhk.mymvc_test2.presenter;

import android.os.Handler;

import com.zhk.mymvc_test2.bean.User;
import com.zhk.mymvc_test2.model.IUserModel;
import com.zhk.mymvc_test2.model.OnLoginListener;
import com.zhk.mymvc_test2.model.UserModel;
import com.zhk.mymvc_test2.view.IUserLoginView;

/**
 * Created by YOLANDA on 2015-09-17.
 */
public class UserLoginPresenter {
    private final IUserLoginView userLoginView;
    private final IUserModel userModel;
    private Handler mHandler = new Handler();

    public UserLoginPresenter(IUserLoginView userLoginView) {
        this.userLoginView = userLoginView;
        this.userModel = new UserModel();
    }

    public void login() {
        User user = new User(userLoginView.getUserName(), userLoginView.getPasswrod());
        if (user.isEmpty()) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    userLoginView.showFailedError("账号或密码不能为空");
                }
            });
        } else {
            userLoginView.showLogining();
            userModel.login(user, new OnLoginListener() {
                @Override
                public void onLoginSucccess(final User user) {
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            userLoginView.toMainActivity(user);
                            userLoginView.hideLogining();
                        }
                    });
                }

                @Override
                public void onLoginFail(String error) {
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            userLoginView.showFailedError("账号或密码错误");
                            userLoginView.hideLogining();
                        }
                    });
                }
            });
        }
    }
}
