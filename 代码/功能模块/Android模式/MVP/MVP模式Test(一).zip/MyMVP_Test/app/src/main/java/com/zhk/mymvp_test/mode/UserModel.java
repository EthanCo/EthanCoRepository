package com.zhk.mymvp_test.mode;

import android.content.Context;
import android.util.Log;

import com.zhk.mymvp_test.Application;
import com.zhk.mymvp_test.bean.UserBean;
import com.zhk.mymvp_test.utils.SPUtils;

/**
 * Created by YOLANDA on 2015-09-16.
 */
public class UserModel implements IUserModel {


    private static final String TAG = "zhklog";
    private final Context context;

    public UserModel() {
        context = Application.getContext();
        if (context == null) {
            Log.i(TAG, "UserModel is null");
        }
    }

    @Override
    public void setID(int id) {
        SPUtils.put(context, "id", id);
    }

    @Override
    public void setFirstName(String firstName) {
        SPUtils.put(context, "firstName", firstName);
    }

    @Override
    public void setLastName(String lastName) {
        SPUtils.put(context, "lastName", lastName);
    }

    @Override
    public int getID() {
        return (int) SPUtils.get(context, "id", 0);
    }

    @Override
    public UserBean load(int id) {
        return new UserBean((String) SPUtils.get(context, "firstName", "f"), (String) SPUtils.get(context, "lastName", "l"));
    }
}
