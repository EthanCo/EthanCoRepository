package com.zhk.mymvp_test.bean;

/**
 * Created by YOLANDA on 2015-09-16.
 */
public interface IUserView {
    int getID();

    String getFristName();

    String getLastName();

    void setFirstName(String firstName);

    void setLastName(String lastName);
}
