package com.zhk.mymvp_test.bean;

/**
 * Created by YOLANDA on 2015-09-16.
 */
public class UserBean {
    private String fristName;
    private String lastName;

    public UserBean(String fristName, String lastName) {
        this.fristName = fristName;
        this.lastName = lastName;
    }

    public String getFristName() {
        return fristName;
    }

    public void setFristName(String fristName) {
        this.fristName = fristName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
