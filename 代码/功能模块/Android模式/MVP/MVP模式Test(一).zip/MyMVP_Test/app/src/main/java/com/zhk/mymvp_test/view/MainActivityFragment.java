package com.zhk.mymvp_test.view;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.zhk.mymvp_test.Application;
import com.zhk.mymvp_test.R;
import com.zhk.mymvp_test.bean.IUserView;
import com.zhk.mymvp_test.presenter.UserPresenter;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment implements View.OnClickListener, IUserView {

    private EditText etID;
    private EditText etFirstName;
    private EditText etLastName;
    private UserPresenter presenter;


    public MainActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etID = (EditText) view.findViewById(R.id.etID);
        etFirstName = (EditText) view.findViewById(R.id.etFirstName);
        etLastName = (EditText) view.findViewById(R.id.etLastName);

        view.findViewById(R.id.btnRead).setOnClickListener(this);
        view.findViewById(R.id.btnSave).setOnClickListener(this);

        Application.setContext(getActivity());
        presenter = new UserPresenter(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSave:
                presenter.saveUser(getID(), getFristName(), getLastName());
                break;
            case R.id.btnRead:
                presenter.loadUser(getID());
                break;
        }
    }

    @Override
    public int getID() {
        return Integer.valueOf(etID.getText().toString());
    }

    @Override
    public String getFristName() {
        return etFirstName.getText().toString();
    }

    @Override
    public String getLastName() {
        return etLastName.getText().toString();
    }

    @Override
    public void setFirstName(String firstName) {
        etFirstName.setText(firstName);
    }

    @Override
    public void setLastName(String lastName) {
        etLastName.setText(lastName);
    }
}
