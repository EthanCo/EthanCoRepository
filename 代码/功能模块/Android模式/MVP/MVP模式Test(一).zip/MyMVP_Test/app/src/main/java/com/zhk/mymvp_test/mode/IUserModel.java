package com.zhk.mymvp_test.mode;

import com.zhk.mymvp_test.bean.UserBean;

/**
 * 处理业务逻辑，这里指数据读写
 * Created by YOLANDA on 2015-09-16.
 */
public interface IUserModel {
    void setID(int id);

    void setFirstName(String firstName);

    void setLastName(String lastName);

    int getID();

    UserBean load(int id); //通过id读取user信息，返回一个UserBean
}
