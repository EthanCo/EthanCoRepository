package com.zhk.mymvp_test;

import android.content.Context;

/**
 * Created by YOLANDA on 2015-09-16.
 */
public class Application extends android.app.Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }

    public static void setContext(Context context) {
        mCcontext = context;
    }

    private static Context mCcontext;

    public static Context getContext() {
        return mCcontext;
    }
}
