package com.ebanswers.stove.ioc_viewinjecttext;

import android.app.Activity;
import android.util.Log;
import android.view.View;

import com.ebanswers.stove.ioc_viewinjecttext.event.DynamicHandler;
import com.ebanswers.stove.ioc_viewinjecttext.event.EventBase;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class ViewInjectUtils {
    private static final String METHOD_SET_CONTENTVIEW = "setContentView";
    private static final String METHOD_FIND_VIEW_BY_ID = "findViewById";

    public static void inject(Activity activity) {
        Log.e("TAG", "inject");
        injectContentView(activity);
        injectViews(activity);
        injectEvents(activity);
    }

    /**
     * 注入所有的事件
     *
     * @param activity
     */
    private static void injectEvents(Activity activity) {
        Class<? extends Activity> clazz = activity.getClass();
        Method[] methods = clazz.getMethods();
        //遍历所有的方法
        for (Method method : methods) {
            Annotation[] annotations = method.getAnnotations();
            //拿到方法上的所有的注解
            for (Annotation annotation : annotations) {
                Class<? extends Annotation> annotationType = annotation.annotationType();
                //拿到注解上的注解
                EventBase eventBaseAnnotation = annotationType.getAnnotation(EventBase.class);
                //如果设置为EventBase
                if (eventBaseAnnotation != null) {
                    //取出设置监听器的名称，监听器的类型，调用的方法名
                    String listenerSetter = eventBaseAnnotation.listenerSetter();
                    Class<?> listenerType = eventBaseAnnotation.listenerType();
                    String methodName = eventBaseAnnotation.methodName();
                    try {
                        //拿到Onclick注解中的value方法
                        Method aMethod = annotationType.getDeclaredMethod("value");
                        //取出所有的viewId
                        int[] viewIds = (int[]) aMethod.invoke(annotation, null);
                        //通过InvocationHandler设置代理
                        DynamicHandler handler = new DynamicHandler(activity);
                        handler.addMethod(methodName, method);
                        Object listener = Proxy.newProxyInstance(listenerType.getClassLoader(), new Class<?>[]{listenerType}, handler);
                        //遍历所有的View，设置事件
                        for (int viewId : viewIds) {
                            View view = activity.findViewById(viewId);
                            Method setEventListenerMethod = view.getClass().getMethod(listenerSetter, listenerType);
                            setEventListenerMethod.invoke(view, listener);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /**
     * 注入所有的控件
     *
     * @param activity
     */
    private static void injectViews(Activity activity) {
        //获得该Activity的字节码
        Class<? extends Activity> clazz = activity.getClass();
        //获得该Activity的所有成员变量
        Field[] fields = clazz.getDeclaredFields();
        // 遍历所有成员变量
        for (Field field : fields) {
            Log.e("TAG", field.getName() + "");
            //返回该程序元素上存在的、指定类型的注解，如果该类型注解不存在，则返回null
            ViewInject viewInjectAnnotation = field.getAnnotation(ViewInject.class);
            if (viewInjectAnnotation != null) {
                int viewId = viewInjectAnnotation.value(); //执行value方法
                if (viewId != -1) {
                    Log.e("TAG", viewId + "");
                    // 初始化View
                    try {
                        //获得findViewById方法
                        Method method = clazz.getMethod(METHOD_FIND_VIEW_BY_ID, int.class);
                        //执行findviewById方法
                        Object resView = method.invoke(activity, viewId);
                        //对于私有变量，需setAccessible(true)
                        field.setAccessible(true);
                        //给变量设值
                        field.set(activity, resView);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        }

    }

    /**
     * 注入主布局文件
     *
     * @param activity
     */
    private static void injectContentView(Activity activity) {
        //获得该Activity的字节码
        Class<? extends Activity> clazz = activity.getClass();
        //获得ContentView注解的实例
        ContentView contentViewAnnotation = clazz.getAnnotation(ContentView.class);
        //如果存在
        if (contentViewAnnotation != null) {
            //调用value方法
            int contentViewLayoutId = contentViewAnnotation.value();
            try {
                /*
                getFields()只能访问类中声明为公有的字段,私有的字段它无法访问，能访问从其它类继承来的公有方法
                getDeclaredFields()能访问类中所有的字段,与public,private,protect无关，不能访问从其它类继承来的方法
                setContentView是父类的方法，所以要用getFields();
                */
                Method method = clazz.getMethod(METHOD_SET_CONTENTVIEW, int.class);
                //对于私有变量，需setAccessible(true)
                method.setAccessible(true);
                //调用setContentView方法
                method.invoke(activity, contentViewLayoutId);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
