package com.ebanswers.stove.ioc_viewinjecttext;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.ebanswers.stove.ioc_viewinjecttext.event.OnClick;

@ContentView(R.layout.activity_main)
public class MainActivity extends AppCompatActivity {

    //@ViewInject(R.id.btn1)
    //private Button btn1;
    @ViewInject(R.id.btn2)
    private Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ViewInjectUtils.inject(this);

/*        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Hello", Toast.LENGTH_SHORT).show();
            }
        });*/

    }

    @OnClick({R.id.btn1, R.id.btn2})
    public void clickBtnInvoked(View view) {
        switch (view.getId()) {
            case R.id.btn1:
                Toast.makeText(this, "Btn1", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btn2:
                Toast.makeText(MainActivity.this, "Btn2", Toast.LENGTH_SHORT).show();
        }
    }
}
