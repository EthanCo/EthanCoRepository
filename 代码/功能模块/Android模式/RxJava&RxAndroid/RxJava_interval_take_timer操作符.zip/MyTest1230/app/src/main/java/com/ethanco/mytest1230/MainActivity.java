package com.ethanco.mytest1230;

import android.os.Bundle;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;

public class MainActivity extends AppCompatActivity {

    private Button btnStartTiming;
    private Button btnStopTiming;
    private Subscription timingObservable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();

        btnStartTiming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /**
                 * interval操作符是每隔一段时间递增1直至无穷大，默认在子线程进行
                 * take:输出最多指定数量的结果
                 */
                timingObservable = Observable.interval(1, TimeUnit.SECONDS).take(100).subscribe(new Subscriber<Long>() {
                    @Override
                    public void onCompleted() {
                        Log.i("Z-MainActivity", "onCompleted: ");
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e("Z-MainActivity", "onError: " + e.getMessage());
                    }

                    @Override
                    public void onNext(Long aLong) {
                        Log.i("Z-MainActivity", "onNext: 是否是主线程"+ (Looper.myLooper() == Looper.getMainLooper()));
                        Log.i("Z-MainActivity", "onNext: " + aLong);
                    }
                });

                /**
                 * timer(long delay, TimeUnit unit) 延迟多久后执行 (只执行一次)
                 *  timer(long initialDelay, long period, TimeUnit unit) 每次递增1直至无重大 initialDelay:延迟多久 period:间隔多久执行一次
                 *
                 *  默认在子线程执行
                 */
                /*timingObservable = Observable.timer(10,TimeUnit.SECONDS).take(60).subscribe(new Subscriber<Long>() {
                    @Override
                    public void onCompleted() {
                        Log.i("Z-MainActivity", "onCompleted: ");
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e("Z-MainActivity", "onError: " + e.getMessage());
                    }

                    @Override
                    public void onNext(Long aLong) {
                        Log.i("Z-MainActivity", "onNext: 是否是主线程" + (Looper.myLooper() == Looper.getMainLooper()));
                        Log.i("Z-MainActivity", "onNext: " + aLong);
                    }
                });*/
            }
        });

        btnStopTiming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (timingObservable != null) {
                    Log.i("Z-MainActivity", "onClick: unsubscribe之前:" + timingObservable.isUnsubscribed());
                    timingObservable.unsubscribe();
                    Log.i("Z-MainActivity", "onClick: unsubscribe之后:" + timingObservable.isUnsubscribed());
                }
            }
        });
    }

    private void initView() {
        btnStartTiming = (Button) findViewById(R.id.btnStartTiming);
        btnStopTiming = (Button) findViewById(R.id.btnStopTiming);
    }
}
