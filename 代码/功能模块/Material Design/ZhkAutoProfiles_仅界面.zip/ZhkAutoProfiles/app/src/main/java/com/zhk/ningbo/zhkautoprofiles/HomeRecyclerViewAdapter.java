package com.zhk.ningbo.zhkautoprofiles;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Zhk on 2015/10/9.
 */
public class HomeRecyclerViewAdapter extends RecyclerView.Adapter<ItemViewHolder> {

    private List<String> mData;
    private LayoutInflater mInflater;

    public HomeRecyclerViewAdapter(List<String> data, Context context) {
        this.mData = data;
        this.mInflater = LayoutInflater.from(context);
    }

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.recyclerview_item, parent, false);
        ItemViewHolder itemViewHolder = new ItemViewHolder(view);
        return itemViewHolder;
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        holder.tv.setText(mData.get(position));
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }
}

class ItemViewHolder extends RecyclerView.ViewHolder {
    TextView tv;

    public ItemViewHolder(View itemView) {
        super(itemView);
        tv = (TextView) itemView.findViewById(R.id.itemTv);
    }
}
