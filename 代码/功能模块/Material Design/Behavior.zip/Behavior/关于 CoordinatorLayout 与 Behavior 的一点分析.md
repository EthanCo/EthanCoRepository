Behavior是Android新出的Design库里新增的布局概念。**Behavior只有是CoordinatorLayout的直接子View才有意义**。可以为任何View添加一个Behavior。  

Behavior是一系列回调。让你有机会以非入侵的为View添加动态的布局，和处理父布局(CoordinatorLayout)滑动手势的机会。  

## 依赖 ##

首先自定义一个Behavior  

	public class MyBehavior extends CoordinatorLayout.Behavior{
        public MyBehavior(Context context, AttributeSet attrs) {
            super(context, attrs);
        }
    }  

**一定要重写这个构造函数。**因为CoordinatorLayout源码中parseBehavior()函数中直接反射调用这个构造函数。  

	static final Class<?>[] CONSTRUCTOR_PARAMS = new Class<?>[] {
        Context.class,
        AttributeSet.class
	};  

下面反射生成Behavior实例在实例化CoordinatorLayout.LayoutParams时:  

	final Class<Behavior> clazz = (Class<Behavior>) Class.forName(fullName, true,context.getClassLoader());
	c = clazz.getConstructor(CONSTRUCTOR_PARAMS);
	c.setAccessible(true);
	constructors.put(fullName, c);
	return c.newInstance(context, attrs)  

在任意View中添加:  

	app:layout_behavior=“你的Behavior包含包名的类名”  

然后CoordinatorLayout就会反射生成你的Behavior。  

另外一种方法如果你的自定义View默认使用一个Behavior。在你的自定义View类上添加@DefaultBehavior(你的Behavior.class)这句注解。你的View就会默认使用这个Behavior。就像AppBarLayout一样。  
	
	@DefaultBehavior(AppBarLayout.Behavior.class)
	public class AppBarLayout extends LinearLayout {}  

生成Behavior后第一件事就是确定依赖关系。重写Behavior的这个方法来确定你依赖哪些View。  


	@Override
	public boolean layoutDependsOn(CoordinatorLayout parent, View child, View dependency) {
	    return dependency.getId() == R.id.first;
	}  

child 是指应用behavior的View ，dependency 担任触发behavior的角色，并与child进行互动。  

确定你是否依赖于这个View。CoordinatorLayout会将自己所有View遍历判断。如果确定依赖。这个方法很重要。当所依赖的View变动时会回调这个方法。  

	@Override
	public boolean onDependentViewChanged(CoordinatorLayout parent, View child, View dependency) {
	    return true;
	}  

下面这个例子：  

	<declare-styleable name="Follow">
        <attr name="target" format="reference"/>
    </declare-styleable>  

先定义target这个属性  

	 public class FollowBehavior extends CoordinatorLayout.Behavior {
	  private int targetId;
	 
	  public FollowBehavior(Context context, AttributeSet attrs) {
	      super(context, attrs);
	      TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.Follow);
	      for (int i = 0; i < a.getIndexCount(); i++) {
	          int attr = a.getIndex(i);
	          if(a.getIndex(i) == R.styleable.Follow_target){
	              targetId = a.getResourceId(attr, -1);
	          }
	      }
	      a.recycle();
	  }
	 
	  @Override
	  public boolean onDependentViewChanged(CoordinatorLayout parent, View child, View dependency) {
	       child.setY(dependency.getY()+dependency.getHeight());
	      return true;
	  }
	 
	  @Override
	  public boolean layoutDependsOn(CoordinatorLayout parent, View child, View dependency) {
	      return dependency.getId() == targetId;
	  }
	}  

xml中：  

	<android.support.design.widget.CoordinatorLayout    xmlns:android="http://schemas.android.com/apk/res/android"
	    xmlns:app="http://schemas.android.com/apk/res-auto"
	    xmlns:tools="http://schemas.android.com/tools"
	    android:orientation="vertical"
	    android:layout_width="match_parent"
	    android:layout_height="match_parent"
	    android:fitsSystemWindows="true"
	    tools:context=".MainActivity">
	 
	    <View
	        android:id="@+id/first"
	        android:layout_width="match_parent"
	        android:layout_height="128dp"
	        android:background="@android:color/holo_blue_light"/>
	 
	    <View
	        android:id="@+id/second"
	        android:layout_width="match_parent"
	        android:layout_height="128dp"
	        app:layout_behavior=".FollowBehavior"
	        app:target="@id/first"
	        android:background="@android:color/holo_green_light"/>
	 
	 
	</android.support.design.widget.CoordinatorLayout>  

## 滑动 ##

Behavior最大的用处在于对滑动事件的处理。就像CollapsingToolbarLayout的那个酷炫效果一样。  

主要是这3个方法，所依赖对象的滑动事件都将通知进来:  

	@Override
	public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, View child, View directTargetChild, View target, int nestedScrollAxes) {
	    return true;//这里返回true，才会接受到后续滑动事件。
	}  

	@Override
	public void onNestedScroll(CoordinatorLayout coordinatorLayout, View child, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
	//进行滑动事件处理
	}  

	@Override
	public boolean onNestedFling(CoordinatorLayout coordinatorLayout, View child, View target, float velocityX, float velocityY, boolean consumed) {
	//当进行快速滑动
	    return super.onNestedFling(coordinatorLayout, child, target, velocityX, velocityY, consumed);
	}  

注意被依赖的View只有实现了NestedScrollingChild接口的才可以将事件传递给CoordinatorLayout。  

但注意这个滑动事件是对于CoordinatorLayout的。所以只要CoordinatorLayout有NestedScrollingChild就会滑动，他滑动就会触发这几个回调。无论你是否依赖了哪个View。  

下面就是一个简单的View跟随ScrollView滑入划出屏幕的例子。可以是Toolbar或者任何View。  

