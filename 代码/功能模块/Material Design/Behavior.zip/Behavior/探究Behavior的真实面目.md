## 探究Behavior的真实面目 ##
### Behavior是什么 ###

	public static abstract class Behavior<V extends View>{
		public boolean onTouchEvent(CoordinatorLayout parent, V child, MotionEvent ev) 	   {
        	return false;
	    }
	    
	    public boolean onLayoutChild(CoordinatorLayout parent, V child, int layoutDirection) {
	        return false;
	    }
	}

它是CoordinatorLayout的内部类，从它的注释和其中的方法可以看出来，它其实就是给CoordinatorLayout的子View提供了一些交互的方法，用来规范它们的交交互行为，比如上面出现的onTouchEvent可以用来规范子View的触摸事件，onLayoutChild可以用来规范子View的布局。  

说到这里，CoordinatorLayout又是什么东西 ？  

	public class CoordinatorLayout extends ViewGroup implements NestedScrollingParent {
	}  

可以看出，它其实就是一个ViewGroup，实现了NestedScrollingParent用来执行嵌套滑动。  

既然Coordinatorlayout仅仅是一个ViewGroup，它又为什么能在xml布局中展现威力呢？ 其中的秘密就是在Behavior中。我们可以这么说，CoordinatorLayout利用了Behavior作为一个代理，去控制管理旗下的子View做到各种布局和动画效果。  

那为什么要使用Behavior呢？ 我想原因大概就是解耦吧，如果把所有的逻辑都写死在CoordinatorLayout中，一来不利于维护，二来我们就没有做一些自定义的事情，会显得非常笨重。  


### 为什么要用Behavior ###

规范子View的显示和交互  

## 原理&系统是怎么用Behavior的 ##

我们知道Behavior是用来帮助CoordinatorLayout的，所以我们要从Coordinatorlayout中寻找答案。首先，我们可以看到CoordinatorLayout中有一个Layoutparams，它的子类的LayoutParams都是这个  

	LayoutParams(Context context, AttributeSet attrs) {
	    super(context, attrs);
	
	    .........
	    if (mBehaviorResolved) {
	        mBehavior = parseBehavior(context, attrs, a.getString(
				R.styleable.CoordinatorLayout_LayoutParams_layout_behavior));
	    }
	
	    a.recycle();
	}

知道了如何将Behavior设置进去，那它是如何发挥作用的呢？让我们来看看onLayout函数。  

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
	    final int layoutDirection = ViewCompat.getLayoutDirection(this);
	    final int childCount = mDependencySortedChildren.size();
	    for (int i = 0; i < childCount; i++) {
	        final View child = mDependencySortedChildren.get(i);
	        final LayoutParams lp = (LayoutParams) child.getLayoutParams();
	        final Behavior behavior = lp.getBehavior();
	
	        if (behavior == null || !behavior.onLayoutChild(this, child, layoutDirection)) {
	            onLayoutChild(child, layoutDirection);
	        }
	    }
	}

可以看到它通过parseBehavior去得到了对应子View的Behavior。大家可以试试用RecyclerView的getLayoutParams方法去获取LayoutParams并且调用getBehavior方法，可以得到的就是我们在Xml文件中设置的那个Behavior。  

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
	    final int layoutDirection = ViewCompat.getLayoutDirection(this);
	    final int childCount = mDependencySortedChildren.size();
	    for (int i = 0; i < childCount; i++) {
	        final View child = mDependencySortedChildren.get(i);
	        final LayoutParams lp = (LayoutParams) child.getLayoutParams();
	        final Behavior behavior = lp.getBehavior();
	
	        if (behavior == null || !behavior.onLayoutChild(this, child, layoutDirection)) {
	            onLayoutChild(child, layoutDirection);
	        }
	    }
	}  

可以看到的是其中会调用behavior.onLayoutChild(this,child,layoutDirection)。 也就是说，Behavior的逻辑要优先于CoordinatorLayout自己的逻辑。其实不止是onLayout，我们要可以看看onTouchEvent这个函数。  

	public boolean onTouchEvent(MotionEvent ev) {
	    boolean handled = false;
	    boolean cancelSuper = false;
	    MotionEvent cancelEvent = null;
	
	    final int action = MotionEventCompat.getActionMasked(ev);
	
	    if (mBehaviorTouchView != null || (cancelSuper = performIntercept(ev, TYPE_ON_TOUCH))) {
	        // Safe since performIntercept guarantees that
	        // mBehaviorTouchView != null if it returns true
	        final LayoutParams lp = (LayoutParams) mBehaviorTouchView.getLayoutParams();
	        final Behavior b = lp.getBehavior();
	        if (b != null) {
	            handled = b.onTouchEvent(this, mBehaviorTouchView, ev);
	        }
	    }
	
	    .........
	      
	    return handled;
	}  


Behavior中的那些方法在CoordinatorLayout中都会在合适的机会去调用。  

> 这也证明了我们刚才的那句话: Behavior就是CoordinatorLayout的代理，帮助它去管理子View。  

我们做一个总结，Behavior可以代理哪些行为呢？  

1. Measure和Layout的布局行为。  
2. onTouchEvent和onInterceptTouchEvent的触摸行为。比如design包中的SwipeDismissBehavior就是通过这样的方式完成的。  
3. 嵌套滑动行为(NestedScrollingParent和NestedScrollingCHild中的逻辑)
4. 子View间的依赖行为。  

对于第四点我们在这里可以细说一下，什么叫子View的依赖行为呢？ 这里我们举个例子，我们都知道如果在CoordinatorLayout中使用了FAB并且点击展示SnackbarLayout的话，FAB会在Snackbar显示的时候对应的上移，这是因为FAB依赖了SnackbarLayout。  

	public static class Behavior extends CoordinatorLayout.Behavior<FloatingActionButton> {
  
    ........
    
    @Override
    public boolean layoutDependsOn(CoordinatorLayout parent,
            FloatingActionButton child, View dependency) {
        // We're dependent on all SnackbarLayouts (if enabled)
        return SNACKBAR_BEHAVIOR_ENABLED && dependency instanceof Snackbar.SnackbarLayout;
    }
    

	@Override
	public boolean onDependentViewChanged(CoordinatorLayout parent, FloatingActionButton child,View dependency) {
	   if (dependency instanceof Snackbar.SnackbarLayout) {
	            updateFabTranslationForSnackbar(parent, child, dependency);
	   } else if (dependency instanceof AppBarLayout) {
	   		// If we're depending on an AppBarLayout we will show/hide it automatically
	   		// if the FAB is anchored to the AppBarLayout
	   		updateFabVisibility(parent, (AppBarLayout) dependency, child);
	   }
	   return false;
	}
	
	........
	}


这是FAB中的Behavior，可以看到它重写了layoutDependsOn和onDependentViewChanged，里面的逻辑很简单的就可以看明白。这里我们 [将代码翻译成语言] ， 就是说FAB要依赖的组件是Snackbarlayout，所以在之后的操作里当DependentView(Snackbarlayout)发生了变化，自己 (FAB)也会相应的作出改变。  

值得一提的是，onDependentViewChanged这个函数的调用时机并不是在onLayout之前，而是在onPreDraw中，具体代码如下  

	class OnPreDrawListener implements ViewTreeObserver.OnPreDrawListener {
	    @Override
	    public boolean onPreDraw() {
	        dispatchOnDependentViewChanged(false);
	        return true;
	    }
	}  

如此简单的处理View间的依赖，可见Behavior配合CoordinatorLayout是有多强大。 下面我们可以再举一个例子来讲讲Behavior的作用。还记得我们上面说的吗 ？ RecyclerView 设置了一个Behavior 它就可以和AppBarLayout很好的展示出来，这个Behavior的名字是  

	app:layout_behavior="@string/appbar_scrolling_view_behavior"

	<string name="appbar_scrolling_view_behavior" translatable="false">android.support.design.widget.AppBarLayout$ScrollingViewBehavior</string>  

可以看到它是AppBarLayout里的一个内部类，让我们看看它做了什么。  

	@Override
	public boolean layoutDependsOn(CoordinatorLayout parent, View child, View dependency) {
	    // We depend on any AppBarLayouts
	    return dependency instanceof AppBarLayout;
	}
	
	@Override
	public boolean onDependentViewChanged(CoordinatorLayout parent, View child,
	        View dependency) {
	    offsetChildAsNeeded(parent, child, dependency);
	    return false;
	}
	
	private void offsetChildAsNeeded(CoordinatorLayout parent, View child, View dependency) {
	    final CoordinatorLayout.Behavior behavior =
	            ((CoordinatorLayout.LayoutParams) dependency.getLayoutParams()).getBehavior();
	    if (behavior instanceof Behavior) {
	        // Offset the child, pinning it to the bottom the header-dependency, maintaining
	        // any vertical gap, and overlap
	        final Behavior ablBehavior = (Behavior) behavior;
	        final int offset = ablBehavior.getTopBottomOffsetForScrollingSibling();
	        child.offsetTopAndBottom((dependency.getBottom() - child.getTop())
	                + ablBehavior.mOffsetDelta
	                + getVerticalLayoutGap()
	                - getOverlapPixelsForOffset(dependency));
	    }
	}