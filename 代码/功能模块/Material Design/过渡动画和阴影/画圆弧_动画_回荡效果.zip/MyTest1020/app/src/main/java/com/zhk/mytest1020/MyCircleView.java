package com.zhk.mytest1020;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

/**
 * Created by YOLANDA on 2015-10-20.
 */
public class MyCircleView extends View {

    private static final String TAG = "zhklog";
    private Paint paint;
    private int mWidth;
    private int mHeight;
    private float angle = 0;
    private int border = 50;
    private RectF rectF3;

    public MyCircleView(Context context) {
        super(context);
        init();
    }

    public MyCircleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MyCircleView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE); // 风格: 实心、空心等
        paint.setStrokeWidth(20);


    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        mWidth = getMeasuredWidth();
        mHeight = getMeasuredHeight();
        rectF3 = new RectF(border, border, mWidth - border, mWidth - border);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();


    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Log.i(TAG, "onDraw ");
        canvas.drawArc(rectF3, 0, angle, false, paint);
    }

    public void setAngle(int angle) {

        Log.i(TAG, "setAngle ");
        this.angle = angle;
        invalidate();
    }
}
