package com.zhk.mytest1020;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;

/**
 * Created by YOLANDA on 2015-10-20.
 */
@TargetApi(Build.VERSION_CODES.LOLLIPOP)
public class MyCircleView extends View {

    private static final String TAG = "zhklog";
    private Paint paint;
    private int mWidth;
    private int mHeight;
    private float angle = 0;
    private int border = 50;
    private int shadow = 50;
    private RectF rectF3;

    public MyCircleView(Context context) {
        super(context);
        init();
    }

    public MyCircleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MyCircleView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setAntiAlias(true);
        //paint.setStyle(Paint.Style.STROKE); // 风格: 实心、空心等
        paint.setStrokeWidth(20);


    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        mWidth = getMeasuredWidth();
        mHeight = getMeasuredHeight();
        rectF3 = new RectF(border, border, mWidth - border, mWidth - border);
    }

    @Override
    public void setTranslationZ(float translationZ) {
        super.setTranslationZ(translationZ);

        setOutlineProvider(viewOutlineProvider);
        invalidate();
    }

    ViewOutlineProvider viewOutlineProvider = new ViewOutlineProvider() {
        @Override
        public void getOutline(View view, Outline outline) {
            outline.setOval(new Rect(border, border, mWidth - border, mWidth - border));
        }
    };

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Log.i(TAG, "onDraw ");
        canvas.drawArc(rectF3, 0, angle, true, paint);
        //canvas.drawCircle(mWidth / 2, mWidth / 2 + border, mWidth/2 - border, paint);
    }

    public void setAngle(int angle) {

        Log.i(TAG, "setAngle ");
        this.angle = angle;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                Log.d(TAG, "ACTION_DOWN on view.");
                setTranslationZ(120);
                break;
            case MotionEvent.ACTION_UP:
                Log.d(TAG, "ACTION_UP on view.");
                setTranslationZ(30);
                break;
            default:
                return false;
        }
        return true;
    }
}
