package com.hzxj.android.presentation;

import android.app.Activity;
import android.app.Application;
import android.view.Display;

public class MyApplication extends Application {
	public static Activity mainActivity;
	public static Display display;
}
