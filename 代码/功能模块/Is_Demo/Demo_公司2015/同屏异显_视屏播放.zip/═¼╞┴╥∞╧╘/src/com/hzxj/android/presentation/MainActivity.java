package com.hzxj.android.presentation;

import java.io.File;
import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

public class MainActivity extends Activity implements SurfaceHolder.Callback,
		OnCompletionListener, OnErrorListener, OnBufferingUpdateListener,
		OnPreparedListener {

	private static String TAG = "MainActivity";

	private SurfaceView surface;
	private MediaPlayer mediaPlayer;
	private SurfaceHolder surfaceHolder;// SurfaceView的控制器
	private String Mp4Path;

	private DisplayManager displayManager;

	private final DisplayManager.DisplayListener mDisplayListener = new DisplayManager.DisplayListener() {
		@Override
		public void onDisplayAdded(int displayId) {
		}

		@Override
		public void onDisplayChanged(int displayId) {
		}

		@Override
		public void onDisplayRemoved(int displayId) {
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		MyApplication.mainActivity = this;
		setContentView(R.layout.activity_main);
		surface = (SurfaceView) findViewById(R.id.surface);
		setUpSurfaceView();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.v(TAG, "onDestroy");
		if (mediaPlayer.isPlaying()) {
			mediaPlayer.stop();
		}
		mediaPlayer.release();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.action_cutting:
			displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
			displayManager.registerDisplayListener(mDisplayListener, null);
			Display[] presentationDisplays = displayManager
					.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
			if (presentationDisplays.length > 0) {
				MyApplication.display = presentationDisplays[0];
				Intent intent = new Intent(this, MyService.class);
				startService(intent);
			}
			Toast.makeText(MainActivity.this, "切换屏幕", Toast.LENGTH_SHORT)
					.show();
			imitateHome();
			break;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	/** 设置SurfaceView */
	private void setUpSurfaceView() {
		surfaceHolder = surface.getHolder();
		surfaceHolder.addCallback(this);
	}

	/** 模拟Home键 */
	private void imitateHome() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);// 注意
		intent.addCategory(Intent.CATEGORY_HOME);
		this.startActivity(intent);
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		mediaPlayer = new MediaPlayer();
		mediaPlayer.setOnCompletionListener(this);
		mediaPlayer.setOnErrorListener(this);
		mediaPlayer.setOnBufferingUpdateListener(this);
		mediaPlayer.setOnPreparedListener(this);
		mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		mediaPlayer.setDisplay(surfaceHolder);
		try {
			File file = new File(Environment.getExternalStorageDirectory(),
					"b.mp4");
			Mp4Path = file.getPath();
			Log.d(TAG, Mp4Path);
			mediaPlayer.setDataSource(Mp4Path);
			mediaPlayer.prepare();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPrepared(MediaPlayer mp) {
		mediaPlayer.start();
	}

	@Override
	public void onBufferingUpdate(MediaPlayer mp, int percent) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean onError(MediaPlayer mp, int what, int extra) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		mediaPlayer.reset();
		try {
			mediaPlayer.setDataSource(Mp4Path);
			mediaPlayer.prepare();
		} catch (IllegalArgumentException | SecurityException
				| IllegalStateException | IOException e) {
			e.printStackTrace();
		}
	}

}
