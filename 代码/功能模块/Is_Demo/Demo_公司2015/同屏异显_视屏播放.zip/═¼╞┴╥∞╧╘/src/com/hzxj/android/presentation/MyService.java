package com.hzxj.android.presentation;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.view.WindowManager;

public class MyService extends Service {

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		RemotePresentation presentation = new RemotePresentation(getApplicationContext(), MyApplication.display);
		presentation.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
		presentation.show();
		return super.onStartCommand(intent, flags, startId);
	}

}
