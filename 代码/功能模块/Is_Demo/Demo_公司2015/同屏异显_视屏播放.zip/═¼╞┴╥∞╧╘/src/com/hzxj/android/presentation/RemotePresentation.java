package com.hzxj.android.presentation;

import java.io.File;

import android.app.Presentation;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.os.Environment;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public final class RemotePresentation extends Presentation implements
		SurfaceHolder.Callback, OnCompletionListener, OnErrorListener,
		OnBufferingUpdateListener, OnPreparedListener {

	private SurfaceView surface;
	private MediaPlayer mediaPlayer;
	private SurfaceHolder surfaceHolder;// SurfaceView的控制器
	private String Mp4Path;
	
	public RemotePresentation(Context context, Display display) {
		super(context, display);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.remote_display);
		surface = (SurfaceView) findViewById(R.id.surface);
		setUpSurfaceView();
	}

	/** 设置SurfaceView */
	private void setUpSurfaceView() {
		surfaceHolder = surface.getHolder();
		surfaceHolder.addCallback(this);
	}

	@Override
	public void onPrepared(MediaPlayer mp) {
		mediaPlayer.start();
	}

	@Override
	public void onBufferingUpdate(MediaPlayer mp, int percent) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean onError(MediaPlayer mp, int what, int extra) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		mediaPlayer.reset();
		try {
			mediaPlayer.setDataSource(Mp4Path);
			mediaPlayer.prepare();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		mediaPlayer = new MediaPlayer();
		mediaPlayer.setOnCompletionListener(this);
		mediaPlayer.setOnErrorListener(this);
		mediaPlayer.setOnBufferingUpdateListener(this);
		mediaPlayer.setOnPreparedListener(this);
		mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		mediaPlayer.setDisplay(surfaceHolder);
		try {
			File file = new File(Environment.getExternalStorageDirectory(),
					"b.mp4");
			Mp4Path = file.getPath();
			mediaPlayer.setDataSource(Mp4Path);
			mediaPlayer.prepare();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub

	}
}
