package com.zhk.ningbo.myaudiostrip;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

/**
 * Created by Zhk on 2015/9/19.
 */
public class AudioStrip extends View {

    private int mRectCount = 21;
    private int mRectWidth = 35;
    private float mRectHeight = 500;
    private float offset = 5;
    private double mRadom;
    private Paint paint;
    private int mWidth;
    private LinearGradient mLinearGradient;

    public AudioStrip(Context context) {
        super(context);

        initVar();
    }

    public AudioStrip(Context context, AttributeSet attrs) {
        super(context, attrs);

        initVar();
    }

    public AudioStrip(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        initVar();
    }

    private void initVar() {
        paint = new Paint();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Log.i("zhk AudioStrip", "onDraw");
        for (int i = 0; i < mRectCount; i++) {
            canvas.drawRect(mWidth * 0.4F / 2F + mRectWidth * i + offset, getRadomCurrHeight(), mWidth * 0.4F / 2F + mRectWidth * (i + 1), mRectHeight, paint);
            postInvalidateDelayed(500);
        }
    }

    public float getRadomCurrHeight() {
        mRadom = Math.random();
        return (float) (mRectHeight * mRadom);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        Log.i("zhk AudioStrip", "onSizeChanged");
        mWidth = getWidth();
        mRectHeight = getHeight();
        mRectWidth = (int) (mWidth * 0.6 / mRectCount);
        mLinearGradient = new LinearGradient(0, 0, mRectWidth, mRectHeight, Color.YELLOW, Color.GREEN, Shader.TileMode.CLAMP);
        paint.setShader(mLinearGradient);
    }
}
