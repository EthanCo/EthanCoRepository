package com.zhk.ningbo.myviewgroup;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Scroller;

/**
 * Created by Zhk on 2015/9/23.
 */
public class MyViewGroup extends ViewGroup {
    private static final String TAG = "zhklog";
    private int mScreenWidth;
    private int mScreenHeight;
    private int mLastY;
    private Scroller mScroller;
    private int mEnd;
    private int mStart;

    public MyViewGroup(Context context) {
        super(context);
        init();
    }

    public MyViewGroup(Context context, AttributeSet attrs) {
        super(context, attrs);

        init();
    }

    public MyViewGroup(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        init();
    }

    private void init() {
        WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        mScreenWidth = outMetrics.widthPixels;
        mScreenHeight = outMetrics.heightPixels;

        //初始化Scroller实例
        mScroller = new Scroller(getContext());
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int childCount = getChildCount();

        //通知子View进行测量
        for (int i = 0; i < childCount; i++) {
            View childView = getChildAt(i);
            measureChild(childView, widthMeasureSpec, heightMeasureSpec);
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int childCount = getChildCount();
        //设置MyViewGroup的高度
        MarginLayoutParams mlp = (MarginLayoutParams) getLayoutParams();
        mlp.height = mScreenHeight * childCount;
        Log.i(TAG, "onLayout height:" + mlp.height);
        setLayoutParams(mlp);


        //设置子View的位置
        for (int i = 0; i < childCount; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() != View.GONE) {
                child.layout(l, mScreenHeight * i, r, mScreenHeight * (i + 1));
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int y = (int) event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mLastY = y;
                mStart = getScrollY();
                break;
            case MotionEvent.ACTION_MOVE:
                if (!mScroller.isFinished()) { //如果mscroller还在滑动
                    mScroller.abortAnimation(); //停止动画
                }
                int dy = mLastY - y;
                Log.i(TAG, "onTouchEvent getScrollY " + getScrollY());
                if (getScrollY() < 0) { //理论上是0，但0有时候会有些问题，需修改
                    dy = 0;
                }
                Log.i(TAG, "onTouchEvent getHeight()" + getHeight());
                Log.i(TAG, "onTouchEvent getMeasuredHeight()" + getMeasuredHeight());
                Log.i(TAG, "onTouchEvent getLayoutParams().height" + getLayoutParams().height);
                Log.i(TAG, "onTouchEvent mScreenHeight" + mScreenHeight);
                if (getScrollY() > (getLayoutParams().height - mScreenHeight)) { //书上是getHeight()，但这里会有问题，取到的是屏幕的宽度有，而getLayoutParams().height获取的数据是正确的，是ViewGroup的总高度(包括看不见的部分)
                    dy = 0;
                }
                scrollBy(0, dy);
                mLastY = y;
                break;
            case MotionEvent.ACTION_UP:
                mEnd = getScrollY();
                int dScrollY = mEnd - mStart; //滚动的距离
                if (dScrollY > 0) { //从上往下滑动
                    if (dScrollY < mScreenHeight / 3) {
                        mScroller.startScroll(0, getScrollY(), 0, -dScrollY);
                    } else {
                        mScroller.startScroll(0, getScrollY(), 0, mScreenHeight - dScrollY);
                    }
                } else { //从下往上滑动
                    if (-dScrollY < mScreenHeight / 3) {
                        mScroller.startScroll(0, getScrollY(), 0, -dScrollY);
                    } else {
                        mScroller.startScroll(0, getScrollY(), 0, -mScreenHeight - dScrollY);
                    }
                }
                break;
        }
        Log.i(TAG, "onTouchEvent action:" + event.getAction());
        postInvalidate();
        return true;
        //return super.onTouchEvent(event);
    }

    /**
     * 调用startScroll()是不会有滚动效果的，只有在computeScroll()获取滚动情况，做出滚动的响应
     * computeScroll在父控件执行drawChild时，会调用这个方法
     */
    @Override
    public void computeScroll() {
        super.computeScroll();
        if (mScroller.computeScrollOffset()) {
            scrollTo(0, mScroller.getCurrY());
            postInvalidate();
        }
    }
}
