package com.zhk.ningbo.mypercentviewtest;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;

/**
 * Created by Zhk on 2015/9/19.
 */
public class PercentView extends View {
    private int mScreenWidth;
    private int mCircleXY;
    private float mRadius;
    private RectF mArcRectF;
    private Paint mCirclePaint;
    private Paint mArcPaint;
    private float mSweepAngle;
    private String mShowText = "Android Skill";
    private int mShowTextSize = 48;
    private Paint mTextPaint;
    private float mSweepValue = 60;

    public PercentView(Context context) {
        super(context);

        initVar();
    }

    public PercentView(Context context, AttributeSet attrs) {
        super(context, attrs);

        initVar();
    }

    public PercentView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        initVar();
    }

    private void initVar() {
        // 宽高赋值
        WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        mScreenWidth = outMetrics.widthPixels;

        initViewVar((int) (mScreenWidth / 1));

        mCirclePaint = new Paint();
        mCirclePaint.setColor(Color.BLUE);
        mArcPaint = new Paint();
        mArcPaint.setStyle(Paint.Style.STROKE); // 风格: 实心、空心等
        mArcPaint.setStrokeWidth(100);
        mArcPaint.setColor(Color.GREEN);
        mTextPaint = new Paint();
        mTextPaint.setTextSize(mShowTextSize);
        mTextPaint.setColor(Color.WHITE);
    }

    private void initViewVar(int length) {

        mCircleXY = length / 2;
        mRadius = (float) (length * 0.5 / 2F);

        mArcRectF = new RectF((float) (length * 0.1), (float) (length * 0.1),
                (float) (length * 0.90), (float) (length * 0.9));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawCircle(mCircleXY, mCircleXY, mRadius, mCirclePaint);

        mSweepAngle = mSweepValue / 100F * 360F;
        canvas.drawArc(mArcRectF, 270, mSweepAngle, false, mArcPaint);

        canvas.drawText(mShowText, 0, mShowText.length(), mCircleXY - (mShowTextSize * 2.5F), mCircleXY + (mShowTextSize / 3), mTextPaint);
    }
    
    public void setSweepValue(float sweepValue) {
        if (sweepValue != 0) {
            mSweepValue = sweepValue;
        } else {
            mSweepValue = 60;
        }

        this.invalidate();
    }
}
