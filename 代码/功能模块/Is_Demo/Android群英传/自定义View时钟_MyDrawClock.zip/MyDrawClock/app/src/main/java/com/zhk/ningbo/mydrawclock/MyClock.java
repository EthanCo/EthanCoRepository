package com.zhk.ningbo.mydrawclock;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by Zhk on 2015/9/26.
 */
public class MyClock extends View {
    private int mScreenWidth;
    private int mClockWidth;
    private int mClockHeight;

    public MyClock(Context context) {
        super(context);

        init();
    }

    public MyClock(Context context, AttributeSet attrs) {
        super(context, attrs);

        init();
    }

    public MyClock(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        init();
    }

    private void init() {
        mScreenWidth = DrawUtil.getOutMetrics(getContext()).widthPixels;
        mClockWidth = mScreenWidth / 2;
        mClockHeight = mClockWidth;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Paint paintCircle = new Paint();
        paintCircle.setStyle(Paint.Style.STROKE);
        paintCircle.setAntiAlias(true); //设置画笔的锯齿效果
        paintCircle.setStrokeWidth(5);
        canvas.drawCircle(mClockWidth, mClockHeight, mClockWidth / 2, paintCircle); //mClockWidth,mClockHeight确定圆形位置，mClockWidth/2是半径

        Paint paintOriginal = new Paint();
        paintOriginal.setStyle(Paint.Style.FILL);
        canvas.drawRect(mClockWidth - 9, mClockHeight - 9, mClockWidth + 9, mClockHeight + 9, paintOriginal);
        canvas.save();

        Paint paintDegree = new Paint();
        int count = 24;
        for (int i = 0; i < count; i++) {
            if (i == 0 || i == 6 || i == 12 || i == 18) {
                paintDegree.setStrokeWidth(5);
                paintDegree.setTextSize(30);
                // canvas.drawLine(mClockWidth,mClockHeight, mClockWidth,mClockHeight + 60, paintDegree);
                canvas.drawLine(mClockWidth, mClockHeight / 2, mClockWidth, mClockHeight / 2 + 60, paintDegree);
                String degreeStr = String.valueOf(i);
                canvas.drawText(degreeStr, mClockWidth - paintDegree.measureText(degreeStr) / 2, mClockHeight / 2 + 60 + 30, paintDegree);
            } else {
                paintDegree.setStrokeWidth(3);
                paintDegree.setTextSize(15);
                canvas.drawLine(mClockWidth, mClockHeight / 2, mClockWidth, mClockHeight / 2 + 30, paintDegree);
                String degreeStr = String.valueOf(i);
                canvas.drawText(degreeStr, mClockWidth - paintDegree.measureText(degreeStr) / 2, mClockHeight / 2 + 30 + 30, paintDegree);
            }
            canvas.rotate(360F / count, mClockWidth, mClockHeight);//以mClockWidth/2,mClockHeight/2(圆心原点)为原点旋转
        }
        canvas.save();

        Paint paintHour = new Paint();
        paintHour.setStrokeWidth(12);
        Paint paintMinute = new Paint();
        paintMinute.setStrokeWidth(6);
        canvas.translate(mClockWidth, mClockHeight);
        canvas.drawLine(0, 0, 70, 70, paintHour);
        canvas.drawLine(0, 0, 70, 120, paintMinute);
        canvas.restore(); //合并所有图层
    }
}
