package com.zhk.ningbo.mytestview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by Zhk on 2015/9/26.
 */
public class MyTestView extends View {
    public MyTestView(Context context) {
        super(context);
        init();
    }

    public MyTestView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MyTestView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public void init() {
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Paint paint = new Paint();
        paint.setColor(Color.GREEN);
        canvas.drawColor(Color.RED);
        canvas.drawColor(Color.BLUE);
        canvas.drawCircle(150, 150, 100, paint);

        canvas.saveLayerAlpha(0, 0, 400, 400, 127, Canvas.HAS_ALPHA_LAYER_SAVE_FLAG); //入栈，后面所有的操作都发生在这个图层上
        paint.setColor(Color.YELLOW);
        canvas.drawCircle(200,200,100,paint);
        canvas.restore(); //出栈，会把图像绘制到上层Canvas上
    }
}
