# netease_splash
High imitation Netease 5 boot screen（高仿网易5.0开机画面）
![image](https://github.com/heartinfei/netease_splash/blob/master/screen_img/device-2015-09-15-153930.png)
![image](https://github.com/heartinfei/netease_splash/blob/master/screen_img/device-2015-09-15-153943.png)
![image](https://github.com/heartinfei/netease_splash/blob/master/screen_img/device-2015-09-15-153957.png)

<li>中文介绍见: <a href="http://www.eoeandroid.com/thread-907686-1-1.html/">高仿网易5.0开机画面</a>

<h2><a id="user-content-usage" class="anchor" href="#usage" aria-hidden="true"><span class="octicon octicon-link"></span></a>Usage</h2>
<ul><li>Gradle Dependency (jCenter)</li></ul>
<p>Easily reference the library in your Android projects using this dependency in your module's <code>build.gradle</code> file:</p>

<div class="highlight highlight-source-groovy-gradle"><pre><span class="pl-en">dependencies</span> {
    compile <span class="pl-s"><span class="pl-pds">'</span>com.wangqiang.libs:splasviewgroup:1.0<span class="pl-pds">'</span></span>
}</pre></div>
详情请参考示例程序
