/** Automatically generated file. DO NOT MODIFY */
package com.wang.cn;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}