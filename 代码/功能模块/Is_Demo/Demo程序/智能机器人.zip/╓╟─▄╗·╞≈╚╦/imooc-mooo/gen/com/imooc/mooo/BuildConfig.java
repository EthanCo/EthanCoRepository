/** Automatically generated file. DO NOT MODIFY */
package com.imooc.mooo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}