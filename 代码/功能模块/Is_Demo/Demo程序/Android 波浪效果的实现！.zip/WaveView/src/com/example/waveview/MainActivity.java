package com.example.waveview;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;

import com.gelitenight.waveview.library.WaveView;

public class MainActivity extends Activity {
	private WaveHelper mWaveHelper;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_main);
		
		WaveView waveView = (WaveView) findViewById(R.id.wave);
        waveView.setBorder(10, Color.parseColor("#44FFFFFF"));
        
        mWaveHelper = new WaveHelper(waveView);
        waveView.postDelayed(new Runnable() {
            @Override
            public void run() {
                mWaveHelper.start();
            }
        }, 1000);
	}

}
