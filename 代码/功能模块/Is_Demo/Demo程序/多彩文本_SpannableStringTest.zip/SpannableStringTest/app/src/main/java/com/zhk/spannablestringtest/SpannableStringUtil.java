package com.zhk.spannablestringtest;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;

public class SpannableStringUtil {
    /**
     * 多彩文本生成
     *
     * @param source 原字符串（在xml先设置这串的字符大小，颜色）
     * @param changeStr 特殊字符串
     * @param changSize 相当原字符串的大小 如 两倍 2.0f
     * @param color 特殊字符串的颜色
     * @return
     */
    public static SpannableString getColorfulText(String source, String changeStr, float changSize,
                                                  int color) {
        SpannableString result = new SpannableString(source);
        int index = source.indexOf(changeStr);
        if (index == -1) {
            return result;
        }
        result.setSpan(new RelativeSizeSpan(changSize), index, index + changeStr.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (color != -1) {
            result.setSpan(new ForegroundColorSpan(color), index, index + changeStr.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return result;
    }

}
