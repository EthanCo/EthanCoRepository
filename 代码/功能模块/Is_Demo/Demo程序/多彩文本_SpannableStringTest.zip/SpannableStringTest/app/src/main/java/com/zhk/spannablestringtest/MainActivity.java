package com.zhk.spannablestringtest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.widget.TextView;

import butterknife.Bind;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @Bind(R.id.testTv)
    TextView testTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);


        String medicalStr = getString(R.string.textStr, "你好"); //此处只有字符串有效，如果是要用数组，可自己改写
        SpannableString countMedical = SpannableStringUtil.getColorfulText(medicalStr,
                String.valueOf("你好"), 1.5f, getResources().getColor(R.color.color1));
        testTv.setText(countMedical);
    }
}
