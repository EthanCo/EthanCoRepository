private void addUrlSpan() {  
    SpannableString spanString = new SpannableString("������");  
    URLSpan span = new URLSpan("tel:0123456789");  
    spanString.setSpan(span, 0, 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
    tv.append(spanString);  
}  
  
  
 
private void addBackColorSpan() {  
    SpannableString spanString = new SpannableString("���ֱ�����ɫ");  
    BackgroundColorSpan span = new BackgroundColorSpan(Color.YELLOW);  
    spanString.setSpan(span, 0, 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
    tv.append(spanString);  
}  
  
  
 
private void addForeColorSpan() {  
    SpannableString spanString = new SpannableString("����ǰ����ɫ");  
    ForegroundColorSpan span = new ForegroundColorSpan(Color.BLUE);  
    spanString.setSpan(span, 0, 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
    tv.append(spanString);  
}  
  
  
 
private void addFontSpan() {  
    SpannableString spanString = new SpannableString("36������");  
    AbsoluteSizeSpan span = new AbsoluteSizeSpan(36);  
    spanString.setSpan(span, 0, 5, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
    tv.append(spanString);  
}  
  
  
 
private void addStyleSpan() {  
    SpannableString spanString = new SpannableString("BIBI");  
    StyleSpan span = new StyleSpan(Typeface.BOLD_ITALIC);//�Ӵ�  
    spanString.setSpan(span, 0, 2, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
    tv.append(spanString);  
}  
  
  
 
private void addStrikeSpan() {  
    SpannableString spanString = new SpannableString("ɾ����");  
    StrikethroughSpan span = new StrikethroughSpan();  
    spanString.setSpan(span, 0, 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
    tv.append(spanString);  
}  
  
 
private void addUnderLineSpan() {  
    SpannableString spanString = new SpannableString("�»���");  
    UnderlineSpan span = new UnderlineSpan();  
    spanString.setSpan(span, 0, 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
    tv.append(spanString);  
}  
  
  
  
//ͼƬ
private void addImageSpan() {  
    SpannableString spanString = new SpannableString(" ");  
    Drawable d = getResources().getDrawable(R.drawable.ic_launcher);  
    d.setBounds(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());  
    ImageSpan span = new ImageSpan(d, ImageSpan.ALIGN_BASELINE);  
    spanString.setSpan(span, 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
    tv.append(spanString);  
}  