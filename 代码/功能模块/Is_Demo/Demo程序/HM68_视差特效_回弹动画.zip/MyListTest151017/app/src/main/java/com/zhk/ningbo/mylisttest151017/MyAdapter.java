package com.zhk.ningbo.mylisttest151017;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Zhk on 2015/10/17.
 */
public class MyAdapter extends BaseAdapter {

    private final List<String> data;
    private final Context mContext;
    private final LayoutInflater mLayoutInfalter;

    public MyAdapter(Context context, List<String> data) {
        this.mContext = context;
        this.mLayoutInfalter = LayoutInflater.from(context);
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = mLayoutInfalter.inflate(R.layout.list_item, null);
        TextView listItemTv = (TextView) view.findViewById(R.id.list_item_tv);
        listItemTv.setText(data.get(position));
        return view;
    }
}
