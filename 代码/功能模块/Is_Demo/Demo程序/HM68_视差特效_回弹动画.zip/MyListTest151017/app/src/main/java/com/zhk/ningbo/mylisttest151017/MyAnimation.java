package com.zhk.ningbo.mylisttest151017;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.OvershootInterpolator;
import android.view.animation.Transformation;

/**
 * Created by Zhk on 2015/10/17.
 */
public class MyAnimation extends Animation {
    private final View mView;
    private final int endHeight;
    private final int startHeight;

    public MyAnimation(View view, int startHeight, int endHeight) {
        this.mView = view;
        this.startHeight = startHeight;
        this.endHeight = endHeight;

        setInterpolator(new OvershootInterpolator()); //设置插值器，实现回弹效果
        setDuration(500); //设置默认的duration
    }

    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {
        // interpolatedTime 0.0f -> 1.0f
        Integer newHeight = evaluate(interpolatedTime, startHeight, endHeight);
        mView.getLayoutParams().height = newHeight;
        mView.requestLayout();

        super.applyTransformation(interpolatedTime, t);
    }

    /**
     * 类型估值器
     *
     * @param fraction
     * @param startValue
     * @param endValue
     * @return
     */
    public Integer evaluate(float fraction, Integer startValue, Integer endValue) {
        int startInt = startValue;
        return (int) (startInt + fraction * (endValue - startInt));
    }
}
