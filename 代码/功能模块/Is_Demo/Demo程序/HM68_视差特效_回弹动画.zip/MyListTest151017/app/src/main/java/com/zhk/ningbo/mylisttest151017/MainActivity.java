package com.zhk.ningbo.mylisttest151017;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private MyListView listView;
    private List<String> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (MyListView) findViewById(R.id.listView);
        listView.setOverScrollMode(View.OVER_SCROLL_NEVER); //去除ListView拉到顶的时候的阴影
        final View headerView = View.inflate(this, R.layout.list_header, null);
        final ImageView headerImg = (ImageView) headerView.findViewById(R.id.list_item_header_img);
        listView.addHeaderView(headerView);

        headerView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {  // 当布局填充结束之后, 此方法会被调用
                listView.setParallaxImage(headerImg);

                //headerView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                headerView.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            }
        });
        listView.setParallaxImage(headerImg);


        initData();
        listView.setAdapter(new MyAdapter(this, data));

    }

    private void initData() {
        data = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            data.add("Item" + i);
        }
    }
}
