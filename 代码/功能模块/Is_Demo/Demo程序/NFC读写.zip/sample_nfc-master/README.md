sample_nfc
==========

An Android Sample project to show how to use NFC.

With this app, you can:
- Read a tag
- Write a tag
- Beam text

For information, have a look at corresponding blog post: http://wiebe-elsinga.com/blog/?p=1269