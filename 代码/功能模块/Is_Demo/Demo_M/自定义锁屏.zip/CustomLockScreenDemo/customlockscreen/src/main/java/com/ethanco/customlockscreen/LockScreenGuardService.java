package com.ethanco.customlockscreen;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

/**
 * @Description 锁屏守护服务
 * Created by YOLANDA on 2016-02-15.
 */
public class LockScreenGuardService extends Service {

    Intent startIntent = null;
    private LockScreenReceiver receiver;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("Z-LockScreenGuard", "onStartCommand: ");
        startIntent = intent;
        registerLockScreenReceiver();
        return super.onStartCommand(intent, flags, startId);
    }

    private void registerLockScreenReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        receiver = new LockScreenReceiver();
        registerReceiver(receiver, filter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i("Z-LockScreenGuard", "onDestroy: ");
        unregisterReceiver(receiver);
        //常驻内存
        if (startIntent != null) {
            Log.i("Z-LockScreenGuard", "serviceIntent not null");
            startService(startIntent);
        }
    }
}
