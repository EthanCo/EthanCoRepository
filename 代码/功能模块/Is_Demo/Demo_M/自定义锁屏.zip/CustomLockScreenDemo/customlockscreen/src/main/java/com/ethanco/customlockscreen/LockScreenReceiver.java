package com.ethanco.customlockscreen;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * @Description 锁屏广播
 * Created by YOLANDA on 2016-02-15.
 */
public class LockScreenReceiver extends BroadcastReceiver {

    private LockScreenHelper record = LockScreenHelper.getInstance();

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.i("Z-LockScreenReceiver", "onReceive-action:" + action);
        Log.i("Z-LockScreenReceiver", "onReceive-class:" + record.getCurrLockScreenActivityClass());
        if (record.getCurrLockScreenActivityClass() != null) {
            Intent lockIntent = new Intent(context, record.getCurrLockScreenActivityClass());
            lockIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(lockIntent);
        }
    }
}
