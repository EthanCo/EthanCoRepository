package com.ethanco.customlockscreendemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.ethanco.customlockscreen.LockScreenHelper;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LockScreenHelper.getInstance().startLockScreenService(this);
        LockScreenHelper.getInstance().setCurrLockScreenActivityClass(MyLockScreenActivity.class);
    }
}
