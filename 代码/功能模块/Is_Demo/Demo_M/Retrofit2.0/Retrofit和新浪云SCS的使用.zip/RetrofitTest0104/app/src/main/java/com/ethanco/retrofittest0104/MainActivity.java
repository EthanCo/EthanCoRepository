package com.ethanco.retrofittest0104;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import retrofit.Callback;
import retrofit.Response;
import retrofit.Retrofit;

public class MainActivity extends AppCompatActivity {

    String url = "http://cdn.sinacloud.net/leisurealarmclock/test.txt";
    String baseUrl = "http://cdn.sinacloud.net/leisurealarmclock/";
    private Retrofit retrofit;
    private APIService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i("Z-MainActivity", "onCreate: 1");
        retrofit = new Retrofit.Builder().baseUrl(baseUrl)
                .addConverterFactory(new ToStringConverterFactory())
//                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();

        apiService = retrofit.create(APIService.class);
        apiService.loadTxt("test.txt").enqueue(new Callback<String>() {
            @Override
            public void onResponse(Response<String> response, Retrofit retrofit) {
                Log.i("Z-MainActivity", "onResponse: " + response.body().toString());
            }

            @Override
            public void onFailure(Throwable t) {
                Log.i("Z-MainActivity", "onFailure: " + t.getMessage());
            }
        });
    }
}
