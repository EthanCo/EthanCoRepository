package com.ethanco.retrofittest0104;

import retrofit.Call;
import retrofit.http.GET;
import retrofit.http.Path;

/**
 * Created by Zhk on 2015/12/20.
 */
public interface APIService {
   
	//如果是全路径，会覆盖原来的baseUrl
    @GET("http://cdn.sinacloud.net/leisurealarmclock/{fileName}")
    Call<String> loadTxt(@Path("fileName") String fileName);
}
