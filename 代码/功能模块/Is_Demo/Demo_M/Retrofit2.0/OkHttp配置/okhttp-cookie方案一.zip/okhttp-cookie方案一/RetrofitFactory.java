package cn.nbhope.smarthome.model.net;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.JavaNetCookieJar;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Retrofit工厂类
 * <p/>
 * Created by Zhk on 2016/1/5.
 */
public class RetrofitFactory {
    private RetrofitFactory() {
    }

    public static RetrofitFactory getInstance() {
        return SingletonHodler.sInstance;
    }

    private static class SingletonHodler {
        private static final RetrofitFactory sInstance = new RetrofitFactory();
    }

    private static final int TIME_OUT = 15;
    private HashMap<String, Retrofit> retrofitMap = new HashMap<>();

    public Retrofit createRetrofit(String baseUrl) {
        Retrofit retrofit = retrofitMap.get(baseUrl);

        if (retrofit == null) {
            CookieManager cookieManager = new CookieManager();
            cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
            CookieHandler.setDefault(cookieManager);
            JavaNetCookieJar jncj = new JavaNetCookieJar(CookieHandler.getDefault());
            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(new HttpLoggingInterceptor()
                            .setLevel(HttpLoggingInterceptor.Level.BODY))
                    .connectTimeout(TIME_OUT, TimeUnit.SECONDS)
                    .readTimeout(TIME_OUT, TimeUnit.SECONDS)
                    .writeTimeout(TIME_OUT, TimeUnit.SECONDS)
                    .cookieJar(jncj)
                    .build();


            retrofit = new Retrofit.Builder().baseUrl(baseUrl)
                    .addConverterFactory(new ToStringConverterFactory())
                    .addConverterFactory(GsonConverterFactory.create())
                    .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                    .client(client)
                    .build();

            retrofitMap.put(baseUrl, retrofit);
        }

        return retrofit;
    }
}
