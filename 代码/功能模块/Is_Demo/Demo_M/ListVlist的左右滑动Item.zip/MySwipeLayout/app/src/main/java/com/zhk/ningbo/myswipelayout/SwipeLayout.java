package com.zhk.ningbo.myswipelayout;

import android.content.Context;
import android.graphics.Rect;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.ViewDragHelper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Created by Zhk on 2015/10/17.
 */
public class SwipeLayout extends FrameLayout {
    private static final String TAG = "zhklog";
    private View mBackView;
    private View mFrontView;
    private ViewDragHelper mDrawHelper;
    private int mWidth;
    private int mHeight;
    private int mRange;

    public SwipeLayout(Context context) {
        super(context, null);
        init();
    }

    public SwipeLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SwipeLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        mDrawHelper = ViewDragHelper.create(this, 1.0f, new ViewDragHelper.Callback() {
            @Override
            public boolean tryCaptureView(View child, int pointerId) {
                return true;
            }

            @Override
            public int clampViewPositionHorizontal(View child, int left, int dx) {
                //// 限定移动范围
                if (child == mFrontView) {
                    if (left < -mRange) {
                        left = -mRange;
                    } else if (left > 0) {
                        left = 0;
                    }
                } else if (child == mBackView) {
                    if (left < mWidth - mRange) {
                        left = mWidth - mRange;
                    } else if (left > mWidth) {
                        left = mWidth;
                    }
                }

                return left;
            }

            @Override
            public void onViewPositionChanged(View changedView, int left, int top, int dx, int dy) {
                super.onViewPositionChanged(changedView, left, top, dx, dy);

                if (mBackView == changedView) {
                    mFrontView.offsetLeftAndRight(dx);
                } else if (mFrontView == changedView) {
                    mBackView.offsetLeftAndRight(dx);
                }

                invalidate(); //兼容老版本
            }

            /**
             * 当View被释放的时候, 处理的事情(执行动画)
             * @param releasedChild 被释放的子View
             * @param xvel          水平方向的速度, 向右为+
             * @param yvel          竖直方向的速度, 向下为+
             */
            @Override
            public void onViewReleased(View releasedChild, float xvel, float yvel) {
                super.onViewReleased(releasedChild, xvel, yvel);

                if (xvel == 0 && mFrontView.getLeft() < -mRange / 2.0F) {
                    open();
                } else if (xvel < 0) {
                    open();
                } else {
                    close();
                }
            }

            @Override
            public int getViewHorizontalDragRange(View child) {
                return mRange * 50; //// 返回拖拽的范围, 不对拖拽进行真正的限制. 仅仅决定了动画执行速度
            }
        });
    }

    private void close() {
        close(true);
    }

    private void close(boolean isSmooth) {
        int finalLeft = 0;
        if (isSmooth) {
            if (mDrawHelper.smoothSlideViewTo(mFrontView, finalLeft, 0)) {
                ViewCompat.postInvalidateOnAnimation(this);
            }
        } else {
            layoutContent(false);
        }
    }

    private void open() {
        open(true);
    }

    private void open(boolean isSmooth) {
        int finalLeft = -mRange;
        if (isSmooth) {
            if (mDrawHelper.smoothSlideViewTo(mFrontView, finalLeft, 0)) {
                ViewCompat.postInvalidateOnAnimation(this);
            }
        } else {
            layoutContent(true);
        }
    }

    @Override
    public void computeScroll() {
        super.computeScroll();

        if (mDrawHelper.continueSettling(true)) {
            ViewCompat.postInvalidateOnAnimation(this);
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        return mDrawHelper.shouldInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        try {
            mDrawHelper.processTouchEvent(event);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    /**
     * 当XML被填充完毕时调用
     */
    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        Log.i(TAG, "onFinishInflate");
        int childCount = getChildCount();

        if (childCount < 2) {
            throw new RuntimeException("子View必须>=2");
        }
        // 当xml被填充完毕时调用
        mBackView = getChildAt(0);
        mFrontView = getChildAt(1);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        Log.i("TAG", "onSizeChanged");

        mWidth = mFrontView.getMeasuredWidth();
        mHeight = mFrontView.getMeasuredHeight();

        mRange = mBackView.getMeasuredWidth();
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        layoutContent(false);
    }

    private void layoutContent(boolean isOpen) {
        Rect frontRect = computeFrontViewRect(isOpen);
        mFrontView.layout(frontRect.left, frontRect.top, frontRect.right, frontRect.bottom);

        Rect backRect = computeBackViewRect(frontRect);
        mBackView.layout(backRect.left, backRect.top, backRect.right, backRect.bottom);

        // 调整顺序, 把mFrontView前置
        bringChildToFront(mFrontView);
    }

    private Rect computeBackViewRect(Rect frontRect) {
        int left = frontRect.right;
        return new Rect(left, 0, left + mRange, 0 + mHeight);
    }


    private Rect computeFrontViewRect(boolean isOpen) {
        int left = 0;
        if (isOpen) {
            left = -mRange;
        }
        return new Rect(left, 0, mWidth, 0 + mHeight);
    }
}
