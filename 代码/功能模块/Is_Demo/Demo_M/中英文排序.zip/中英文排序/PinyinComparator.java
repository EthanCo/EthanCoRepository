package com.sh.sp.utils;

import java.util.Comparator;

import cn.nbhope.player.Music;

/**
 * Created by wang4 on 2016/9/12.
 */
public class PinyinComparator implements Comparator<Music> {
    public int compare(Music m1, Music m2) {
        //这里主要是用来对Music里面的数据根据ABCDEFG...来排序
            CharacterParser parser=CharacterParser.getInstance();
            String title1=parser.getSelling(m1.getTitle()).substring(0, 1).toUpperCase();
            String title2=parser.getSelling(m2.getTitle()).substring(0, 1).toUpperCase();
            return title1.compareTo(title2);
    }
}
