# Dagger 2 初体验 #
## Gradle配置 ##
### 在 Project 的 Gradle 中添加  

	dependencies {
        classpath 'com.android.tools.build:gradle:2.0.0-alpha3'
        // ---------------- Add ------------------ 
        classpath 'com.neenbedankt.gradle.plugins:android-apt:1.8'
		// ---------------- END ------------------     
	}

### 在 Module 的 Gradle 中添加

添加插件（Dagger2的原理是在编译时注入代码）

	apply plugin: 'com.neenbedankt.android-apt'

添加依赖  

	dependencies {	
		compile 'com.google.dagger:dagger:2.0.2'
	    apt 'com.google.dagger:dagger-compiler:2.0.2'
	    compile 'org.glassfish:javax.annotation:10.0-b28'
	}

最后一个依赖是javax注解的依赖。  

### 基础注解 ###
@Inject（注入）：使用这个注解是告诉Dagger当前申明的类或者属性需要被注入，Dagger会根据配置来提供它的一个实例。   
@Module（模块）：它申明Dagger在哪里可以找到依赖，可以把多个Module合并到一块向Component提供依赖。   
@Provide（提供）：这个注解在@Module里使用，定义申明的方法告诉Dagger我们是如何构造并提供Module申明的实例的。   
@Component（组件）：它是连接Inject和Module的容器，我们将写好的Module放入Component中，并且通过他向申明了Inject的类或者属性提供注入。   


### 使用Dragger2实现依赖注入 ###

#### 新建Model ####

	public class Person {
	    public Person(String name, int age) {
	        this.name = name;
	        this.age = age;
	    }
	
	    private String name;
	    private int age;
	
	    public String getName() {
	        return name;
	    }
	
	    public void setName(String name) {
	        this.name = name;
	    }
	
	    public int getAge() {
	        return age;
	    }
	
	    public void setAge(int age) {
	        this.age = age;
	    }
	}

#### 创建Module ####
负责提供依赖的组件被称为Module

	@Module
	public class MainActivityModule {
	    @Provides
	    public Person generatePerson() {
	        return new Person("EthanCo", 18);
	    }
	}

#### 创建Component ####
连接提供Module和Inject的组件被称为component  

	@Component(modules = MainActivityModule.class)
	public interface MainActivityComponent {
	    void inject(MainActivity activity);
	}

#### 完成依赖注入 ####
在Activity中  

	 public class MainActivity extends AppCompatActivity {
	
	    @Inject
	    Person person;
	
	    private MainActivityComponent activityComponent;
	
	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.activity_main);
	
	
	        //DaggerMainActivityComponent : 由"Dagger" + Component类的类名组成
	        activityComponent = DaggerMainActivityComponent.builder().mainActivityModule(new MainActivityModule()).build();
	        activityComponent.inject(this);
	
	        //依赖注入已完成，已经可以使用@Inject注解的注解类
	        TextView textView = (TextView) findViewById(R.id.textView);
	        textView.setText("姓名:" + person.getName() + " 年龄:" + person.getAge());
	    }
	}

DaggerMainActivityComponent在编译时自动生成

#### 运行后 ####
TextView显示 : 


> 姓名:EthanCo 年龄:18

### 其他 ###
> 参考  
> [http://blog.csdn.net/cn_foolishman/article/details/50235919](http://blog.csdn.net/cn_foolishman/article/details/50235919)  
> [http://codethink.me/2015/08/06/dependency-injection-with-dagger-2/](http://codethink.me/2015/08/06/dependency-injection-with-dagger-2/)