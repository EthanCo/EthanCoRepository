package com.ebanswers.stove.mytest0108;

/**
 * @Description TODO
 * Created by YOLANDA on 2016-01-08.
 */
public class UserModel {
    public String name = "朱豪凯";
    public int age = 19;
}
