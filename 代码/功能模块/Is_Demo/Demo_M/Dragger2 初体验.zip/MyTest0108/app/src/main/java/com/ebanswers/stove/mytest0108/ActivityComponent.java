package com.ebanswers.stove.mytest0108;

import dagger.Component;

/**
 * @Description TODO
 * Created by YOLANDA on 2016-01-08.
 */
//@Component(modules = {ActivityModule.class})
@Component(modules = ActivityModule.class)
public interface ActivityComponent {
    void inject(MainActivity activity);
}
