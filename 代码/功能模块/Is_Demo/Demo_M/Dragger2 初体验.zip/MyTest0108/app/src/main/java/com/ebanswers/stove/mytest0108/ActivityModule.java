package com.ebanswers.stove.mytest0108;

import dagger.Module;
import dagger.Provides;

/**
 * @Description TODO
 * Created by YOLANDA on 2016-01-08.
 */
@Module
public class ActivityModule {

    @Provides
    public UserModel provideUserModel() {
        return new UserModel();
    }
}
