package com.ethanco.myautopoweroff;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.WindowManager;

/**
 * Created by YOLANDA on 2015-11-05.
 */
public class DialogUtil {
    /**
     * 弹出普通对话框
     *
     * @param title
     * @param message
     * @param context
     * @param onDialogClickListener
     * @param isSystemAlert         是否是系统级别的(Service适用)，需ndroid.permission.SYSTEM_ALERT_WINDOW权限
     * @param isCancelOutside       是否点击dialog外部消失
     */
    public static Dialog alertDialog(String title, String message, Context context, final OnDialogClickListener onDialogClickListener, boolean isSystemAlert, boolean isCancelOutside) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        //builder.setCancelable(false);//屏蔽了回退键
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(R.string.cancel_poweroff, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                if (onDialogClickListener != null) {
                    onDialogClickListener.onPositiveClick();
                }
            }
        });
        builder.setNegativeButton(R.string.continue_poweroff, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                if (onDialogClickListener != null) {
                    onDialogClickListener.onNegativeClick();
                }
            }
        });

        AlertDialog dialog = builder.create();
        if (isSystemAlert)
            dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
        if (isCancelOutside)
            dialog.setCanceledOnTouchOutside(true);
        dialog.show();
        return dialog;
    }

    /**
     * 弹出系统级Dialog(Service适用)，需ndroid.permission.SYSTEM_ALERT_WINDOW权限
     *
     * @param title
     * @param message
     * @param context
     * @param onDialogClickListener
     */
    public static Dialog alertSystemDialog(String title, String message, Context context, final OnDialogClickListener onDialogClickListener) {
        return alertDialog(title, message, context, onDialogClickListener, true, true);
    }

    public interface OnDialogClickListener {
        void onPositiveClick();

        void onNegativeClick();
    }
}
