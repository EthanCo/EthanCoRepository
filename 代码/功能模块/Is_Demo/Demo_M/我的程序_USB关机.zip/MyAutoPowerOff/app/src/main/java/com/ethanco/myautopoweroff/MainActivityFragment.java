package com.ethanco.myautopoweroff;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    private SeekBar offTimeSeekBar;
    private FloatingActionButton confirmFab;
    private TextView timeTv;

    public MainActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        offTimeSeekBar = (SeekBar) view.findViewById(R.id.seekBar_off_time);
        timeTv = (TextView) view.findViewById(R.id.tv_time);
        confirmFab = (FloatingActionButton) view.findViewById(R.id.fab);
        offTimeSeekBar.setProgress(PreferenceUtil.getInstance().getPowerOffTime() / 60);
        timeTv.setText(offTimeSeekBar.getProgress() + "分钟");
        offTimeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                setTimeTv(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public int getPowerOffTime() {
        return offTimeSeekBar.getProgress() * 60;
    }

    public void setPowerOffTime(int time) {
        int minutes = time / 60;
        setTimeTv(minutes);
        offTimeSeekBar.setProgress(minutes);
    }

    private void setTimeTv(int progress) {
        if (progress == 0) {
            timeTv.setText("马上");
        } else if (offTimeSeekBar.getMax() == progress) {
            timeTv.setText(String.valueOf(progress) + "分钟");
        } else {
            timeTv.setText(String.valueOf(progress) + "分钟");
        }
    }
}
