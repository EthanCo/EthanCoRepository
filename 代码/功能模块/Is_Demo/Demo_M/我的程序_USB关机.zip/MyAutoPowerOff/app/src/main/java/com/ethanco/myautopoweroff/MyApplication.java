package com.ethanco.myautopoweroff;

import android.app.Application;
import android.content.Context;

/**
 * Created by YOLANDA on 2015-10-29.
 */
public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        mContext = getApplicationContext();
        PowerUtil.upgradeRootPermission(getPackageCodePath());
    }

    public static Context mContext = null;

    public static Context getContext() {
        return mContext;
    }
}
