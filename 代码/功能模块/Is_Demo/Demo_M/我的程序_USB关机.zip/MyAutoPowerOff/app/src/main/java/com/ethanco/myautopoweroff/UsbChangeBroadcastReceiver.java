package com.ethanco.myautopoweroff;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by YOLANDA on 2015-10-29.
 */
public class UsbChangeBroadcastReceiver extends BroadcastReceiver {
    private static final String TAG = "zhklog-UsbChange";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action.equals("android.hardware.usb.action.USB_STATE")) {
            boolean connected = intent.getExtras().getBoolean("connected");
            Intent i = new Intent(context, PowerOffService.class);
            i.putExtra("connected", connected);

            if (connected) {
                Log.i(TAG, "usb插入");
                Toast.makeText(context, "usb插入", Toast.LENGTH_SHORT).show();
                if (!PreferenceUtil.getInstance().getAlreadyPlugInUsb()) {
                    PreferenceUtil.getInstance().setAlreadyPlugInUsb(true);
                    context.startService(i);
                }
            } else {
                Log.i(TAG, "usb拔出");
                Toast.makeText(context, "usb拔出", Toast.LENGTH_SHORT).show();
                if (PreferenceUtil.getInstance().getAlreadyPlugInUsb()) {
                    PreferenceUtil.getInstance().setAlreadyPlugInUsb(false);
                    context.startService(i);
                }
            }
        }
    }
}
