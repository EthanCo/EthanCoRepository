package com.ethanco.myautopoweroff;

import android.content.SharedPreferences;

/**
 * Created by YOLANDA on 2015-10-29.
 */
public class PreferenceUtil {
    private static final String FILE_NAME = "com.ethanco.myautopoweroff.sp";
    private static final String POWER_OFF_TIME = "powerOffTime";
    private static final String ALREADY_PLUG_IN = "alreadyPlugInUsb";
    private final SharedPreferences sp;

    private PreferenceUtil() {
        sp = MyApplication.getContext().getSharedPreferences(FILE_NAME, MyApplication.getContext().MODE_PRIVATE);
    }

    private static PreferenceUtil sInstance;

    public static PreferenceUtil getInstance() {
        if (sInstance == null) {
            sInstance = new PreferenceUtil();
        }
        return sInstance;
    }

    public void setPowerOffTime(int second) {
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(POWER_OFF_TIME, second);
        editor.commit();
    }

    public int getPowerOffTime() {
        return sp.getInt(POWER_OFF_TIME, 20);
    }

    public void setAlreadyPlugInUsb(boolean b) {
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean(ALREADY_PLUG_IN, b);
        editor.commit();
    }

    public boolean getAlreadyPlugInUsb() {
        return sp.getBoolean(ALREADY_PLUG_IN, false);
    }
}
