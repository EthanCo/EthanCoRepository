package com.ethanco.myautopoweroff;

import android.app.Dialog;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;

/**
 * Created by YOLANDA on 2015-10-29.
 */
public class PowerOffService extends Service {

    private static final String TAG = "zhklog-PowerOffService";
    private static final int ASK_POWER_OFF = 990_000_001;
    private static final int CHANGE_DIALOG_TIME = ASK_POWER_OFF + 1;
    private static final int DISMISS_DIALOG = CHANGE_DIALOG_TIME + 1;
    private Thread timerThread;
    private boolean isUsbConn = true;
    private int time = 0;

    private static final int SHOW_TIP = 725;

    private Dialog dialog;
    Handler myHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SHOW_TIP:
                    Toast.makeText(getApplicationContext(), (String) msg.obj, Toast.LENGTH_SHORT).show();
                    break;
                case ASK_POWER_OFF:
                    timerThread.start();
                    dialog = DialogUtil.alertSystemDialog("USB关机", "USB已拔出，系统将自动关机，是否取消?", getApplicationContext(), new DialogUtil.OnDialogClickListener() {
                        @Override
                        public void onPositiveClick() {
                            isUsbConn = true;
                        }

                        @Override
                        public void onNegativeClick() {
                        }
                    });
                    break;
                case DISMISS_DIALOG:
                    if (dialog != null && dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(PowerOffService.this, "Service onCreate", Toast.LENGTH_SHORT).show();
        Log.i(TAG, "onCreate");
        timerThread = new Thread() {
            @Override
            public void run() {
                time = 0;
                final int totalTime = PreferenceUtil.getInstance().getPowerOffTime();
                while (!isUsbConn) {
                    time++;
                    SystemClock.sleep(1000);
                    if (time == totalTime - 10) {
                        ShowTip("系统即将关机");
                    } else if (time >= totalTime) {
                        powerOff();
                    }
                }
            }
        };
    }

    private void powerOff() {
        try {
            PowerUtil.powerOff_2();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            PowerUtil.powerOff_1();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        isUsbConn = intent.getExtras().getBoolean("connected");
        Toast.makeText(PowerOffService.this, "Service isUsbConn:" + isUsbConn, Toast.LENGTH_SHORT).show();
        Log.i(TAG, "" + isUsbConn);
        if (!isUsbConn) { //如果没有连接usb，则自动关机
            if (timerThread != null && !timerThread.isAlive()) {
                myHandler.sendEmptyMessage(ASK_POWER_OFF);
            }
        } else {
            stopSelf();
        }

        return START_REDELIVER_INTENT;
        //return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        myHandler.sendEmptyMessage(DISMISS_DIALOG);
        ShowTip("USB插入，已取消关机");
        isUsbConn = true;
        Toast.makeText(PowerOffService.this, "Service onDestory", Toast.LENGTH_SHORT).show();
        Log.i(TAG, "onDestroy ");
        super.onDestroy();
    }

    /**
     * 提示Toast
     *
     * @param tip
     */
    private void ShowTip(String tip) {
        Message msg = Message.obtain();
        msg.what = SHOW_TIP;
        msg.obj = tip;
        myHandler.sendMessage(msg);
    }
}
