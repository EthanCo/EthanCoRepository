package com.zhk.ningbo.mysocketclienttest;

/**
 * Created by YOLANDA on 2015-10-15.
 */
public interface onReceiveListener {
    void onReceive(String data);

    void onReceive(byte[] data);
}
