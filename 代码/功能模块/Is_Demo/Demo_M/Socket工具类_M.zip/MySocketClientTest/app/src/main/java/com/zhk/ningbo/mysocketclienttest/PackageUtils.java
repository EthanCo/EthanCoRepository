package com.zhk.ningbo.mysocketclienttest;

import android.app.ActivityManager;
import android.content.Context;

import java.util.List;

/**
 * Created by YOLANDA on 2015-10-15.
 */
public class PackageUtils {
    /**
     * 判断当前应用程序是否是在前台运行
     *
     * @return true-在前台运行; false-otherwise
     */
    public static boolean isAppShowing(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);

        List<ActivityManager.RunningAppProcessInfo> appProcesses = am.getRunningAppProcesses();

        if (appProcesses == null)
            return false;

        // 可以根据importance的不同来判断前台或后台.
        // RunningAppProcessInfo里面的常量importance就是上面所说的前台后台,
        // 其实importance是表示这个app进程的重要性, 因为系统回收时候,
        // 会根据importance来回收进程的. 具体可以去看文档...
        for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : appProcesses) {
            if (runningAppProcessInfo.processName.equals(context.getPackageName())) {
                int status = runningAppProcessInfo.importance;
                if (status == ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE
                        || status == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    return true;
                }
            }
        }

        return false;
    }
}
