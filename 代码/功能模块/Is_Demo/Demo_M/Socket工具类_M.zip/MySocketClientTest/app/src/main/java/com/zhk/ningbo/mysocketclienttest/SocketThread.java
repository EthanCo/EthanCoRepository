package com.zhk.ningbo.mysocketclienttest;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.text.TextUtils;

import java.io.IOException;
import java.net.ConnectException;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by YOLANDA on 2015-10-15.
 */

/**
 * Created by YOLANDA on 2015-10-15.
 */
public class SocketThread extends Thread {

    private final Context mContent;
    private final String address;
    private final int port;
    private SocketUtil receiverUtil;
    private SocketUtil sendUtil;

    public boolean isReceivingAlways() {
        return isReceivingAlways;
    }

    /**
     * 是否持续接收
     */
    private boolean isReceivingAlways = true;
    /**
     * receiveSocket是否处于连接状态
     */
    private boolean isConnected = true;

    public boolean isWait() {
        return isWait;
    }

    private boolean isWait = false;

    public Lock getReceiveLock() {
        return receiveLock;
    }

    private Lock receiveLock = new ReentrantLock();

    public Condition getReceiveCondition() {
        return receiveCondition;
    }

    private Condition receiveCondition;

    public boolean isReadLine() {
        return isReadLine;
    }

    public void setIsReconnect(boolean isReconnect) {
        this.isReconnect = isReconnect;
    }

    /**
     * 是否开启断线重连
     */
    public boolean isReconnect = true;

    /**
     * 设置是否按一行读取（以/r,/n,/r/n结尾为一行,若服务端发送的消息不以上述标识结尾，则接收不到），若为false，则按byte[]读取
     */
    public void setIsReadLine(boolean isReadLine) {
        this.isReadLine = isReadLine;
    }

    /**
     * 是否按一行读取（以/r,/n,/r/n结尾为一行,若服务端发送的消息不以上述标识结尾，则接收不到），若为false，则按byte[]读取
     */
    private boolean isReadLine = false;

    private static final int READ_STRING = 392; //读取到String
    private static final int READ_BYTES = 151; //读取到byte数组
    private static final int CONN_SUCCESS = 390; //连接成功
    private static final int SOCKET_EXCEPTION = 880; //socket异常
    private static final int SOCKET_CLOSE = 675; //socket安全关闭
    private static final int SEND_SUCCESS = 621; //发送成功
    private static final int SEND_FAILED = 284; //发送失败


    public SocketThread(Context context, String address, int port) {
        this.mContent = context;
        this.address = address;
        this.port = port;
        this.receiveCondition = receiveLock.newCondition();
        this.setPriority(4); //默认降低线程优先级
    }

    private Handler mHander = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case READ_STRING:
                    String data = (String) msg.obj;
                    receiveListener.onReceive(data);
                    receiveListener.onReceive(HexUtils.hexStr2Bytes(data));
                    break;
                case READ_BYTES:
                    byte[] bytes = (byte[]) msg.obj;
                    receiveListener.onReceive(bytes);
                    receiveListener.onReceive(HexUtils.bytesToHexString(bytes));
                case CONN_SUCCESS:
                    connListener.onConnectioned();
                    break;
                case SOCKET_EXCEPTION:
                    connListener.onUnConnected((String) msg.obj);
                    break;
                case SOCKET_CLOSE:
                    connListener.onConnectioned();
                    break;
                case SEND_SUCCESS:
                    sendListener.onSendSuccess();
                    break;
                case SEND_FAILED:
                    sendListener.onSendFaild((String) msg.obj);
                    break;
            }
        }
    };

    @Override
    public void run() {
        receiverRun();
    }

    private void receiverRun() {
        try {
            initReceiverUtil();
            //initSendUtil();
            mHander.sendEmptyMessage(CONN_SUCCESS);
            LogUtil.i("zhklog", "lock");
            receiveLock.lock();
            while (isReceivingAlways) {
                isWait = false;
                do {
                    if (isConnected) {
                        readInputStream();
                    }
                    startReConnect();
                    LogUtil.i("zhklog", "SocketThread receiver is runing");
                } while (PackageUtils.isAppShowing(mContent));
                if (!isWait) {
                    LogUtil.i("zhklog", "await");
                    isWait = true;
                    receiveCondition.await();
                }
            }
            LogUtil.i("zhklog", "socket colose");
            mHander.sendEmptyMessage(SOCKET_CLOSE);
        } catch (IOException e) {
            LogUtil.i("zhklog", "IOException:" + e.getMessage());
            Message msg = Message.obtain();
            msg.what = SOCKET_EXCEPTION;
            msg.obj = "接收失败";
            mHander.sendMessage(msg);
            e.printStackTrace();
            closeReceiverSocket();
            SystemClock.sleep(3000);
            if (isReceivingAlways) {
                LogUtil.i("zhklog", "重连");
                receiverRun();
            }
        } catch (InterruptedException e) {
            //TODO
            e.printStackTrace();
        } finally {
            receiveLock.unlock();
            //closeReceiverSocket();
        }
    }

    /**
     * 重连
     */
    private void startReConnect() {
        if (isReconnect) {
            reConnect();
        }
    }

    private void readInputStream() throws IOException {
        Message msg = Message.obtain();
        if (isReadLine) {
            String readStr = receiverUtil.readLine();
            msg.what = READ_STRING;
            msg.obj = readStr;
            LogUtil.i("zhklog", "readString :" + readStr);
            if (!TextUtils.isEmpty(readStr)) {
                mHander.sendMessage(msg);
            }
        } else {
            byte[] bytes = receiverUtil.readBytes();
            msg.what = READ_BYTES;
            msg.obj = bytes;
            LogUtil.i("zhklog", "readByte[] len:" + bytes.length);
            if (bytes != null && bytes.length > 0) {
                mHander.sendMessage(msg);
            }
        }
    }

    /**
     * 断线重连
     */
    private void reConnect() {
        try {
            if (!isInterrupted() && isReceivingAlways()) {
                if (receiverUtil != null) {
                    try {
                        LogUtil.i("zhklog", "sendUrgentData");
                        //socket.sendUrgentData(0xff);
                        //receiverUtil.writeByte(0xFF);
                        //receiverUtil.sendString("FF");
                        receiverUtil.sendLine("FF");
                    } catch (IOException e) {
                        //说明断线了
                        LogUtil.i("zhklog", "断线了:" + e.getMessage());
                        e.printStackTrace();
                        isConnected = false;
                    }
                    SystemClock.sleep(3000);
                    if (!isConnected) {
                        //重连
                        LogUtil.i("zhklog", "重连");
                        initReceiverUtil();
                        isConnected = true;
                    }
                }
            }
        } catch (IOException e) {
            LogUtil.e("zhklog", "IOException:" + e.getMessage());
            e.printStackTrace();
            startReConnect();
        }
    }

    private void initReceiverUtil() throws IOException {
        receiverUtil = new SocketUtil(address, port);
    }

    private void initSendUtil() throws IOException {
        sendUtil = new SocketUtil(address, port);
        LogUtil.i("zhklog", "sendUtil is null:" + (sendUtil == null));
    }

    public void closeSendSocket() {
        if (sendUtil != null) {
            sendUtil.closeSocket();
        }
    }

    public void closeReceiverSocket() {
        if (receiverUtil != null) {
            receiverUtil.closeSocket();
        }
    }

    public void closeALL() {
        closeSendSocket();
        closeReceiverSocket();
    }

    /**
     * 发送是否成功
     */
    private boolean sendSuccess;

    public void sendLine(final String s) {
        new Thread() {
            @Override
            public void run() {
                sendSuccess = false;
                sendSuccess = sendData(s, true);
                if (!sendSuccess) {
                    sendSuccess = sendData(s, false);
                }

                if (sendSuccess) {
                    mHander.sendEmptyMessage(SEND_SUCCESS);
                } else {
                    Message msg = Message.obtain();
                    msg.what = SEND_FAILED;
                    msg.obj = "发送失败";
                    mHander.sendMessage(msg);
                }
            }
        }.start();
    }

    /**
     * 发送数据
     *
     * @param data        发送的数据
     * @param isJudgeNull 是否检查sendsocket为null
     */
    private boolean sendData(String data, boolean isJudgeNull) {

        boolean sendResult = false;
        try {
            if (isJudgeNull) {
                if (sendUtil == null) {
                    initSendUtil();
                }
            } else {
                initSendUtil();
            }
            sendUtil.sendLine(data);
            sendResult = true;
        } catch (ConnectException e2) {
            sendResult = false;
            Message msg = Message.obtain();
            msg.what = SOCKET_EXCEPTION;
            msg.obj = "请检查网络连接是否正常";
            mHander.sendMessage(msg);
        } catch (IOException e1) {
            sendResult = false;
            e1.printStackTrace();
        } finally {
            return sendResult;
        }
    }

    public void setConnListener(onConnListener connListener) {
        this.connListener = connListener;
    }

    public onConnListener connListener = new onConnListener() {
        @Override
        public void onConnectioned() {

        }

        @Override
        public void onClose() {

        }

        @Override
        public void onUnConnected(String error) {

        }
    };

    public void setReceiveListener(onReceiveListener receiveListener) {
        this.receiveListener = receiveListener;
    }

    public onReceiveListener receiveListener = new onReceiveListener() {// 在主线程
        @Override
        public void onReceive(String data) {

        }

        @Override
        public void onReceive(byte[] data) {

        }
    };

    public void setSendListener(onSendListener sendListener) {
        this.sendListener = sendListener;
    }

    public onSendListener sendListener = new onSendListener() {
        @Override
        public void onSendSuccess() {

        }

        @Override
        public void onSendFaild(String error) {

        }
    };
}
