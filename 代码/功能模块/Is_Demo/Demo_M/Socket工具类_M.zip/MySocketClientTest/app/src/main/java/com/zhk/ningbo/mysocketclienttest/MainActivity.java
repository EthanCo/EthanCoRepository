package com.zhk.ningbo.mysocketclienttest;

import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class MainActivity extends AppCompatActivity {

    private TextView infoTv;
    private Button startBtn;
    SocketUtil util = null;
    private Button stopBtn;
    private Button startReciverBtn;
    private Button sendBtn;


    private Lock lock = new ReentrantLock();
    private Condition condition = lock.newCondition();

    private static final String TAG = "zhklog";
    private static final String address = "192.168.1.163";  //TODO 修改ip --------------------------------------------------------------- <<<<<<<<<<<<<<<<<<<
    private static final int port = 3000;                   //TODO 修改端口 --------------------------------------------------------------- <<<<<<<<<<<<<<<<<<<
    private SocketThread socketThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        infoTv = (TextView) findViewById(R.id.infoTv);
        startBtn = (Button) findViewById(R.id.StartBtn);
        stopBtn = (Button) findViewById(R.id.stopBtn);
        startReciverBtn = (Button) findViewById(R.id.StartReceiverBtn);
        sendBtn = (Button) findViewById(R.id.sendBtn);

        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    @Override
                    public void run() {
                        try {
                            Log.i(TAG, "start");
                            util = new SocketUtil(address, port);
                            while (true) {
                                util.sendLine("AA0901D4FEF6000900020000FFEC55");
//                              util.sendString("AA0901D4FEF6000900020000FFEC55\n");
                                Log.i(TAG, "send");
                                byte[] bytes = util.readBytes();
                                final String str = HexUtils.bytesToHexString(bytes);
                                //final String str = util.readLine();
                                MainActivity.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        infoTv.append(str);
                                    }
                                });
                                SystemClock.sleep(5000);
                            }
                        } catch (IOException e) {
                            Log.e(TAG, e.getMessage());
                            e.printStackTrace();
                        } finally {
                            util.closeSocket();
                        }
                    }
                }.start();
            }
        });

        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    @Override
                    public void run() {
                        util.closeSocket();
                    }
                }.start();
            }
        });

        startReciverBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                socketThread = new SocketThread(MainActivity.this, address, port);
                socketThread.setConnListener(new onConnListener() {
                    @Override
                    public void onConnectioned() {
                        Log.i("zhklog ", "onConnectioned");
                    }

                    @Override
                    public void onClose() {
                        Log.i("zhklog", " onClose");
                    }

                    @Override
                    public void onUnConnected(final String error) {
                        Toast.makeText(getApplicationContext(), error, Toast.LENGTH_SHORT).show();

                    }
                });
                socketThread.setReceiveListener(new onReceiveListener() {
                    @Override
                    public void onReceive(String data) {
                        infoTv.append(data);
                        Log.i("zhklog", "receiver:" + data);
                    }

                    @Override
                    public void onReceive(byte[] data) {
                        Log.i("zhklog", "receiver:" + data);
                    }
                });
                socketThread.setSendListener(new onSendListener() {
                    @Override
                    public void onSendSuccess() {
                        Toast.makeText(getApplicationContext(), "发送成功", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onSendFaild(final String error) {
                        Toast.makeText(getApplicationContext(), error, Toast.LENGTH_SHORT).show();
                    }
                });
                socketThread.start();

                sendBtn.setEnabled(true);
            }
        });

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                socketThread.sendLine("AA0901D4FEF6000900020000FFEC55");
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (socketThread != null && socketThread.isAlive()) {
            lock.lock();
            condition.signal();
            lock.unlock();
        }
    }
}
