package com.zhk.ningbo.mysocketclienttest;

/**
 * Created by YOLANDA on 2015-10-15.
 */
public interface onConnListener {
    void onConnectioned();

    void onClose();

    void onUnConnected(String error);
}




