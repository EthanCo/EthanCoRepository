package com.zhk.ningbo.mysocketclienttest;

/**
 * Created by YOLANDA on 2015-10-15.
 */
public interface onSendListener {
    void onSendSuccess();

    void onSendFaild(String error);
}
