package com.zhk.ningbo.mysocketclienttest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 * Created by Zhk on 2015/10/14.
 */
public class SocketUtil {

    private static final String CHAR_SET = "utf-8";
    private BufferedWriter writer;
    private OutputStream output;
    private Socket socket;

    public SocketUtil(String address, int port) throws IOException {
        socket = new Socket(address, port);
        output = socket.getOutputStream();
        writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), CHAR_SET));
//        writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), CHAR_SET)), true);
    }

    /**
     * 以byte数组形式发送
     *
     * @param bytes
     * @throws IOException
     */
    public void sendBytes(byte[] bytes) throws IOException {
        output.write(bytes);
        output.flush();
    }

    /**
     * 发送消息到服务器
     *
     * @param s
     * @return
     * @throws IOException
     */
    public void sendString(String s) throws IOException {
        writer.write(s);
        writer.flush();
    }

    /**
     * 发送一行数据到服务器
     *
     * @param s
     */
    public void sendLine(String s) throws IOException {
        //writer.println(s); //自动flush
        if (!(s.endsWith("\r\n") || s.endsWith("\n") || s.endsWith("\r"))) {
            s += "\n";
        }
        writer.write(s);
        writer.flush();
    }

    public byte[] readBytes() throws IOException {
        if (socket != null) {
            InputStream input = socket.getInputStream();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            if (input != null) {
                byte[] buffer = new byte[1024];
                int len = 0;

                len = input.read(buffer);
                if (len != -1) {
                    stream.write(buffer, 0, len);
                }
                stream.flush();
            }
            return stream.toByteArray();
        }
        return null;
    }

//    public String readString1() {
//        if (socket != null) {
//            try {
//                InputStream input = socket.getInputStream();
//                if (input != null) {
//                    BufferedInputStream bis = new BufferedInputStream(input);
//                    int len = -1;
//                    byte[] buffer = new byte[1];
//                    StringBuffer sb = new StringBuffer();
//                    while ((len = bis.read(buffer)) != -1) {
//                        sb.append(new String(buffer, 0, len));
//                    }
//                    return sb.toString();
//                }
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return null;
//    }

    /**
     * 获取一行消息（以/r,/n,/r/n结尾为一行,若服务端发送的消息不以上述标识结尾，则接收不到）
     *
     * @return
     * @throws IOException
     */
    public String readLine() throws IOException {
        if (socket != null) {
            InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input, CHAR_SET));
            return reader.readLine();
        }
        return null;
    }


    public void closeSocket() {
        if (output != null) {
            try {
                output.close();
                output = null;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (writer != null) {
            try {
                writer.close();
                writer = null;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            if (socket != null) {
                socket.close();
                socket = null;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
