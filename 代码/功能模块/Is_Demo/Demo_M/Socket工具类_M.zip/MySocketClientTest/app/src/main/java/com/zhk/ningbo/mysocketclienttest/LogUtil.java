package com.zhk.ningbo.mysocketclienttest;

import android.util.Log;

public class LogUtil {
    public static boolean isDebug = BuildConfig.DEBUG; //是否是调试状态
    public static String defulatTAG = "defulatTAG";

    public static void error(String tag, String msg) {
        if (isDebug)
            Log.e(tag, msg);
    }

    public static void warn(String tag, String msg) {
        if (isDebug)
            Log.w(tag, msg);
    }

    public static void warn(String tag, String msg, Throwable tr) {
        if (isDebug)
            Log.w(tag, msg, tr);
    }

    public static void info(String tag, String msg) {
        if (isDebug)
            Log.i(tag, msg);
    }

    public static void debug(String tag, String msg) {
        if (isDebug)
            Log.d(tag, msg);
    }

    public static void verbose(String tag, String msg) {
        if (isDebug)
            Log.v(tag, msg);
    }

    //------------------default tag ---------------------------//

    public static void e(String msg) {
        LogUtil.error(defulatTAG, msg);
    }

    public static void w(String msg) {
        LogUtil.warn(defulatTAG, msg);
    }

    public static void w(String msg, Throwable tr) {
        LogUtil.warn(defulatTAG, msg, tr);
    }

    public static void i(String msg) {
        LogUtil.info(defulatTAG, msg);
    }

    public static void d(String msg) {
        LogUtil.debug(defulatTAG, msg);
    }

    public static void v(String msg) {
        LogUtil.verbose(defulatTAG, msg);
    }

    //-------------------- subTAG --------------------------------//

    private static String getFinalTAG(String defulatTAG, String subTAG) {
        return defulatTAG + "-" + subTAG;
    }

    public static void e(String subTAG, String msg) {
        LogUtil.error(getFinalTAG(defulatTAG, subTAG), msg);
    }

    public static void w(String subTAG, String msg) {
        LogUtil.warn(getFinalTAG(defulatTAG, subTAG), msg);
    }

    public static void w(String subTAG, String msg, Throwable tr) {
        LogUtil.warn(getFinalTAG(defulatTAG, subTAG), msg);
    }

    public static void i(String subTAG, String msg) {
        LogUtil.info(getFinalTAG(defulatTAG, subTAG), msg);
    }

    public static void d(String subTAG, String msg) {
        LogUtil.debug(getFinalTAG(defulatTAG, subTAG), msg);
    }

    public static void v(String subTAG, String msg) {
        LogUtil.verbose(getFinalTAG(defulatTAG, subTAG), msg);
    }
}