package com.zhk.myexceptiontest;

import android.app.Application;

/**
 * 若使用CrashHandler记录异常，则需将你的Application继承BaseApplication
 * Description
 * Created by chenqiao on 2015/9/21.
 */
public abstract class BaseApplication extends Application {

    private static final boolean USE_CRASH = true; //是否记录异常
    protected CrashHandler crashHandler;

    @Override
    public void onCreate() {
        super.onCreate();
        /**
         * 设置默认异常处理Handler
         */

        //-------------需要 读写权限 ---------------- <<<<<<<<<<<<<
        if (USE_CRASH) {
            crashHandler = CrashHandler.getInstance();
            crashHandler.init(getApplicationContext());
        }

        onBaseCreate();
    }

    protected abstract void onBaseCreate();
}
