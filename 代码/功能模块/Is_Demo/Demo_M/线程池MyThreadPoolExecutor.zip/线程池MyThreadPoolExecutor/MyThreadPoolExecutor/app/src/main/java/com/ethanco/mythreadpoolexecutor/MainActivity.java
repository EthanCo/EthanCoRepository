package com.ethanco.mythreadpoolexecutor;

import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {

    private Button btnExcute;
    private ThreadPoolExecutor executor;
    private ExecutorService executorService;
    private ProgressBar progressbar1;
    private ProgressBar progressbar2;
    private ProgressBar progressbar3;
    private ProgressBar progressbar4;
    private ProgressBar progressbar5;
    private ProgressBar progressbar6;
    private ProgressBar progressbar7;
    private ProgressBar progressbar8;
    private ProgressBar progressbar9;
    private ProgressBar progressbar10;
    private ArrayList<ProgressBar> progressBarList;

    private static final int CPU_COUNT = Runtime.getRuntime().availableProcessors();
    private static final int CORE_POOL_SIEZE = CPU_COUNT + 1;
    private static final int MAXIMUM_POOL_SIZE = CPU_COUNT * 2 + 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
        initVar();
        initEvent();
    }

    private int i = -1;

    private void initEvent() {

        btnExcute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i = -1;
                for (int j = 0; j < progressBarList.size(); j++) {
                    executor.execute(runnable);
//                    executorService.execute(runnable);
                }
            }
        });
    }

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            i++;
            if (i > progressBarList.size()) {
                i = 0;
            }
            ProgressBar progressBar = progressBarList.get(i);
            int progress = 0;
//                while(true){ //线程不要是永久运行的，要不然后面的线程就运行不了了
            while (progress < 100) {
                progress += 10;
                progressBar.setProgress(progress);
                SystemClock.sleep(300);
            }
        }
    };

    private final AtomicInteger mCount = new AtomicInteger(1);

    private void initVar() {
        executor = new ThreadPoolExecutor(CORE_POOL_SIEZE, MAXIMUM_POOL_SIZE, 60, TimeUnit.SECONDS, new LinkedBlockingDeque<Runnable>(128), new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                return new Thread(r, "AsyncTask#" + mCount.getAndIncrement());
            }
        });

//        executorService = Executors.newFixedThreadPool(3); //只有核心线程，线程数量固定，不销毁，能更快地相应外界的请求

//        executorService = Executors.newCachedThreadPool(); //只有非核心线程，线程数不定，超过60秒闲置线程就会回收，适合执行大量的耗时较少的任务

//        executorService = Executors.newScheduledThreadPool(2); //创建一个定长的线程池，而且支持定时的以及周期性的任务执行，类似于Timer

//        executorService = Executors.newSingleThreadExecutor(); //内部只有一个核心线程，确保所有的任务都在一个线程中按顺序执行

        progressBarList = new ArrayList<>();
        progressBarList.add(progressbar1);
        progressBarList.add(progressbar2);
        progressBarList.add(progressbar3);
        progressBarList.add(progressbar4);
        progressBarList.add(progressbar5);
        progressBarList.add(progressbar6);
        progressBarList.add(progressbar7);
        progressBarList.add(progressbar8);
        progressBarList.add(progressbar9);
        progressBarList.add(progressbar10);
    }

    private void initView() {
        btnExcute = (Button) findViewById(R.id.btnExcute);
        progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
        progressbar2 = (ProgressBar) findViewById(R.id.progressbar2);
        progressbar3 = (ProgressBar) findViewById(R.id.progressbar3);
        progressbar4 = (ProgressBar) findViewById(R.id.progressbar4);
        progressbar5 = (ProgressBar) findViewById(R.id.progressbar5);
        progressbar6 = (ProgressBar) findViewById(R.id.progressbar6);
        progressbar7 = (ProgressBar) findViewById(R.id.progressbar7);
        progressbar8 = (ProgressBar) findViewById(R.id.progressbar8);
        progressbar9 = (ProgressBar) findViewById(R.id.progressbar9);
        progressbar10 = (ProgressBar) findViewById(R.id.progressbar10);
    }
}
