package cn.nbhope.permissionhandler;

import android.Manifest;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.tbruyelle.rxpermissions.RxPermissions;

import cn.nbhope.permissionhandler.databinding.ActivityMainBinding;
import cn.nbhope.permissionhandler.databinding.ActivityPermissionHandlerBinding;

public class RxPermissionTestActivity extends AppCompatActivity {

    private ActivityPermissionHandlerBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_permission_handler);
        setTitle(getClass().getSimpleName());

        binding.btnCallPhone.setOnClickListener(v -> callPhone());
    }

    private void callPhone() {
        RxPermissions.getInstance(this)
                .request(Manifest.permission.CALL_PHONE)
                .subscribe(granted -> {
                    if (granted) { // Always true pre-M
                        //授权成功
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        Uri data = Uri.parse("tel:" + "10010");
                        intent.setData(data);
                        startActivity(intent);
                    } else {
                        // Oups permission denied
                        Toast.makeText(getApplicationContext(), "权限被取消", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
