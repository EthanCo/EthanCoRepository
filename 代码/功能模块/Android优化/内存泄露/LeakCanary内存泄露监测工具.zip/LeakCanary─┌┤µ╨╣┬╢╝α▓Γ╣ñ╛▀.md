# LeakCanary的使用 #
###[中文文档](http://www.liaohuqiu.net/cn/posts/leak-canary-read-me/)

## 在build.gradle(module)中添加依赖 ##
	//在debug版本提示通知，可以查看LeakCanary的信息，
    debugCompile 'com.squareup.leakcanary:leakcanary-android:1.3' 
	//在release版本中，是不希望用户看到的
    releaseCompile 'com.squareup.leakcanary:leakcanary-android-no-op:1.3' 

## 在Application的oncreate中 ##
	
    @Override
    public void onCreate() {
        super.onCreate();
        LeakCanary.install(this);
    }

##即可使用
> 注意第一次启动的时候，需要手动点击Leaks(在桌面上)程序启动它

- 默认情况下LeakCanary只检测Activity的内存泄露，若要检测其他的内存泄露，需要自己配置