package com.ethanco.leakcanarytest;

import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /**
         *这是个Activity中的匿名内部类，因此它隐式的持有一个外部类对象，也就是MainActivity，
         * 如果MainActivity执行完毕前就销毁了，这个Activity就发生了泄露。
         */
        new Thread() {
            @Override
            public void run() {
                SystemClock.sleep(20000);
            }
        }.start();
    }
}

