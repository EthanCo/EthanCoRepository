import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import com.google.gson.Gson;


public class CopyOfTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String path = "http://192.168.20.2/DeviceServer/Index.ashx";
		try {
			URL url = new URL(path);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
			conn.setConnectTimeout(5000);//���ӳ�ʱ
			conn.setReadTimeout(5000);//��ȡ��ʱ
			
			Gson gson = new Gson();
			RequestMessage req = new RequestMessage("adam4150", "oper", "ondo1");
			//RequestMessage req = new RequestMessage("zigbee", "getdata", "");
			//RequestMessage req = new RequestMessage("led", "oper", "xxx");
			String jsonStr = gson.toJson(req);
			
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Content-Length",jsonStr.length()+"");
			conn.setDoOutput(true);
			
			conn.getOutputStream().write(jsonStr.getBytes());
			if (conn.getResponseCode()==200) {
				InputStream is = conn.getInputStream();
				InputStreamReader sr = new  InputStreamReader(is,"UTF-8"); //���ñ���
				BufferedReader br = new BufferedReader(sr);
				String str ="";
				String temp = "";
				while((temp=br.readLine())!=null){
					str +=temp;
				}
				System.out.println(str);
			}else {
				System.out.println("responseCode Error");
			}
		} catch (IOException e) {
			System.out.println("Exception:"+e.getMessage());
		}
	}
}
