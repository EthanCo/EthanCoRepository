
public class RequestMessage {
	
	public RequestMessage(String device,String op,String param) {
		this.op = op;
		this.device = device;
		this.param = param;
	}
	
	private String op;
	private String device;
	private String param;
}
