
public class Test3 {

	public static void main(String[] args) {
		boolean res = Boolean.parseBoolean("True");
		System.out.println(""+res);
	}
}
