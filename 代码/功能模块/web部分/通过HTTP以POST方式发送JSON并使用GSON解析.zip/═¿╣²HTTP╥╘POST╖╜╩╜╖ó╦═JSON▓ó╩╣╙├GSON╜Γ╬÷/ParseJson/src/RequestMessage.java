
public class RequestMessage {
	
	public RequestMessage(String Device,String Op,String Obj) {
		this.Op = Op;
		this.Device = Device;
		this.Obj = Obj;
	}
	
	private String Op;
	private String Device;
	private String Obj;
}
