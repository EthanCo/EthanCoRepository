import java.util.HashMap;


public class ResponseMessage {
		private String ErrorInfo;

		public String getErrorInfo() {
			return ErrorInfo;
		}

		public void setErrorInfo(String errorInfo) {
			ErrorInfo = errorInfo;
		}
		
		private boolean isSuccess;

		public boolean isSuccess() {
			return isSuccess;
		}

		public void setSuccess(boolean isSuccess) {
			this.isSuccess = isSuccess;
		}
		
		private HashMap<String, String> Model;

		public HashMap<String, String> getModel() {
			return Model;
		}

		public void setModel(HashMap<String, String> model) {
			Model = model;
		}
}
