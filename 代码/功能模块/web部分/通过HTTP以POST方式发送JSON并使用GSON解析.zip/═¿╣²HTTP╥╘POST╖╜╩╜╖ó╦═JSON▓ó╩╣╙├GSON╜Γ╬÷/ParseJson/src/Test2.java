import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import com.google.gson.Gson;


public class Test2 {

	/**
	 * @param args
	 * @throws UnsupportedEncodingException 
	 */
	public static void main(String[] args) throws UnsupportedEncodingException {
		String str ="{\"IsSuccess\":false,\"Model\":{},\"ErrorInfo\":\"����ʽ����������ʽ����\"}";
		
		byte[] bytes = str.getBytes("UTF-8");
		str = new String(bytes,"GBK");
		
		System.out.println(str);
		
		Gson gson = new Gson();
		ResponseMessage res = gson.fromJson(str, ResponseMessage.class);
		System.out.println(res.isSuccess()+res.getErrorInfo());
		HashMap<String,String> model = res.getModel();
		System.out.println("temper"+model.get("temper")+"humi"+model.get("humi")+"light"+model.get("light"));
	}
}
