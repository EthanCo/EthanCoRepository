package com.zhk.stumanager;

import java.io.InputStream;
import java.util.ArrayList;

import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class LoginActivity extends Activity {

	private Spinner spinner;
	private ArrayAdapter<String> adapter;
	private static final String[] m = { "ѧ��", "��ʦ", "����Ա" };
	private ProgressDialog progressDialog;
	private MyData myData;
	private ArrayList<String> keyList = new ArrayList<String>();
	private ArrayList<String> valueList = new ArrayList<String>();
	private EditText etId;
	private EditText etPwd;
	private EditText etUrl;
	private String identity=m[0];

	private Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MyData.SUCCESS:
				myData.setIdentity(identity);
				myData.setUserId(etId.getText().toString());
				Intent intent = new Intent(LoginActivity.this,MainActivity.class);
				 startActivity(intent);
				 finish();
				break;
			case MyData.FAILE:
				Toast.makeText(getApplicationContext(), "�˺Ż���������ݲ���ȷ",
						Toast.LENGTH_SHORT).show();
				break;
			case MyData.FAILE_ERROR:
				Toast.makeText(getApplicationContext(), "���������Ƿ�����",
						Toast.LENGTH_SHORT).show();
				break;
			default:
				break;
			}
			progressDialog.dismiss();
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// ʹ���Զ��������
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_login);
		// ʹ�ò����ļ������������
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.title);
		
		Button btTitleLeft = (Button)findViewById(R.id.btTitleLeft);
		TextView title = (TextView)findViewById(R.id.title);
		ImageButton btTitleRight =(ImageButton)findViewById(R.id.btTitleRight);
		
		title.setText("��½");
		btTitleLeft.setVisibility(View.GONE);
		btTitleRight.setVisibility(View.GONE);
		
		spinner = (Spinner) findViewById(R.id.Spinner01);
		// ����ѡ������ArrayAdapter��������
		adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, m);
		// ���������б��ķ��
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// ��adapter ���ӵ�spinner��
		spinner.setAdapter(adapter);
		// �����¼�Spinner�¼�����
		spinner.setOnItemSelectedListener(new SpinnerSelectedListener());

		myData = (MyData) getApplication();

		etId = (EditText) findViewById(R.id.etUserId);
		etPwd = (EditText) findViewById(R.id.etPwd);
		etUrl = (EditText) findViewById(R.id.etUrl);
		Button btLogin = (Button) findViewById(R.id.btLogin);
		btLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String id = etId.getText().toString();
				String pwd = etPwd.getText().toString();
				if (id.equals("") || pwd.equals("")) {
					Toast.makeText(getApplicationContext(), "�˺Ż����벻Ϊ��",
							Toast.LENGTH_SHORT).show();
				} else {
					progressDialog = ProgressDialog.show(LoginActivity.this,
							"���ڴ���", "���Եȡ���");
					myData.setUrl(etUrl.getText().toString());
					keyList.clear();
					valueList.clear();
					keyList.add("id");
					valueList.add(id);
					keyList.add("pwd");
					valueList.add(pwd);
					keyList.add("identity");
					valueList.add(identity);
					new Thread() {
						public void run() {
							try {
								Thread.sleep(800); // ģ�����
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							HttpConnSoap soap = new HttpConnSoap();
							InputStream in = soap.GetWebServre(
									myData.getUrlParams(), "verifyPwd",
									keyList, valueList);
							xmlParser xParser = new xmlParser();
							Message msg = new Message();
							try {
								if (xParser.verifyPwd(in)) {
									msg.what = MyData.SUCCESS;
								} else {
									msg.what = MyData.FAILE;
								}
							} catch (Exception e) {
								msg.what = MyData.FAILE_ERROR;
							} finally {
								handler.sendMessage(msg);
							}
						}
					}.start();;
				}
			}
		});
	}

	// ʹ��������ʽ����
	class SpinnerSelectedListener implements OnItemSelectedListener {

		public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			identity = m[arg2];
		}

		public void onNothingSelected(AdapterView<?> arg0) {
		}
	}
}
