package com.zhk.myclass;


public class ClassStudent extends ClassUser {

	
    //�����Ƿ��ܲ�
    private boolean achieveFlag;

    //�༶
    private String stuClass;

    //ϵ��
    private String department;

    //�ܲٴ���
    private int exerciseTimes;
	
	public ClassStudent() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ClassStudent(String id, String name, int age, String sex,
			String stuClass, String department, String picture, String blockId,
			int exerciseTimes, Boolean ActivityFlag) {
		super(id, name, age, sex, picture, blockId);
		this.stuClass = stuClass;
		this.department = department;
		this.exerciseTimes = exerciseTimes;
		this.achieveFlag = ActivityFlag;
	}

	@Override
	public String toString() {
		return "ClassStudent [achieveFlag=" + achieveFlag + ", stuClass="
				+ stuClass + ", department=" + department + ", exerciseTimes="
				+ exerciseTimes + "]";
	}

	public boolean isAchieveFlag() {
		return achieveFlag;
	}

	public void setAchieveFlag(boolean achieveFlag) {
		this.achieveFlag = achieveFlag;
	}

	public String getStuClass() {
		return stuClass;
	}

	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getExerciseTimes() {
		return exerciseTimes;
	}

	public void setExerciseTimes(int exerciseTimes) {
		this.exerciseTimes = exerciseTimes;
	}

}
