package com.zhk.stumanager;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.zhk.myclass.ClassStudent;

import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class AllStuActivity extends Activity {
	private boolean finish = true;// �Ƿ�������
	// private boolean isBottom=false;//�Ƿ���������
	private int countPage = 5;// ���ص���ҳ��
	private int pageSize = 8;// ÿҳ����8������
	private ArrayList<String> keyList = new ArrayList<String>();
	private ArrayList<String> valueList = new ArrayList<String>();
	private MyData myData;
	private List<ClassStudent> totalStuList = new ArrayList<ClassStudent>();
	private ListView lvAllStu;
	private ProgressDialog progressDialog;
	private View footer; // ҳ��
	private MyListAdapter adapter;

	private Handler handler = new Handler() {

		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case MyData.SUCCESS:
				List<ClassStudent> stuList = (List<ClassStudent>) msg.obj;

				totalStuList.addAll(stuList);
				footer = View.inflate(getApplicationContext(), R.layout.footer,
						null); // ���ҳ��
				lvAllStu.addFooterView(footer); // ����ҳ�� listview�ڲ�����
												// ����Ҫ�ȼ���footer
				adapter = new MyListAdapter();
				lvAllStu.setAdapter(adapter);
				lvAllStu.removeFooterView(footer);// ��Ϊ����Ҫһ��ʼ����ʾҳ��,�����Ƴ�

				lvAllStu.setOnItemClickListener(new MyOnItemClickListener());
				lvAllStu.setOnScrollListener(new MyOnScrollListener());
				break;
			case MyData.FAILE:
				Toast.makeText(getApplicationContext(), "����",
						Toast.LENGTH_SHORT).show();
				break;
			default:
				break;
			case MyData.SUCCESSNEXT:
				List<ClassStudent> stuList2 = (List<ClassStudent>) msg.obj;
				int count = stuList2.size();
				if (count == pageSize) {
					totalStuList.addAll(stuList2);
					finish = true;
					break;
				} else if (count < pageSize && count > 0) {
					totalStuList.addAll(stuList2);
				} else {
					Toast.makeText(getApplicationContext(), "����", 1).show();
				}
				if (lvAllStu.getFooterViewsCount() > 0) {
					adapter.notifyDataSetChanged();// ��listview�Զ�ˢ��
				}
			}
			progressDialog.dismiss();
			lvAllStu.removeFooterView(footer);
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// ʹ���Զ��������
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_allstu);
		// ʹ�ò����ļ������������
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.title);
		
		Button btTitleLeft = (Button)findViewById(R.id.btTitleLeft);
		TextView title = (TextView)findViewById(R.id.title);
		ImageButton btTitleRight =(ImageButton)findViewById(R.id.btTitleRight);
		
		title.setText("�鿴����ѧ��");

		
		btTitleLeft.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		
		btTitleRight.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "��������ð�ť", Toast.LENGTH_SHORT).show();
			}
		});
		
		lvAllStu = (ListView) findViewById(R.id.lvAllStu);
		myData = (MyData) getApplication();

		progressDialogShow();
		new Thread() {
			public void run() {
				HttpConnSoap soap = new HttpConnSoap();
				keyList.clear();
				valueList.clear();
				keyList.add("size");
				valueList.add(String.valueOf(pageSize));
				keyList.add("num");
				valueList.add("1");
				InputStream in = soap.GetWebServre(myData.getUrlParams(),
						"selectAllStus", keyList, valueList);
				xmlParser xParser = new xmlParser();
				List<ClassStudent> stuList;
				Message msg = new Message();
				try {
					stuList = xParser.getStuList(in);
					msg.what = MyData.SUCCESS;
					msg.obj = stuList;
				} catch (Exception e) {
					e.printStackTrace();
					msg.what = MyData.FAILE;
				} finally {
					handler.sendMessage(msg);
				}
			}
		}.start();
	}

	private void progressDialogShow() {
		progressDialog = ProgressDialog.show(AllStuActivity.this, "���ڴ���",
				"���Եȡ���");
	}

	private class MyOnItemClickListener implements OnItemClickListener {
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			ClassStudent stu = (ClassStudent) parent
					.getItemAtPosition(position);
			MyBundle mBndle = new MyBundle();
			Intent intent = new Intent(AllStuActivity.this, AStuActivity.class);
			Bundle bundle = mBndle.setStuBundle(stu);
			intent.putExtras(bundle);
			startActivity(intent);
		}
	}

	private class MyListAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return totalStuList.size();
		}

		@Override
		public Object getItem(int position) {
			return totalStuList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View item = View.inflate(getApplicationContext(),
					R.layout.allstu_item, null);
			TextView tvId = (TextView) item.findViewById(R.id.tvIdAllStu);
			TextView tvName = (TextView) item.findViewById(R.id.tvNameAllStu);
			TextView tvExerciseTimes = (TextView) item
					.findViewById(R.id.tv3AllStu);

			ClassStudent stu = totalStuList.get(position);
			tvId.setText(stu.getId());
			tvName.setText(stu.getName());
			tvExerciseTimes.setText(stu.getExerciseTimes() + "");
			return item;
		}
	}

	public class MyOnScrollListener implements OnScrollListener {

		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem,
				int visibleItemCount, int totalItemCount) {
			final int totalCount = firstVisibleItem + visibleItemCount; // ����=��Ļ��ʾ�ĵ�һ���id+��ʾ��item��
			int currentPage = totalCount / pageSize;// ��ǰҳ
			final int nextPage = currentPage + 1;// ��һҳ
			if (totalCount == totalItemCount && nextPage <= countPage && finish) {// �Ѿ��ƶ�����listview�����
				finish = false;
				lvAllStu.addFooterView(footer);
				new Thread() {
					public void run() {
						try {
							Thread.sleep(1500); // ģ��������ȡ����
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						keyList.clear();
						valueList.clear();
						keyList.add("size");
						valueList.add(String.valueOf(pageSize));
						keyList.add("num");
						valueList.add(String.valueOf(nextPage + 1));
						HttpConnSoap soap = new HttpConnSoap();
						InputStream in = soap.GetWebServre(
								myData.getUrlParams(), "selectAllStus",
								keyList, valueList);
						xmlParser xParser = new xmlParser();
						List<ClassStudent> stuList;
						Message msg = new Message();
						try {
							stuList = xParser.getStuList(in);
							msg.what = MyData.SUCCESSNEXT;
							msg.obj = stuList;
						} catch (Exception e) {
							e.printStackTrace();
							msg.what = MyData.FAILE;
						} finally {
							handler.sendMessage(msg);
						}
					}
				}.start();
			}
		}
	}
}
