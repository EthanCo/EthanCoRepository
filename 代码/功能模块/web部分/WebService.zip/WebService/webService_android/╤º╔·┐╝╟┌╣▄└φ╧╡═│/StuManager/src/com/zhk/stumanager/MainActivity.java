package com.zhk.stumanager;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.zhk.myclass.ClassStudent;

import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class MainActivity extends Activity {

    private EditText etUserId;
    private ProgressDialog progressDialog;  
    private MyData myData;
	private ArrayList<String> keyList = new ArrayList<String>();
	private ArrayList<String> valueList = new ArrayList<String>();
	private long mExitTime;
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case MyData.SUCCESS:
				List<ClassStudent> stuList = (List<ClassStudent>)msg.obj;
				if(stuList.size()==1){
					ClassStudent stu = stuList.get(0);
					Intent intent = new Intent(MainActivity.this,AStuActivity.class);
					MyBundle mBundle = new MyBundle();
					Bundle bundle =mBundle.setStuBundle(stu);
					intent.putExtras(bundle);
					startActivity(intent);
				}else if(stuList.size()==0){
					Toast.makeText(getApplicationContext(), "��ѧ��������",Toast.LENGTH_SHORT).show();
				}else{
					Toast.makeText(getApplicationContext(), "����",Toast.LENGTH_SHORT).show();
				}
				break;
			case MyData.FAILE:
				Toast.makeText(getApplicationContext(), "���������Ƿ�����", Toast.LENGTH_SHORT).show();
				break;
			default:
				break;
			}
			progressDialog.dismiss();
		};
	};
	@Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        
		// ʹ���Զ��������
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.activity_main);
		// ʹ�ò����ļ������������
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.title);
		
		Button btTitleLeft = (Button)findViewById(R.id.btTitleLeft);
		TextView title = (TextView)findViewById(R.id.title);
		ImageButton btTitleRight =(ImageButton)findViewById(R.id.btTitleRight);
		
		title.setText("������");
		btTitleLeft.setVisibility(View.GONE);
		btTitleRight.setVisibility(View.GONE);
        
        etUserId = (EditText)findViewById(R.id.etUserIdMain);
        Button btAllStu = (Button)findViewById(R.id.btAllStu);
        Button btAStu = (Button)findViewById(R.id.btAStu);
        
        myData = (MyData)getApplication();
        if(myData.getIdentity().equals("ѧ��")){
        	btAllStu.setVisibility(View.GONE);
        	etUserId.setText(myData.getUserId());
        	etUserId.setVisibility(View.GONE);
        	btAStu.setText("�鿴��ϸ��Ϣ");
        }
        
        btAllStu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent=new Intent(MainActivity.this,AllStuActivity.class);
				startActivity(intent);
			}
		});
        
        btAStu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {

				
				String id = etUserId.getText().toString();
				if(id.equals("")){
					Toast.makeText(getApplicationContext(), "������ѧ��", Toast.LENGTH_SHORT).show();
				}else{
//					progressDialog=new ProgressDialog(MainActivity.this);
//					progressDialog.setTitle("title");
//					progressDialog.setMessage("message");
//					progressDialog.show();
					progressDialog=ProgressDialog.show(MainActivity.this, "���ڴ���", "���Եȡ���");
					keyList.clear();
					valueList.clear();
					keyList.add("id");
					valueList.add(id);
					
					new Thread(){
						public void run(){
							HttpConnSoap soap = new HttpConnSoap();
							try {
								Thread.sleep(1500); //ģ������
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							InputStream in =soap.GetWebServre(myData.getUrlParams(),"selectStu", keyList, valueList);
							xmlParser xParser = new xmlParser();
							List<ClassStudent> stuList;
							Message msg = new Message();
							try {
								stuList=xParser.getStuList(in);
								msg.what=MyData.SUCCESS;
								msg.obj=stuList;
							} catch (Exception e) {
								msg.what=MyData.FAILE;
							}finally{
								handler.sendMessage(msg);
							}
						}
					}.start();		
				}
			}
		});
    }
	
	//���η��ؼ��˳�
	public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
                if ((System.currentTimeMillis() - mExitTime) > 2000) {
                        Object mHelperUtils;
                        Toast.makeText(this, "�ٰ�һ���˳�����", Toast.LENGTH_SHORT).show();
                        mExitTime = System.currentTimeMillis();

                } else {
                        finish();
                }
                return true;
        }
        return super.onKeyDown(keyCode, event);
}
}
