package com.zhk.stumanager;

import android.app.Application;

public class MyData extends Application {
	public final static int SUCCESS=1;
	public final static int FAILE=0;
	public final static int SUCCESSNEXT=2;
	public final static int FAILE_ERROR=-1;
	private String userId;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	private String identity;
	private String url;
	private String urlParams;
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
		this.urlParams=url+"Service1.asmx";
	}
	public String getUrlParams() {
		return urlParams;
	}
	public void setUrlParams(String urlParams) {
		this.urlParams = urlParams;
	}
}
