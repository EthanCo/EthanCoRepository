package com.zhk.stumanager;

import com.zhk.myclass.ClassStudent;

import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class AStuActivity extends Activity {

	private MyData myData;
	private ProgressDialog progressDialog;
	private Handler handler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case MyData.SUCCESS:
				Bitmap bitmap = (Bitmap)msg.obj;
				image.setImageBitmap(bitmap);
				break;
			}
			progressDialog.dismiss();
		}
	};

	private ImageView image;    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
		// ʹ���Զ��������
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_astu);
		// ʹ�ò����ļ������������
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.title);
		
		Button btTitleLeft = (Button)findViewById(R.id.btTitleLeft);
		TextView title = (TextView)findViewById(R.id.title);
		ImageButton btTitleRight =(ImageButton)findViewById(R.id.btTitleRight);
		
		title.setText("�鿴ָ��ѧ��");

		
		btTitleLeft.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		
		btTitleRight.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "��������ð�ť", Toast.LENGTH_SHORT).show();
			}
		});
        
        //��ȡ�ؼ�
        TextView etName = (TextView)findViewById(R.id.tvNameAStu);
        TextView etAge = (TextView)findViewById(R.id.tvAgeAStu);
        TextView etDepartment = (TextView)findViewById(R.id.tvDepartmentAStu);
        TextView etExerciseTimes = (TextView)findViewById(R.id.tvExerciseTimesAStu);
        TextView etSex = (TextView)findViewById(R.id.tvSexAStu);
        TextView etActivityFlag = (TextView)findViewById(R.id.tvActivityFlagAStu);
        TextView etStuClass = (TextView)findViewById(R.id.tvStuClassAStu);
        image =(ImageView)findViewById(R.id.imageAStu);
        
        //��ȡ���ݵ�ֵ
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        MyBundle mBundle = new MyBundle();
        ClassStudent stu = new ClassStudent();
        stu=mBundle.getStu(bundle);
        
        //����ֵ
        etName.setText(stu.getName());
        etAge.setText(String.valueOf(stu.getAge()));
        etSex.setText(stu.getSex());
        etStuClass.setText(stu.getStuClass());
        etExerciseTimes.setText(String.valueOf(stu.getExerciseTimes()));
        etDepartment.setText(stu.getDepartment());
        if(stu.isAchieveFlag()){
        	etActivityFlag.setText("��");
        }else{
        	etActivityFlag.setText("��");
        }
        
        //��ȡȫ�ֱ���
        myData=(MyData)getApplication();
        final String picture ="picture/"+stu.getPicture();
        
        //����ͼƬ
        progressDialog=ProgressDialog.show(AStuActivity.this, "���ڴ���", "���Ե�");
        new Thread(){
        	public void run(){
        		try {
					Thread.sleep(800);//ģ������
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                String path = myData.getUrl()+picture;
                httpHelper hHelper = new httpHelper();
                Bitmap bitmap = hHelper.getPic(path, AStuActivity.this);
                Message msg = new Message();
                msg.what=MyData.SUCCESS;
                msg.obj=bitmap;
                handler.sendMessage(msg);
        	}
        }.start();
    }
}
