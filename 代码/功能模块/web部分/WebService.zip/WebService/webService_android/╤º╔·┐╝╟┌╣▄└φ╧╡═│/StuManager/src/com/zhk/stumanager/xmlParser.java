package com.zhk.stumanager;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import com.zhk.myclass.ClassStudent;

import android.util.Xml;

public class xmlParser {

	public List<ClassStudent> getStuList(InputStream in) throws Exception {
		XmlPullParser parser = Xml.newPullParser(); // ��ý�����
		parser.setInput(in, "UTF-8"); // ������������ָ�����
		ArrayList<ClassStudent> stuLList = new ArrayList<ClassStudent>();
		ClassStudent p = null;
		for (int type = parser.getEventType(); type != XmlPullParser.END_DOCUMENT; type = parser
				.next()) {
			if (type == XmlPullParser.START_TAG) { // ��������˱�ǩ��ʼ�¼�
				if (parser.getName().equals("ClassStudent")) { // �����ǩ��ΪClassStudent
					p = new ClassStudent();
					stuLList.add(p); // װ�뼯��
				} else if (parser.getName().equals("Picture")) {
					p.setPicture(parser.nextText());
				}else if(parser.getName().equals("Id")){
					p.setId(parser.nextText());
				}else if (parser.getName().equals("Age")) {
					p.setAge(Integer.parseInt(parser.nextText()));
				} else if (parser.getName().equals("Name")) {
					p.setName(parser.nextText());
				} else if (parser.getName().equals("Sex")) {
					p.setSex(parser.nextText());
				} else if (parser.getName().equals("BlockId")) {
					p.setBlockId(parser.nextText());
				} else if (parser.getName().equals("AchieveFlag")) {
					p.setAchieveFlag(Boolean.getBoolean(parser.nextText()));
				} else if (parser.getName().equals("StuClass")) {
					p.setStuClass(parser.nextText());
				} else if (parser.getName().equals("Department")) {
					p.setDepartment(parser.nextText());
				} else if (parser.getName().equals("ExerciseTimes")) {
					p.setExerciseTimes(Integer.parseInt(parser.nextText()));
				}
			}
		}
		return stuLList;
	}

	/*
	 * ��½��֤ ���ص�����ʾ�� <?xml version="1.0" encoding="utf-8"?> <soap:Envelope
	 * xmlns:soap="http://...." xmlns:xsi="http://...."> <soap:Body>
	 * <verifyPwdResponse xmlns="http://....">
	 * <verifyPwdResult>true</verifyPwdResult> </verifyPwdResponse> </soap:Body>
	 * </soap:Envelope>
	 */
	public boolean verifyPwd(InputStream in) throws XmlPullParserException,
			IOException {
		XmlPullParser parser = Xml.newPullParser(); // ��ý�����
		parser.setInput(in, "UTF-8");// ����������,ָ������
		for (int type = parser.getEventType(); type != XmlPullParser.END_DOCUMENT; type = parser
				.next()) {
			if (type == XmlPullParser.START_TAG) {
				if (parser.getName().equals("verifyPwdResult")) {
					if (parser.nextText().equals("true")) {
						return true;
					}
					break;
				}
			}
		}
		return false;
	}
}
