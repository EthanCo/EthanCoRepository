package com.zhk.stumanager;

import com.zhk.myclass.ClassStudent;

import android.os.Bundle;

public class MyBundle {
	public Bundle setStuBundle(ClassStudent stu){
		Bundle bundle = new Bundle();
		bundle.putString("id",stu.getId());
		bundle.putString("name", stu.getName());
		bundle.putInt("age", stu.getAge());
		bundle.putString("sex",stu.getSex());
		bundle.putString("stuclass", stu.getStuClass());
		bundle.putString("department", stu.getDepartment());
		bundle.putString("pic", stu.getPicture());
		bundle.putInt("exerciseTimes", stu.getExerciseTimes());
		bundle.putBoolean("achieveFlag", stu.isAchieveFlag());
		return bundle;
	}
	
	public ClassStudent getStu(Bundle bundle){
		ClassStudent stu = new ClassStudent();
		stu.setId(bundle.getString("id"));
		stu.setName(bundle.getString("name"));
		stu.setAge(bundle.getInt("age"));
		stu.setSex(bundle.getString("sex"));
		stu.setStuClass(bundle.getString("stuclass"));
		stu.setDepartment(bundle.getString("department"));
		stu.setPicture(bundle.getString("pic"));
		stu.setExerciseTimes(bundle.getInt("exerciseTimes"));
		stu.setAchieveFlag(bundle.getBoolean("achieveFlag"));
		return stu;
	}
}
