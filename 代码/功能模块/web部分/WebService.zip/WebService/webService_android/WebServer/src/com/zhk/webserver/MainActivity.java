package com.zhk.webserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParserException;

import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;

public class MainActivity extends ActionBarActivity {
	private ArrayList<String> arrayList = new ArrayList<String>();
	private ArrayList<String> brrayList = new ArrayList<String>();
	private List<ClassStudent> stuList=null;
	HttpConnSoap soap = new HttpConnSoap();
	private String temp;
	private String str="";
	private TextView tv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		tv = (TextView)findViewById(R.id.tv);
//		
//		Button bt = (Button)findViewById(R.id.bt);
//		bt.setOnClickListener(new OnClickListener() {
//
//			private String tempstr;
//			private String str;
//
//			@Override
//			public void onClick(View v) {
//				arrayList.clear();
//				brrayList.clear();
//				arrayList.add("ClassName");
//				brrayList.add("������1331");
//				InputStream in = soap.GetWebServre("selectStusClass", arrayList, brrayList);
//				BufferedReader reader = new BufferedReader(new InputStreamReader(in));
//					}
//				try {
//					while((tempstr = reader.readLine())!=null)
//					{
//						str+=tempstr;
//					}
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				tv.setText(str);
//			}
//		});
	}
	
	public void myclick(View v)
	{	
		str="";
		stuList=null;
		arrayList.clear();
		brrayList.clear();
		arrayList.add("id");
		brrayList.add("51340142");
//		arrayList.add("num");
//		brrayList.add("2");
		InputStream in = soap.GetWebServre("selectStu", arrayList, brrayList);
		xmlParser xParser = new xmlParser();
		try {
			stuList = xParser.getStuList(in);
		} catch (Exception e) {
			e.printStackTrace();
		}
		for(int i=0;i<stuList.size();i++)
		{
			str+=stuList.get(i).name+" ";
		}
//		if(in==null){
//			Toast.makeText(MainActivity.this, "δ��ȡ����", 1).show();
//		}
//		else{
//			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
//			try {
//				while((temp=reader.readLine())!=null){
//					str+=temp;
//				}
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			tv.setText(str);
//		}
	}
	
	public void myclick2(View v)
	{
		arrayList.clear();
		brrayList.clear();
		arrayList.add("id");
		brrayList.add("51340142");
		arrayList.add("pwd");
		brrayList.add("1234567");
		arrayList.add("identity");
		brrayList.add("ѧ��");
		
		InputStream in = soap.GetWebServre("verifyPwd", arrayList, brrayList);
		xmlParser xParser = new xmlParser();
		try {
			if(xParser.verifyPwd(in))
			{
				tv.setText("true");
			}
			else{
				tv.setText("false");
			}
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		if(in==null){
//			Toast.makeText(MainActivity.this, "δ��ȡ����", 1).show();
//		} else {
//			BufferedReader reader = new BufferedReader(
//					new InputStreamReader(in));
//			try {
//				while ((temp = reader.readLine()) != null) {
//					str += temp;
//				}
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			tv.setText(str);
//		}
	}
}
