package com.zhk.webserver;

public class ClassUser extends AbstractClass {

	public ClassUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    public ClassUser(String id, String name, int age, String sex, String picture,String blockId)
    { 
    	super();
        this.id=id;
        this.name=name;
        this.age = age;
        this.sex=sex;
        this.picture = picture;
        this.blockId=blockId;
    }
	
}
