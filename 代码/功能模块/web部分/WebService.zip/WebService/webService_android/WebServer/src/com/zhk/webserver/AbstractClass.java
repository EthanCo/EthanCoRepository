package com.zhk.webserver;

abstract public class AbstractClass
{
    protected String picture;

    protected String id;

    protected String name;

	@Override
	public String toString() {
		return "AbstractClass [picture=" + picture + ", id=" + id + ", name="
				+ name + ", age=" + age + ", sex=" + sex + ", pwd=" + pwd
				+ ", blockId=" + blockId + "]";
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getBlockId() {
		return blockId;
	}

	public void setBlockId(String blockId) {
		this.blockId = blockId;
	}

	protected int age;

    protected String sex;

    protected String pwd;

    protected String blockId;
}
