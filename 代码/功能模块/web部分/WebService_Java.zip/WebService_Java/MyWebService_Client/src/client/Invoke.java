package client;

import zhk.Test;
import zhk.TestService;

public class Invoke {
	public static void main(String[] args){
		/*
		 * ��WSDL��
		 * <service name="TestService">
		 * */
		TestService testService = new TestService();
		
		/*
		 * ��WSDL��
		 * <port name="TestPort" binding="tns:TestPortBinding">
		 * */
		Test test = testService.getTestPort();
		//���ɵ��÷���˷���
		String res = test.say("yyy");
		System.out.println(res);
	}
}
