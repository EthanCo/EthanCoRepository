package com.zhk.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zhk.domain.Person;

public class parseService {

	// �ӷ�������ȡjosn����
	public List<Person> getPersonsFormJson(String path)
			throws NumberFormatException, IOException, JSONException {
		List<Person> pList = new ArrayList<Person>();
		URL url;
		url = new URL(path);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setConnectTimeout(5000);
		
		if (conn.getResponseCode() == 200) {
			InputStream is = conn.getInputStream();

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int len = 0;
			while ((len = is.read(buffer)) != -1) {
				bos.write(buffer);
			}
			String jsonStr = bos.toString();
			bos.close();
			is.close();// �ر���
			JSONArray jsonArray = new JSONArray(jsonStr); // android����json����
			for (int i = 0; i < jsonArray.length(); i++) {
				JSONObject jsonObject = jsonArray.getJSONObject(i);
				Person p = new Person();
				p.setName(jsonObject.getString("name"));
				p.setAge(Integer.parseInt(jsonObject.getString("age")));
				p.setContent(jsonObject.getString("content"));
				pList.add(p);
			}
			return pList;
		}
		return null;
	}
}
