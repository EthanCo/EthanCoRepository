package com.zhk.test;

import android.test.AndroidTestCase;
import android.util.Log;

public class test1 extends AndroidTestCase {
	public void test001(){
		System.out.println("1qq");
	}
}
