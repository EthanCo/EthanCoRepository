package com.zhk.json;

import java.io.IOException;
import java.util.List;

import org.json.JSONException;

import com.zhk.domain.Person;
import com.zhk.service.parseService;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends Activity {
	private final static int SUCCESS=1;
	private TextView tv1;
	private Handler mHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case SUCCESS:
				StringBuffer info = (StringBuffer)msg.obj;
				tv1.setText(info);
				break;

			default:
				break;
			}
		};
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		tv1 = (TextView) findViewById(R.id.tv1);
		new Thread() {
			public void run() {
				parseService service = new parseService();
				String path = getResources().getString(R.string.serverjsonurl);
				try {
					List<Person> pList = service.getPersonsFormJson(path);
					
					StringBuffer info =new StringBuffer();
					for (Person p : pList) {
						info.append(p.getName() +" - "+ p.getAge() +" - "+ p.getContent() + "\r\n");
					}
					Message msg = new Message();
					msg.what=SUCCESS;
					msg.obj=info;
					mHandler.sendMessage(msg);
				} catch (NumberFormatException e) {
					Log.i("log.i", "NumberFormatException");
					e.printStackTrace();
				} catch (IOException e) {
					Log.i("log.i", "IOException");
					e.printStackTrace();
				} catch (JSONException e) {
					Log.i("log.i", "JSONException");
					e.printStackTrace();
				}
			};
		}.start();
	}
}
