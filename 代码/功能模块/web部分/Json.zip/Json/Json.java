jION 数组 		格式：[{image:"httP://192.168.1.101:8080/web/a.jpg",title:"",content:"",count:""},{}] 

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HeaderNewsService service = new HeaderNewsService();
		List<HeaderNew> headerNews = service.getHeaderNews();// ctrl + 2  L 
		StringBuilder sb = new StringBuilder("[");
		for(HeaderNew headerNew:headerNews){
			sb.append("{");
			sb.append("image:").append("\"").append(headerNew.getImage()).append("\"").append(",");
			sb.append("title:").append("\"").append(headerNew.getTitle()).append("\"").append(",");
			sb.append("content:").append("\"").append(headerNew.getContent()).append("\"").append(",");
			sb.append("count:").append("\"").append(headerNew.getCount()).append("\"");
			sb.append("}");
			sb.append(",");
		}
		sb.deleteCharAt(sb.length() -1 );
		sb.append("]");
		
		request.setAttribute("json", sb.toString());
		request.getRequestDispatcher("WEB-INF/page/headernewsjson.jsp").forward(request, response);
	}