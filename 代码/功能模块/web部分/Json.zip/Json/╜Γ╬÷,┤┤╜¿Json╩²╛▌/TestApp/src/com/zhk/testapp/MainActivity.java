package com.zhk.testapp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Button btParse;
	private TextView tvInfo;
	private String jString ="{\"year\":\"2015\",\"people\":[{\"firstName\":\"Brett\",\"lastName\":\"McLaughlin\",\"email\":\"aaaa\"},{\"firstName\":\"Jason\",\"lastName\":\"Hunter\",\"email\":\"bbbb\"},{\"firstName\":\"Elliotte\",\"lastName\":\"Harold\",\"email\":\"cccc\"}]}";
	String newLine = System.getProperty("line.separator"); // ͳһ���з�
	private TextView tvJson;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initJson();
		initView();
		initEvent();
	}
//����Json����
	private void initJson() {
		try {
			JSONObject JObject = new JSONObject();
			JObject.put("year", "2015");
			JSONArray peoples = new JSONArray();
			for (int i = 0; i < 3; i++) {
				JSONObject people = new JSONObject();
				people.put("firstName", "Brett"+i);
				people.put("lastName", "McLaughlin"+i);
				people.put("email", "123@qq.com"+i);
				peoples.put(people);
			}
			JObject.put("peopels", peoples);
			Toast.makeText(getApplicationContext(), String.valueOf(JObject), Toast.LENGTH_SHORT).show();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	
	private void initEvent() {
		//����Json����
		btParse.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				try {
					// �����������{},�Ǵ���һ������
					JSONObject JObject = new JSONObject(jString);
					// ��һ����year��ֵ��String
					String year = JObject.getString("year");
					tvInfo.setText(year+newLine);
					// �ڶ�����person��ֵ������
					JSONArray personArray = JObject.getJSONArray("peoples");
					// person���������Ƕ���
					for (int i = 0; i < personArray.length(); i++) {
						JSONObject obj = personArray.getJSONObject(i);
						tvInfo.append(" " + obj.getString("firstName"));
						tvInfo.append(" " + obj.getString("lastName"));
						tvInfo.append(" " + obj.getString("email") + newLine);

						// long tempStr =obj.optLong("firstName");
						// //���������󷵻�ϵͳĬ��ֵ 0
						long tempStr = obj.optLong("firstName", 1000);// ����������,�����û�ָ����1000
						Toast.makeText(getApplicationContext(), tempStr + "", Toast.LENGTH_SHORT).show();
					}
				} catch (JSONException e1) {
					Toast.makeText(getApplicationContext(), e1.getMessage(), Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	private void initView() {
		btParse = (Button) findViewById(R.id.btParse);
		tvInfo = (TextView) findViewById(R.id.tvInfo);
	}
}
