package cn.itcast.servlet;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		String name = new String(request.getParameter("name").getBytes("iso-8859-1"),"utf-8");
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		
		System.out.println("name :" + name + ", password :" + password);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if(isMultipart){
			try {
				// Create a factory for disk-based file items
				FileItemFactory factory = new DiskFileItemFactory();

				// Create a new file upload handler
				ServletFileUpload upload = new ServletFileUpload(factory);

				// Parse the request
				List<FileItem> items = upload.parseRequest(request);
				
				
				String path = request.getSession().getServletContext().getRealPath("/files");
				File dir = new File(path);
				System.out.println(path);
				if(!dir.exists()){
					dir.mkdirs();
				}
				
				for(FileItem item:items){
					if(item.isFormField()){//�ı�
						String name = item.getFieldName();
						String value = item.getString();
						System.out.println(name + " = " + value);
					}else{//�ļ�
						String filename = item.getName();
						File file = new File(dir, getFilename(filename));
						item.write(file);
					}
				}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			doGet(request, response);
		}
	}

	
	//�õ��ļ�����
	private String getFilename(String filename){
		if(filename.contains("\\")){
		   return filename.substring(filename.lastIndexOf("\\")+1);	
		}
		return filename;
	}
}
