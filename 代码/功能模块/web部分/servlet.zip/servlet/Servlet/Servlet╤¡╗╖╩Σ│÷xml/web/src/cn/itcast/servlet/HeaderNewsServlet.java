package cn.itcast.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.domain.HeaderNew;
import cn.itcast.service.HeaderNewsService;

/**
 * Servlet implementation class HeaderNewsServlet
 */
public class HeaderNewsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private HeaderNewsService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HeaderNewsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		service = new HeaderNewsService();
		List<HeaderNew> headerNews = service.getHeaderNews();
		request.setAttribute("headerNews", headerNews);
		//��ת��һ��jsp
		request.getRequestDispatcher("/WEB-INF/page/headernewsxml.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
