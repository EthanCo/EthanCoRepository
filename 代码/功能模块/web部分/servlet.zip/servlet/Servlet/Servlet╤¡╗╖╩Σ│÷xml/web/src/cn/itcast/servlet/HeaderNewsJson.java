package cn.itcast.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.domain.HeaderNew;
import cn.itcast.service.HeaderNewsService;

/**
 * Servlet implementation class HeaderNewsJson
 */
public class HeaderNewsJson extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HeaderNewsJson() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HeaderNewsService service = new HeaderNewsService();
		List<HeaderNew> headerNews = service.getHeaderNews();// ctrl + 2  L 
		//[{image:"httP://192.168.1.101:8080/web/a.jpg",title:"",content:"",count:""},{}] 
		StringBuilder sb = new StringBuilder("[");
		for(HeaderNew headerNew:headerNews){
			sb.append("{");
			sb.append("image:").append("\"").append(headerNew.getImage()).append("\"").append(",");
			sb.append("title:").append("\"").append(headerNew.getTitle()).append("\"").append(",");
			sb.append("content:").append("\"").append(headerNew.getContent()).append("\"").append(",");
			sb.append("count:").append("\"").append(headerNew.getCount()).append("\"");
			sb.append("}");
			sb.append(",");
		}
		sb.deleteCharAt(sb.length() -1 );
		sb.append("]");
		
		request.setAttribute("json", sb.toString());
		request.getRequestDispatcher("WEB-INF/page/headernewsjson.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
