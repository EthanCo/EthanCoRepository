package com.zhk.loginWeb;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class loginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
			String name = req.getParameter("name");
//			String name = new String(req.getParameter("name").getBytes("ISO-8859-1"),"utf-8"); //iso-8859-1 ��tomcat�����ʽ,ת��Ϊutf-8
			String password = req.getParameter("password");
			System.out.println("name:"+name+" - "+"password:"+password);
	}
	
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}
}
