package com.zhk.filter;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class EncodingHttpServletRequestWrapper extends
		HttpServletRequestWrapper {

	HttpServletRequest request;
	
	public EncodingHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);
		this.request=request;
	}

	@Override
	public String getParameter(String name) {
		String value = request.getParameter(name);
		if(value!=null){
			String data=null;
			try {
				data = new String(value.getBytes("ISO-8859-1"),"utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return data;
		}
		return super.getParameter(name);
	}
}
