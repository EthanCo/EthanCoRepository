package com.zhk.loginapp;

import java.io.IOException;

import org.json.JSONObject;

import com.zhk.service.LoginService;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	private final static int LOGINBYGET = 1;

	private EditText etName;
	private EditText etPwd;
	private Button btLogin;
	private LoginService service;

	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case LOGINBYGET:
				boolean res = (boolean) msg.obj;
				loginResult(res);
				break;
			default:
				break;
			}
		};
	};

	public void loginResult(boolean res) {
		int info = R.string.loginFALSE;
		if (res) {
			info = R.string.loginSUCEESE;
		}
		Toast.makeText(getApplicationContext(), info, Toast.LENGTH_SHORT).show();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		etName = (EditText) findViewById(R.id.name);
		etPwd = (EditText) findViewById(R.id.password);
		btLogin = (Button) findViewById(R.id.btLogin);

		service = new LoginService();

		btLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Toast.makeText(MainActivity.this, "���ڵ�½", Toast.LENGTH_SHORT).show();

				final String name = etName.getText().toString();
				final String password = etPwd.getText().toString();
				Log.i("log.i", "log.i-" + name + password);
				if (name == "" || password == "") {
					Toast.makeText(MainActivity.this, "�˺ź����벻��Ϊ��", Toast.LENGTH_SHORT).show();
				} else {

					new Thread() {
						public void run() {
							try {
								LoginService service2 = new LoginService();
								// boolean res =
								// service2.LoginByGet("http://10.0.2.2:8080/loginWeb/login",
								// name, password); // ������localhost //��get����
								// boolean res =
								// service2.LoginByPost("http://10.0.2.2:8080/loginWeb/login",
								// name, password);//��post����
								// boolean res =
								// service2.loginByHttpClientGet("http://10.0.2.2:8080/loginWeb/login",
								// name, password); //��HttpClient Get��ʽ����
								boolean res = service2.loginHttpClientByPost("http://10.0.2.2:8080/loginWeb/login", name, password); // ��HttpClient  Post��ʽ����
								String a = "false";
								if (res) {
									a = "true";
								}
								Log.i("log.i", a);
								Message msg = new Message();
								msg.what = LOGINBYGET;
								msg.obj = res;
								mHandler.sendMessage(msg);
							} catch (IOException e) {
								Log.i("log.i", "IOException");
								e.printStackTrace();
							} catch (Throwable e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}.start();
				}
			}
		});
	}
}
