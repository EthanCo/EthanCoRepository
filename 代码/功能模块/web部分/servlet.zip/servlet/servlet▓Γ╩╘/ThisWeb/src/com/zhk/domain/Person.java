package com.zhk.domain;

public class Person {
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	String name;
	int age;
	public Person(String name, int age, String content) {
		super();
		this.name = name;
		this.age = age;
		this.content = content;
	}
	String content;
}
