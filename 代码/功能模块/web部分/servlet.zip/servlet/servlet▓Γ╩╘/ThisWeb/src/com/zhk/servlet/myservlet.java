package com.zhk.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zhk.domain.Person;
import com.zhk.server.personServer;

public class myservlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
//		//��ת��һ��html
//		req.getRequestDispatcher("/WEB-INF/page/newhtml.html").forward(req, resp);
//		//��ת��һ��jsp
//		req.getRequestDispatcher("/WEB-INF/page/newjsp.jsp").forward(req, resp);
		
		personServer pServer = new personServer();
		List<Person> pList =pServer.getPresons();
		req.setAttribute("persons", pList);
		
//		//��ת��һ��jsp,��ʾxml
//		req.getRequestDispatcher("/WEB-INF/page/xmljsp.jsp").forward(req, resp);
		
		StringBuilder sb = new StringBuilder("[");
		for(Person p:pList){
			sb.append("{");
			sb.append("name:").append("\"").append(p.getName()).append("\"").append(",");
			sb.append("age:").append("\"").append(p.getAge()).append("\"").append(",");
			sb.append("content:").append("\"").append(p.getContent()).append("\"");
			sb.append("}");
			sb.append(",");
		}
		sb.deleteCharAt(sb.length() -1 );
		sb.append("]");
		
		req.setAttribute("json", sb.toString());
		
		//��ת��һ��jsp,��ʾjson
		req.getRequestDispatcher("/WEB-INF/page/jsonjsp.jsp").forward(req, resp);
	}
}
