package com.zhk.server;

import java.util.ArrayList;
import java.util.List;

import com.zhk.domain.Person;

public class personServer {
	public List<Person> getPresons(){
		List<Person> pList = new ArrayList();
		for (int i = 10; i < 20; i++) {
			Person p = new Person("�����00"+i, i, "������ļ�鰡xx"+i);
			pList.add(p);
		}
		return pList;
	}
}
