package com.zhk.ningbo.webviewtest1;

import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Administrator on 2015/8/2.
 */
public class HttpThread extends Thread {

    private String mUrl;

    public HttpThread(String url) {
        this.mUrl = url;
    }

    @Override
    public void run() {
        try {
            URL httpUrl = new URL(mUrl);
            HttpURLConnection conn = (HttpURLConnection) httpUrl.openConnection();
            conn.setDoInput(true);
            /**
             android 4.0���ϵ�ϵͳ������conn.setDoOutput(true),������������post��ʽ�ύ,��ʵ��������㲻��Ҫ��������ύ������Ϣ������Ƶ�еĴ�����4.0�����ֻ����ǿ������еģ���android����ϵͳ������Ա��4.0���ϵ��ֻ���http����������޸ģ����ԲŻ������˵���쳣��
             �޸ķ�ʽ��
             conn.setDoInput(true);
             //	conn.setDoOutput(true);
             conn.setRequestMethod("GET")
             */
            //conn.setDoOutput(true);
            conn.setRequestMethod("GET");
            File downloadFile;
            File sdFile;
            FileOutputStream out;
            if (conn.getResponseCode() == 200) {
                Log.i("zhklog", "download start");
                InputStream in = conn.getInputStream();
                Log.i("zhklog", "get input stream");
                if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                    Log.i("zhklog", "exter storage exit");
                    downloadFile = Environment.getExternalStorageDirectory();
                    sdFile = new File(downloadFile, "test1.apk");
                    out = new FileOutputStream(sdFile);

                    byte[] b = new byte[6 * 1024];
                    int len;
                    Log.i("zhklog", "download start write");
                    while ((len = in.read(b)) != -1) {
                        Log.i("zhklog", "len:" + len);
                        if (out != null) {
                            out.write(b, 0, len);
                        }
                    }
                    Log.i("zhklog", "download success");
                    if (out != null) {
                        out.close();
                    }
                    if (in != null) {
                        in.close();
                    }
                } else {
                    Log.i("zhklog", "exter storage not exit");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.i("zhklog", "exception:" + e.getMessage());
        }
    }
}
