package com.bocweb.cunyou.utils;

import android.app.Activity;
import android.graphics.drawable.BitmapDrawable;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.PopupWindow;

import com.bocweb.cunyou.R;

/**
 * @Description PopupWindow的一个封装工具类
 * Created by EthanCo on 2016/3/30.
 */
public class PopupUtil {
    /**
     * @param activity
     * @param contentView 自定义的view
     * @param heightScale 高度比例 0-1
     * @param anchor
     * @param xoff
     * @param yoff
     */
    public static void showAsDropDown(Activity activity, View contentView, float heightScale, View anchor, int xoff, int yoff) {
        DisplayMetrics outMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(outMetrics);
        int mScreenHeight = outMetrics.heightPixels;
        final PopupWindow popupWindow = new PopupWindow(contentView,
                ViewGroup.LayoutParams.MATCH_PARENT, (int) (mScreenHeight * heightScale), true);
        popupWindow.setTouchable(true);
        popupWindow.setAnimationStyle(R.style.anim_popup_dir);
        popupWindow.setOnDismissListener(new poponDismissListener(activity));
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        backgroundAlpha(activity, 0.5f);
        popupWindow.showAsDropDown(anchor, xoff, yoff);
    }

    /**
     * @param activity
     * @param contentView 自定义的view
     * @param heightScale 高度比例 0-1
     * @param anchor
     */
    public static void showAsDropDown(Activity activity, View contentView, float heightScale, View anchor) {
        showAsDropDown(activity, contentView, heightScale, anchor, 0, 0);
    }


    /**
     * 设置添加屏幕的背景透明度
     *
     * @param activity
     * @param bgAlpha
     */
    public static void backgroundAlpha(Activity activity, float bgAlpha) {
        WindowManager.LayoutParams lp = activity.getWindow().getAttributes();
        lp.alpha = bgAlpha; //0.0-1.0
        activity.getWindow().setAttributes(lp);
    }

    /**
     * 添加新笔记时弹出的popWin关闭的事件，主要是为了将背景透明度改回来
     *
     * @author cg
     */
    static class poponDismissListener implements PopupWindow.OnDismissListener {

        private Activity mActivity;

        public poponDismissListener(Activity activity) {
            mActivity = activity;
        }

        @Override
        public void onDismiss() {
            // TODO Auto-generated method stub
            //Log.v("List_noteTypeActivity:", "我是关闭事件");
            backgroundAlpha(mActivity, 1f);
        }
    }
}
